export default {
  apps : [{
    name   : "z",
    script : "./app.js",
    env: {
      PORT:"5001",
      SECRET:"secretpass",
      DB_NAME:"pos-pwa-db",
      DB_USER:"sa",
      DB_PASS:"123456",
      HOST:"localhost",
      DIALECT:"mssql",
      PRINTER:"EPSON-TM-T88V",
      NODE_ENV:"development"
    },
  }]
}
