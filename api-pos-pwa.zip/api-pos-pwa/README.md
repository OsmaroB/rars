# api-pos-pwa

## _Power by Osmaro Bonilla_

[![Osmaro](https://cldup.com/dTxpPi9lDf.thumb.png)](https://nodesource.com/products/nsolid)


Application created with the functionality of API Rest for the POS PWA application of the "inventa" corporation.

## Used tools

- NodeJS
- Swagger (Documentation)
- Nodemon
- Express
- Sequelize

## Installation

Dillinger requires [Node.js](https://nodejs.org/) v14+ to run.

- You must create within your SQLServer engine the database named "pos-pwa-db"
- Configure the initial database file located at "./src/database/databse.js"
- Install the dependencies and devDependencies and start the server.

```sh
git clone https://gitlab.com/desarrollos-it/api-pos-pwa.git
cd api-pos-pwa
npm i
npm run dev
```
The application will run on port 5001 and to see the documentation go to the /api-doc link
