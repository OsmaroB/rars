import app from '../src/app';
import request from 'supertest';

let idUser;
describe('GET /users', ()=>{
    test('should respond with a 200 status code', async ()=>{
        const response = await request(app).get('/users').send();
        expect(response.status).toBe(200);
    });

    test('should respond with an array', async()=>{
        const response = await request(app).get('/users').send();
        expect(response.body).toBeInstanceOf(Array);
    });
});

describe('POST /users', ()=>{
    describe('given a correct structure',()=>{
        const newItem = {
            mask: 'USE-0001',
            email: 'user@gmail.com',
            password: 'password',
            status: 0,
            employeeID: 1,
            roleID: 1,
        }
        test('should respond with a 200 status code', async ()=>{
            const response = await request(app).post('/users').send(newItem);
            expect(response.status).toBe(200);
        });
        test('hould have a content-type: application/json in header', async ()=>{
            const response = await request(app).post('/users').send(newItem);
            expect(response.header['content-type']).toBe('application/json; charset=utf-8');
        });
        test('should respond with an task ID', async ()=>{
            const response = await request(app).post('/users').send(newItem);
            expect(response.body.id).toBeDefined();
            idUser= response.body.id;
        });
    });

});

describe('PUT /users/:id', ()=>{
    describe('given a correct structure',()=>{
        const item = {
            mask: 'USE-0001',
            email: 'user@gmail.com',
            password: 'password',
            employeeID: 1,
            roleID: 1,
        }
        test('should respond with a 200 status code', async ()=>{
            const response = await request(app).put(`/users/${idUser}`).send(item);
            expect(response.status).toBe(200);
        });
        test('hould have a content-type: application/json in header', async ()=>{
            const response = await request(app).put(`/users/${idUser}`).send(item);
            expect(response.header['content-type']).toBe('application/json; charset=utf-8');
        });
        test('should respond with an task ID', async ()=>{
            const response = await request(app).put(`/users/${idUser}`).send(item);
            expect(response.body.id).toBeDefined();
        });
    });

});

// NO FINISH TEST
describe('PUT /users-remove/:id logic delete', ()=>{
    describe('given a correct structure',()=>{
        const item = {
            status: '1',
        }
        test('should respond with a 200 status code', async ()=>{
            const response = await request(app).put(`/users-remove/${idUser}`).send(item);
            expect(response.status).toBe(200);
        });
        test('hould have a content-type: application/json in header', async ()=>{
            const response = await request(app).put(`/users-remove/${idUser}`).send(item);
            expect(response.header['content-type']).toBe('application/json; charset=utf-8');
        });
        test('should respond with an task ID', async ()=>{
            const response = await request(app).put(`/users-remove/${idUser}`).send(item);
            expect(response.body.id).toBeDefined();
        });
    });
});