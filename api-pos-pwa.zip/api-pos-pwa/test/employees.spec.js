import app from '../src/app';
import request from 'supertest';

describe('GET /employees', ()=>{
    test('should respond with a 200 status code', async ()=>{
        const response = await request(app).get('/employees').send();
        expect(response.status).toBe(200);
    });

    test('should respond with an array', async()=>{
        const response = await request(app).get('/employees').send();
        expect(response.body).toBeInstanceOf(Array);
    });
});

describe('POST /employees', ()=>{
    describe('given a correct structure',()=>{
        const newEmployee = {
            mask: 'EMP-0001',
            name: 'name employee',
            lastName: 'lastname employee',
            status: 0
        }
        test('should respond with a 200 status code', async ()=>{
            const response = await request(app).post('/employees').send(newEmployee);
            expect(response.status).toBe(200);
        });
        test('hould have a content-type: application/json in header', async ()=>{
            const response = await request(app).post('/employees').send(newEmployee);
            expect(response.header['content-type']).toBe('application/json; charset=utf-8');
        });
        test('should respond with an task ID', async ()=>{
            const response = await request(app).post('/employees').send(newEmployee);
            expect(response.body.id).toBeDefined();
        });
    });

    describe('when structure incorrect',()=>{
        test('should respond with a 400 status code', async()=>{
            const response = await request(app).post('/employees').send({});
            expect(response.status).toBe(400);
        });
    });
});

describe('PUT /employees/:id', ()=>{
    describe('given a correct structure',()=>{
        const employee = {
            mask: 'EMP-0001',
            name: 'name employee updated',
            lastName: 'lastname employee update',
        }
        test('should respond with a 200 status code', async ()=>{
            const response = await request(app).put('/employees/1').send(employee);
            expect(response.status).toBe(200);
        });
        test('hould have a content-type: application/json in header', async ()=>{
            const response = await request(app).put('/employees/1').send(employee);
            expect(response.header['content-type']).toBe('application/json; charset=utf-8');
        });
        test('should respond with an task ID', async ()=>{
            const response = await request(app).put('/employees/1').send(employee);
            expect(response.body.id).toBeDefined();
        });
    });

    describe('when structure incorrect',()=>{
        test('should respond with a 400 status code', async()=>{
            const response = await request(app).put('/employees/1').send({});
            expect(response.status).toBe(400);
        });
    });
});

// NO FINISH TEST
describe('PUT /employees-remove/:id logic delete', ()=>{
    describe('given a correct structure',()=>{
        const employee = {
            status: '1',
        }
        test('should respond with a 200 status code', async ()=>{
            const response = await request(app).put('/employees-remove/1').send(employee);
            expect(response.status).toBe(200);
        });
        test('hould have a content-type: application/json in header', async ()=>{
            const response = await request(app).put('/employees-remove/1').send(employee);
            expect(response.header['content-type']).toBe('application/json; charset=utf-8');
        });
        test('should respond with an task ID', async ()=>{
            const response = await request(app).put('/employees-remove/1').send(employee);
            expect(response.body.id).toBeDefined();
        });
    });
});