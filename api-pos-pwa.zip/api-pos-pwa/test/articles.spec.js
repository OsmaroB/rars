import app from '../src/app';
import request from 'supertest';

let idArticle;
describe('GET /articles', ()=>{
    test('should respond with a 200 status code', async ()=>{
        const response = await request(app).get('/articles').send();
        expect(response.status).toBe(200);
    });

    test('should respond with an array', async()=>{
        const response = await request(app).get('/articles').send();
        expect(response.body).toBeInstanceOf(Array);
    });
});

describe('POST /articles', ()=>{
    describe('given a correct structure',()=>{
        const newItem = {
            mask: 'ART-0001',
            name: 'article',
            purchasing_unit: 'purchasing unit',
            quantity_purchasing_unit: 200,
            sales_unit: 'sales unit',
            quantity_sales_unit: 200,
            stock: 200,
            status: '0'
        }
        test('should respond with a 200 status code', async ()=>{
            const response = await request(app).post('/articles').send(newItem);
            expect(response.status).toBe(200);
        });
        test('hould have a content-type: application/json in header', async ()=>{
            const response = await request(app).post('/articles').send(newItem);
            expect(response.header['content-type']).toBe('application/json; charset=utf-8');
        });
        test('should respond with an task ID', async ()=>{
            const response = await request(app).post('/articles').send(newItem);
            expect(response.body.id).toBeDefined();
            idArticle = response.body.id;
        });
    });

});

describe('PUT /articles/:id', ()=>{
    describe('given a correct structure',()=>{
        const item = {
            mask: "ART-00002",
            name: "Articulo",
            purchasing_unit: "Unidad de compra",
            quantity_purchasing_unit: 10,
            sales_unit: "Unidad de venta",
            quantity_sales_unit: 2,
            stock: 12
        }
        test('should respond with a 200 status code', async ()=>{
            const response = await request(app).put(`/articles/${idArticle}`).send(item);
            expect(response.status).toBe(200);
        });
        test('hould have a content-type: application/json in header', async ()=>{
            const response = await request(app).put(`/articles/${idArticle}`).send(item);
            expect(response.header['content-type']).toBe('application/json; charset=utf-8');
        });
        test('should respond with an task ID', async ()=>{
            const response = await request(app).put(`/articles/${idArticle}`).send(item);
            expect(response.body.id).toBeDefined();
        });
    });

});

// NO FINISH TEST
describe('PUT /articles-remove/:id logic delete', ()=>{
    describe('given a correct structure',()=>{
        const item = {
            status: '1',
        }
        test('should respond with a 200 status code', async ()=>{
            const response = await request(app).put(`/articles-remove/${idArticle}`).send(item);
            expect(response.status).toBe(200);
        });
        test('hould have a content-type: application/json in header', async ()=>{
            const response = await request(app).put(`/articles-remove/${idArticle}`).send(item);
            expect(response.header['content-type']).toBe('application/json; charset=utf-8');
        });
        test('should respond with an task ID', async ()=>{
            const response = await request(app).put(`/articles-remove/${idArticle}`).send(item);
            expect(response.body.id).toBeDefined();
        });
    });
});