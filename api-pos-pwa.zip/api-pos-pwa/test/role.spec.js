import app from '../src/app';
import request from 'supertest';

let idRole;
describe('GET /roles', ()=>{
    test('should respond with a 200 status code', async ()=>{
        const response = await request(app).get('/roles').send();
        expect(response.status).toBe(200);
    });

    test('should respond with an array', async()=>{
        const response = await request(app).get('/roles').send();
        expect(response.body).toBeInstanceOf(Array);
    });
});

describe('POST /roles', ()=>{
    describe('given a correct structure',()=>{
        const newItem = {
            mask: 'ROL-0001',
            name: 'role name',
            description: 'rol description',
            status: 0
        }
        test('should respond with a 200 status code', async ()=>{
            const response = await request(app).post('/roles').send(newItem);
            expect(response.status).toBe(200);
        });
        test('hould have a content-type: application/json in header', async ()=>{
            const response = await request(app).post('/roles').send(newItem);
            expect(response.header['content-type']).toBe('application/json; charset=utf-8');
        });
        test('should respond with an task ID', async ()=>{
            const response = await request(app).post('/roles').send(newItem);
            expect(response.body.id).toBeDefined();
            idRole= response.body.id;
        });
    });

});

describe('PUT /roles/:id', ()=>{
    describe('given a correct structure',()=>{
        const item = {
            mask: 'ROL-0001',
            name: 'role name',
            description: 'rol description'
        }
        test('should respond with a 200 status code', async ()=>{
            const response = await request(app).put(`/roles/${idRole}`).send(item);
            expect(response.status).toBe(200);
        });
        test('hould have a content-type: application/json in header', async ()=>{
            const response = await request(app).put(`/roles/${idRole}`).send(item);
            expect(response.header['content-type']).toBe('application/json; charset=utf-8');
        });
        test('should respond with an task ID', async ()=>{
            const response = await request(app).put(`/roles/${idRole}`).send(item);
            expect(response.body.id).toBeDefined();
        });
    });

});

// NO FINISH TEST
describe('PUT /roles-remove/:id logic delete', ()=>{
    describe('given a correct structure',()=>{
        const item = {
            status: '1',
        }
        test('should respond with a 200 status code', async ()=>{
            const response = await request(app).put(`/roles-remove/${idRole}`).send(item);
            expect(response.status).toBe(200);
        });
        test('hould have a content-type: application/json in header', async ()=>{
            const response = await request(app).put(`/roles-remove/${idRole}`).send(item);
            expect(response.header['content-type']).toBe('application/json; charset=utf-8');
        });
        test('should respond with an task ID', async ()=>{
            const response = await request(app).put(`/roles-remove/${idRole}`).send(item);
            expect(response.body.id).toBeDefined();
        });
    });
});