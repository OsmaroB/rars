import jwt from 'jsonwebtoken';
import {SECRET} from '../config/config.js';
import { User } from '../models/User.js';

export const verifyToken = async (req, res, next)=>{
    try {
        const token = req.headers["x-access-token"];
        if(!token) return res.status(403).json({message: "No token provider"})
        const decoded = jwt.verify(token, SECRET);
        req.id = decoded.id;
        const user = await User.findByPk(req.id);
        if(!user) return res.status(404).json({message: 'No user found'});
        next();
    } catch (error) {
        return res.status(401).json({message: 'Unauthorized'})
    }
}
