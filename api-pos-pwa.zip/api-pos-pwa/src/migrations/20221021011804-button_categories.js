'use strict';
module.exports = {
  async up (queryInterface, Sequelize) {
    await queryInterface.createTable('buttonCategories', {
      id: {
        type: Sequelize.INTEGER,
        primaryKey: true,
        autoIncrement: true,
        allowNull: false
      },
      buttonID:{
        type: Sequelize.INTEGER,
        references:{
          model: 'buttons',
          key:'id'  
        }
      },
      categoryID:{
        type: Sequelize.INTEGER,
        references:{
          model:'categories',
          key:'id'  
        }
      },
      days:{
        type:Sequelize.STRING
      },
      untilDate:{
          type:Sequelize.STRING
      },
      specificDate:{
          type:Sequelize.STRING
      },
      status:{
          type: Sequelize.INTEGER,
          defaultValue: 0,
      },
      userCreate:{
          type: Sequelize.INTEGER
      },
      userUpdate: {
          type: Sequelize.INTEGER
      },
      createdAt: {
        type: Sequelize.DATE,
        defaultValue: Sequelize.NOW,
      },
      updatedAt: {
          type: Sequelize.DATE,
        defaultValue: Sequelize.NOW,
      },
    });
  },

  async down (queryInterface, Sequelize) {
    await queryInterface.dropTable('buttonCategories');
  }
};
