'use strict';

/** @type {import('sequelize-cli').Migration} */
module.exports = {
  async up (queryInterface, Sequelize) {
    await queryInterface.createTable('discounts', {
      id: {
        type: Sequelize.INTEGER,
        primaryKey: true,
        autoIncrement: true,
        allowNull: false
      },
      mask:{
        type: Sequelize.STRING(11)
      },
      name:{
        type: Sequelize.STRING(75)
      },
      isGlobal:{
        type: Sequelize.BOOLEAN
      },
      type:{
        type: Sequelize.INTEGER
      },
      discountInfo:{
        type: Sequelize.DOUBLE,
        defaultValue: 0,
      },
      status:{
          type: Sequelize.INTEGER,
          defaultValue: 0,
      },
      channelID:{
        type: Sequelize.INTEGER,
        references:{
          model:'channelsSubchannels',
          key:'id'  
        }
      },
      subchannelID:{
        type: Sequelize.INTEGER,
        references:{
          model:'subchannels',
          key:'id'  
        } 
      },
      userCreate:{
          type: Sequelize.INTEGER
      },
      userUpdate: {
          type: Sequelize.INTEGER
      },
      createdAt: {
        type: Sequelize.DATE,
        defaultValue: Sequelize.NOW,
      },
      updatedAt: {
          type: Sequelize.DATE,
        defaultValue: Sequelize.NOW,
      },
    });
  },

  async down (queryInterface, Sequelize) {
    await queryInterface.dropTable('discounts');
  }
};
