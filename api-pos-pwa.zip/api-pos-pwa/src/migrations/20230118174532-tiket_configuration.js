'use strict';

/** @type {import('sequelize-cli').Migration} */
module.exports = {
  async up (queryInterface, Sequelize) {
    await queryInterface.createTable('tiketConfigurations', {
      id: {
        type: Sequelize.INTEGER,
        primaryKey: true,
        autoIncrement: true,
        allowNull: false
      },
      enterprise:{
        type: Sequelize.STRING(50)
      },
      nit:{
        type: Sequelize.STRING(20)
      },
      item:{
        type: Sequelize.STRING(100)
      },
      address:{
        type: Sequelize.STRING(255)
      },
      resolution:{
        type: Sequelize.STRING(20)
      },
      serie:{
        type: Sequelize.STRING(20)
      },
      authorizationDate:{
        type: Sequelize.STRING(10)
      },
      cashRegisterNumber:{
        type: Sequelize.STRING(10)
      },
      link:{
        type: Sequelize.STRING(255)
      },
      paragraph1:{
        type: Sequelize.STRING(255)
      },
      paragraph2:{
        type: Sequelize.STRING(255)
      },
      userCreate:{
          type: Sequelize.INTEGER
      },
      userUpdate: {
          type: Sequelize.INTEGER
      },
      createdAt: {
        type: Sequelize.DATE,
        defaultValue: Sequelize.NOW,
      },
      updatedAt: {
          type: Sequelize.DATE,
        defaultValue: Sequelize.NOW,
      },
    });
  },

  async down (queryInterface, Sequelize) {
    await queryInterface.dropTable('tiketConfigurations');
  }
};
