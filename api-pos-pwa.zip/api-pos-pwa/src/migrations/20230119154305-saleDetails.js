'use strict';

// /** @type {import('sequelize-cli').Migration} */
module.exports = {
  async up (queryInterface, Sequelize) {
    await queryInterface.createTable('saleDetails', {
      id: {
        type: Sequelize.INTEGER,
        primaryKey: true,
        autoIncrement: true,
        allowNull: false
      },
      tiketNumber:{
        type: Sequelize.STRING
      },
      maskDetail:{
        type: Sequelize.STRING
      },
      typeDetail:{
        type: Sequelize.STRING
      },
      line:{
        type: Sequelize.STRING
      },
      product:{
        type: Sequelize.STRING
      },
      description:{
        type: Sequelize.STRING
      },
      modifier:{
        type: Sequelize.STRING
      },
      cashRegisterNumber:{
        type: Sequelize.STRING
      },
      restaurant:{
        type: Sequelize.STRING
      },
      cant:{
        type: Sequelize.INTEGER
      },
      cost:{
        type: Sequelize.DOUBLE
      },
      totalWithoutTax:{
        type: Sequelize.DOUBLE
      },
      discountLine:{
        type: Sequelize.DOUBLE
      },
      totalWithDiscount:{
        type: Sequelize.DOUBLE
      },
      tax:{
        type: Sequelize.DOUBLE
      },
      totalWithTax:{
        type: Sequelize.DOUBLE
      },
      tip:{
        type: Sequelize.DOUBLE
      },
      priceID:{
        type: Sequelize.INTEGER,
        references:{
          model:'prices',
          key:'id'  
        }
      },
      saleID:{
        type: Sequelize.INTEGER,
        references:{
          model:'sales',
          key:'id'  
        }
      },
      userCreate:{
          type: Sequelize.INTEGER
      },
      userUpdate: {
          type: Sequelize.INTEGER
      },
      createdAt: {
        type: Sequelize.DATE,
        defaultValue: Sequelize.NOW,
      },
      updatedAt: {
          type: Sequelize.DATE,
        defaultValue: Sequelize.NOW,
      },
    });
  },

  async down (queryInterface, Sequelize) {
    await queryInterface.dropTable('saleDetails');
  }
};
