'use strict';

// /** @type {import('sequelize-cli').Migration} */
module.exports = {
  async up (queryInterface, Sequelize) {
    await queryInterface.createTable('buttonDetails', {
      id: {
        type: Sequelize.INTEGER,
        primaryKey: true,
        autoIncrement: true,
        allowNull: false
      },
      status:{
          type: Sequelize.INTEGER,
          defaultValue: 0,
      },
      productID:{
        type: Sequelize.INTEGER,
        references:{
          model:'products',
          key:'id'  
        }
      },
      buttonID:{
        type: Sequelize.INTEGER,
        references:{
          model:'buttons',
          key:'id'  
        }
      },
      userCreate:{
          type: Sequelize.INTEGER
      },
      userUpdate: {
          type: Sequelize.INTEGER
      },
      createdAt: {
        type: Sequelize.DATE,
        defaultValue: Sequelize.NOW,
      },
      updatedAt: {
          type: Sequelize.DATE,
        defaultValue: Sequelize.NOW,
      },
    });
  },

  async down (queryInterface, Sequelize) {
    await queryInterface.dropTable('buttonDetails');
  }
};
