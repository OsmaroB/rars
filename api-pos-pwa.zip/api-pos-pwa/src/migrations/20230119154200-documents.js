'use strict';

// /** @type {import('sequelize-cli').Migration} */
module.exports = {
  async up (queryInterface, Sequelize) {
    await queryInterface.createTable('documents', {
      id: {
        type: Sequelize.INTEGER,
        primaryKey: true,
        autoIncrement: true,
        allowNull: false
      },
      mask:{
          type: Sequelize.STRING
      },
      startCorrelative:{
          type: Sequelize.STRING
      },
      finishCorrelative:{
          type: Sequelize.STRING
      },
      actualCorrelative:{
          type: Sequelize.STRING
      },
      documentTypeID:{
        type: Sequelize.INTEGER,
        references:{
          model:'documentTypes',
          key:'id'  
        }
      },
      status:{
        type: Sequelize.INTEGER
      },
      userCreate:{
          type: Sequelize.INTEGER
      },
      userUpdate: {
          type: Sequelize.INTEGER
      },
      createdAt: {
        type: Sequelize.DATE,
        defaultValue: Sequelize.NOW,
      },
      updatedAt: {
          type: Sequelize.DATE,
        defaultValue: Sequelize.NOW,
      },
    });
  },

  async down (queryInterface, Sequelize) {
    await queryInterface.dropTable('documents');
  }
};
