'use strict';

/** @type {import('sequelize-cli').Migration} */
module.exports = {
  async up (queryInterface, Sequelize) {
    await queryInterface.createTable('roleDetails', {
      id: {
        type: Sequelize.INTEGER,
        primaryKey: true,
        autoIncrement: true,
        allowNull: false
      },
      mask:{
          type: Sequelize.STRING(9)
      },
      url: {
          type: Sequelize.STRING(255)
      },
      status:{
          type: Sequelize.INTEGER,
          defaultValue: 0,
      },
      roleID:{
        type: Sequelize.INTEGER,
        references:{
          model:'roles',
          key:'id'  
        }
      },
      userCreate:{
          type: Sequelize.INTEGER
      },
      userUpdate: {
          type: Sequelize.INTEGER
      },
      createdAt: {
        type: Sequelize.DATE,
        defaultValue: Sequelize.NOW,
      },
      updatedAt: {
          type: Sequelize.DATE,
        defaultValue: Sequelize.NOW,
      },
    });
  },

  async down (queryInterface, Sequelize) {
    await queryInterface.dropTable('roleDetails');
  }
};
