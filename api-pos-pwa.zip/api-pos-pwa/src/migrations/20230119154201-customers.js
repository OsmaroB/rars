'use strict';

// /** @type {import('sequelize-cli').Migration} */
module.exports = {
  async up (queryInterface, Sequelize) {
    await queryInterface.createTable('customers', {
      id: {
        type: Sequelize.INTEGER,
        primaryKey: true,
        autoIncrement: true,
        allowNull: false
      },
      mask:{
          type: Sequelize.STRING(9)
      },
      dui:{
          type: Sequelize.STRING(14)
      },
      name:{
        type: Sequelize.STRING(100)
      },
      lastName:{
        type: Sequelize.STRING(100)
      },
      email:{
        type: Sequelize.STRING(255)
      },
      status:{
        type: Sequelize.INTEGER,
        defaultValue: 0

      },
      userCreate:{
          type: Sequelize.INTEGER
      },
      userUpdate: {
          type: Sequelize.INTEGER
      },
      createdAt: {
        type: Sequelize.DATE,
        defaultValue: Sequelize.NOW,
      },
      updatedAt: {
          type: Sequelize.DATE,
        defaultValue: Sequelize.NOW,
      },
    });
  },

  async down (queryInterface, Sequelize) {
    await queryInterface.dropTable('customers');
  }
};
