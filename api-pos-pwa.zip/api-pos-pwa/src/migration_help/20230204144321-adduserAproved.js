'use strict';

// /** @type {import('sequelize-cli').Migration} */
module.exports = {
  async up (queryInterface, Sequelize) {
    await queryInterface.addColumn('cashDeskClosings', 
    'userAproved',{
      type: Sequelize.STRING,
    });
    await queryInterface.addColumn('sales', 
    'userAproved',{
      type: Sequelize.STRING,
    });
    await queryInterface.addColumn('outputCashDesks', 
    'userAproved',{
      type: Sequelize.STRING,
    });
  },

  async down (queryInterface, Sequelize) {
    // await queryInterface.dropTable('sales');
  }
};
