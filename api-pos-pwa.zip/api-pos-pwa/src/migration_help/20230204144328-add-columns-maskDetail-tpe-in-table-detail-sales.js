'use strict';

// /** @type {import('sequelize-cli').Migration} */
module.exports = {
  async up (queryInterface, Sequelize) {
    await queryInterface.addColumn(
      'SaleDetails', 
      'maskDetail',
      {
        type: Sequelize.STRING,
      }
    );
    await queryInterface.addColumn(
      'SaleDetails', 
      'typeDetail',
      {
        type: Sequelize.INTEGER,
      }
    );
  },

  async down (queryInterface, Sequelize) {
    // await queryInterface.dropTable('sales');
  }
};
