'use strict';

// /** @type {import('sequelize-cli').Migration} */
module.exports = {
  async up (queryInterface, Sequelize) {
    await queryInterface.changeColumn('TiketConfigurations', 'enterprise', {
      type: Sequelize.STRING(100),
    });
    await queryInterface.changeColumn('TiketConfigurations', 'resolution', {
      type: Sequelize.STRING(50),
    });
  },

  async down (queryInterface, Sequelize) {
    // await queryInterface.dropTable('sales');
  }
};
