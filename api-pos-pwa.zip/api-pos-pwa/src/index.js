import app from './app.js';
import {sequelize} from './database/database.js'
import './models/User.js';
import './models/Employee.js';
import './models/Role.js';
import './models/RoleDetail.js';
import './models/Recipes.js';
import './models/Articles.js';
import './models/RecipeArticles.js';
import './models/ProductDetails.js';
import './models/Products.js';
import './models/Buttons.js';
import './models/ButtonDetails.js';
import './models/ChannelsSubchannels.js';
import './models/Categories.js';
import './models/ButtonCategories.js';
import './models/DocumentTypes.js';
import './models/Optionals.js';
import './models/PaymentMethods.js';

const main = async ()=>{
    try {
        await sequelize.sync({force: false});
        app.listen(5001);
    } catch (error) {
        console.log('Unable to connect to the database: ', error);
    }
}
main();
