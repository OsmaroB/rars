import { Router } from "express";
import {
    getDocuments,
    getDocumentForId,
    createDocument,
    updateDocument,
    statusDocument,
    getDocumentsForDocumentType,
} from '../controllers/document.controller.js';

const router = Router();

router.get('/documents', getDocuments);
router.post('/documents', createDocument);
router.put('/documents/:id', updateDocument);
router.get('/documents/:id', getDocumentForId);
router.put('/document-remove/:id', statusDocument);
router.post('/documents-for-document-type', getDocumentsForDocumentType);


export default router;