import { Router } from "express";
import {
    getCashDeskClosing,
    getCashDeskClosingForId,
    createCashDeskClosing,
    updateCashDeskClosing,
    statusCashDeskClosing,
    startCashDeskClosingX,
    updatePrettyCashCashDeskClosing,
    readCashDeskClosingForDateCashDeskStatus,
    updateCashCashDeskClosing,
    getCashDeskClosingForTypeDate,
} from '../controllers/cash-desk-closing.js';


const router = Router();

router.get('/cash-desk-closing', getCashDeskClosing);
router.put('/update-pretty-cash/:id', updatePrettyCashCashDeskClosing);
router.put('/update-cash-cash/:id', updateCashCashDeskClosing);
router.post('/cash-desk-closing', createCashDeskClosing);
router.post('/start-desk-closing-x', startCashDeskClosingX);
router.post('/cash-desk-closing-for-date-cashdesk-status', readCashDeskClosingForDateCashDeskStatus);
router.put('/cash-desk-closing/:id', updateCashDeskClosing);
router.put('/cash-desk-closing-remove/:id', statusCashDeskClosing);
router.get('/cash-desk-closing/:id', getCashDeskClosingForId);
router.post('/cash-desk-closing-type-date-cashregister', getCashDeskClosingForTypeDate);

export default router;