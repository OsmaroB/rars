import { Router } from "express";
import {
    getRoleDetails,
    getRoleDetailForId,
    updateRoleDetail,
    createRoleDetail,
    statusRoleDetail
} from '../controllers/roles-details.controllers.js'

const router = Router();

router.get('/roles-detail', getRoleDetails);
router.post('/roles-detail', createRoleDetail);
router.put('/roles-detail/:id', updateRoleDetail);
router.put('/roles-detail-remove/:id',statusRoleDetail);
router.get('/roles-detail/:id', getRoleDetailForId);

export default router;