import { Router } from "express";
import {
    getCustomers,
    getCustomerForId,
    createCustomer,
    updateCustomer,
    statusCustomer,
    customerRepeat,
    customerEmailRepeat,
} from '../controllers/customer.controller.js';

const router = Router();

router.get('/customers', getCustomers);
router.post('/customers', createCustomer);
router.put('/customers/:id', updateCustomer);
router.put('/customers-remove/:id', statusCustomer);
router.get('/customers/:id', getCustomerForId);
router.post('/customer-repeat', customerRepeat);
router.post('/customer-email-repeat', customerEmailRepeat);

export default router;