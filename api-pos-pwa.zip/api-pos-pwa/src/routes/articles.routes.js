import { Router } from "express";
import {
    getArticles,
    getArticleForId,
    updateArticle,
    createArticle,
    statusArticle,
} from '../controllers/articles.controllers.js'

const router = Router();

/** 
 * @openapi
 * /articles:
 *  get:
 *    tags:
 *      - Articles
 *    summary: Get all elements
 *    description: Get all items in table
 *    responses:
 *      '200':
 *        description: A successful response
*/
router.get('/articles', getArticles);

/**
 * @openapi
 * /articles:
 *  post:
 *      tags:
 *          - Articles
 *      summary: Register item in table with success structure
 *      description: use to create item in table
 *      responses:
 *          '200':
 *              description: A successful response
 *      requestBody:
 *          required: true
 *          content:
 *              application/json:
 *                  schema:
 *                      $ref: '#/components/schemas/createArticle'
 * 
 */
router.post('/articles', createArticle);

/**
 * @openapi
 * /articles/1:
 *  put:
 *      tags:
 *          - Articles
 *      summary: Update element
 *      description: use to update item in table with success structure
 *      responses:
 *          '200':
 *              description: A successful response
 *      requestBody:
 *          required: true
 *          content:
 *              application/json:
 *                  schema:
 *                      $ref: '#/components/schemas/updateArticle'
 */
router.put('/articles/:id', updateArticle);

/**
 * @openapi
 * /articles-remove/1:
 *  put:
 *      tags:
 *          - Articles
 *      summary: Remove logit item for status in table
 *      description: Update column status in table
 *      responses:
 *          '200':
 *              description: A successful response
 *      requestBody:
 *          required: true
 *          content:
 *              application/json:
 *                  schema:
 *                      $ref: '#/components/schemas/delete'
 * 
 */
router.put('/articles-remove/:id', statusArticle);

/**
 * @openapi
 * /articles/1:
 *  get:
 *      tags:
 *          - Articles
 *      summary: Get element for Id
 *      description: Read element for id in table
 *      responses:
 *          '200':
 *              description: A successful response
 * 
 */
router.get('/articles/:id', getArticleForId);

export default router;