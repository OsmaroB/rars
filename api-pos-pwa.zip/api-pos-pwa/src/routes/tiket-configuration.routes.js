import { Router } from "express";
import {
    getTiketConfiguration,
    createTiketConfiguration,
    updateTiketConfiguration
} from '../controllers/tiket-configuration.controllers.js';

const router = Router();

router.get('/tiket-configuration', getTiketConfiguration);
router.post('/tiket-configuration', createTiketConfiguration);
router.put('/tiket-configuration/:id', updateTiketConfiguration);

export default router;