import { Router } from "express";
import {
    getCategories,
    getCategoryForId,
    createCategory,
    updateCategory,
    statusCategory
} from '../controllers/categories.controllers.js'

const router = Router();

router.get('/categories', getCategories);
router.post('/categories', createCategory);
router.put('/categories/:id', updateCategory);
router.put('/categories-remove/:id', statusCategory);
router.get('/categories/:id', getCategoryForId);

export default router;