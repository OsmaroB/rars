import { Router } from "express";
import { 
    createPaymentMethodDetail,
    updatePaymentMethodDetail,
    statusPaymentMethod,
    getPaymentMethodDetails,
    getPaymentMethodForId
} from '../controllers/payment-method-details.controllers.js';

const router = Router();

router.get('/payment-method-details', getPaymentMethodDetails);
router.post('/payment-method-details', createPaymentMethodDetail);
router.put('/payment-method-details/:id', updatePaymentMethodDetail);
router.put('/payment-method-details-remove/:id', statusPaymentMethod);
router.get('/payment-method-details/:id', getPaymentMethodForId);

export default router;