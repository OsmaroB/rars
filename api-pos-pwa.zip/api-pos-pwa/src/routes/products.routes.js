import { Router } from "express";
import {
    getProducts,
    getProductForId,
    createProduct,
    updateProduct,
    statusProduct
} from '../controllers/products.controllers.js'

const router = Router();

router.get('/products', getProducts);
router.post('/products', createProduct);
router.put('/products/:id', updateProduct);
router.put('/products-remove/:id', statusProduct);
router.get('/products/:id', getProductForId);

export default router;