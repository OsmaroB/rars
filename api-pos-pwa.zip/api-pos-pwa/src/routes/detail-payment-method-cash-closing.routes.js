import { Router } from "express";
import {
    getDetailPaymentMethodCashClosing,
    getDetailPaymentMethodCashClosingForId,
    createDetailPaymentMethodCashClosing,
    updateDetailPaymentMethodCashClosing,
    statusDetailPaymentMethodCashClosing,
    readtDetailPaymentMethodCashClosingForCashRegister,
} from '../controllers/detail-payment-method-cash-closing.controller.js';

const router = Router();

router.get('/detail-payment-method-cash-closing', getDetailPaymentMethodCashClosing);
router.post('/detail-payment-method-cash-closing', createDetailPaymentMethodCashClosing);
router.put('/detail-payment-method-cash-closing/:id', updateDetailPaymentMethodCashClosing);
router.put('/detail-payment-method-cash-closing-remove/:id', statusDetailPaymentMethodCashClosing);
router.get('/detail-payment-method-cash-closing/:id', getDetailPaymentMethodCashClosingForId);
router.post('/detail-payment-method-cash-closing-for-cash-desk-closing', readtDetailPaymentMethodCashClosingForCashRegister);

export default router;