import { Router } from "express";
import {
    getOptionalProductForId,
    getOptionalProducts,
    createOptionalProduct,
    updateOptionalProduct,
    statusOptionalProduct
} from '../controllers/optional-products.controllers.js';

const router = Router();

router.get('/optional-products', getOptionalProducts);
router.post('/optional-products', createOptionalProduct);
router.put('/optional-products/:id', updateOptionalProduct);
router.put('/optional-products-remove/:id', statusOptionalProduct);
router.get('/optional-products/:id', getOptionalProductForId);

export default router;