import { Router } from "express";
import {
    getOptionals,
    getOptionalForId,
    createOptional,
    updateOptional,
    statusOptional
} from '../controllers/optionals.controllers.js';

const router = Router();

router.get('/optionals', getOptionals);
router.post('/optionals', createOptional);
router.put('/optionals/:id', updateOptional);
router.put('/optionals-remove/:id', statusOptional);
router.get('/optionals/:id', getOptionalForId);

export default router;