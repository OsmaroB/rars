import { Router } from "express";
import {
    getPaymentMethods,
    getPaymentMethodForId,
    createPaymentMethod,
    updatePaymentMethod,
    statusPaymentMethod
} from '../controllers/payment-methods.controllers.js';

const router = Router();

router.get('/payment-methods', getPaymentMethods);
router.post('/payment-methods', createPaymentMethod);
router.put('/payment-methods/:id', updatePaymentMethod);
router.put('/payment-methods-remove/:id', statusPaymentMethod);
router.get('/payment-methods/:id', getPaymentMethodForId);

export default router;