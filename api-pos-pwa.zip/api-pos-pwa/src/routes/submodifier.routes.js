import { Router } from "express";
import {
    createSubmodifier,
    updateSubmodifier,
    getSubmodifierForId,
    getSubmodifiers,
    statusSubmodifier
} from '../controllers/submodifiers.controllers.js';

const router = Router();

router.get('/submodifiers', getSubmodifiers);
router.post('/submodifiers', createSubmodifier);
router.put('/submodifiers/:id', updateSubmodifier);
router.put('/submodifiers-remove/:id', statusSubmodifier);
router.get('/submodifiers/:id', getSubmodifierForId);

export default router;