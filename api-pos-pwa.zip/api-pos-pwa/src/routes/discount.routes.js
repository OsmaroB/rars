import { Router } from "express";
import {
    createDiscount,
    updateDiscount,
    getDiscountForId,
    getDiscounts,
    statusDiscount,
} from '../controllers/discounts.controllers.js';

const router = Router();

router.get('/discounts', getDiscounts);
router.post('/discounts', createDiscount);
router.put('/discounts/:id', updateDiscount);
router.put('/discounts-remove/:id', statusDiscount);
router.get('/discounts/:id', getDiscountForId);

export default router;