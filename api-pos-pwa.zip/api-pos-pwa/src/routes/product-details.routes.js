import { Router } from "express";
import {
    getProductDetails,
    getProductDetailForId,
    updateProductDetail,
    createProductDetail,
    statusProductDetail
} from '../controllers/product-details.controller.js'

const router = Router();

router.get('/product-details', getProductDetails);
router.post('/product-details', createProductDetail);
router.put('/product-details/:id', updateProductDetail);
router.put('/product-details-remove/:id', statusProductDetail);
router.get('/product-details/:id', getProductDetailForId);

export default router;