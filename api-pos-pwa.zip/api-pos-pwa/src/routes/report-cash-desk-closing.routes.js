import { Router } from "express";
import {
    getReportCashDeskClosing,
    getReportCashDeskClosingForId,
    createReportCashDeskClosing,
    updateReportCashDeskClosing,
    statusReportCashDeskClosing,
    readReportCashDeskClosingForCashDesk,
} from '../controllers/report-cash-desk-closing.controller.js';

const router = Router();

router.get('/report-cash-desk-closing', getReportCashDeskClosing);
router.post('/report-cash-desk-closing', createReportCashDeskClosing);
router.put('/report-cash-desk-closing/:id', updateReportCashDeskClosing);
router.put('/report-cash-desk-closing-remove/:id', statusReportCashDeskClosing);
router.get('/report-cash-desk-closing/:id', getReportCashDeskClosingForId);
router.post('/report-cash-desk-closing-for-cash-desk', readReportCashDeskClosingForCashDesk);

export default router;