import { Router } from "express";
import {
    getPricesForChannel,
} from '../controllers/customer-sales.controller.js';

const router = Router();

router.post('/customer-sales-for-channel', getPricesForChannel);

export default router;