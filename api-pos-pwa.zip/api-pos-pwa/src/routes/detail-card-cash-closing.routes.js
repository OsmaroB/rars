import { Router } from "express";
import {
    getDetailSubchannelCashClosing,
    getDetailSubchannelCashClosingForId,
    createDetailSubchannelCashClosing,
    updateDetailSubchannelCashClosing,
    statusDetailSubchannelCashClosing,
    readSubchannelCashClosingForCashRegister
} from '../controllers/detail-subchannel-cash-closing.controller.js';

const router = Router();

router.get('/detail-subchannel-cash-closing', getDetailSubchannelCashClosing);
router.post('/detail-subchannel-cash-closing', createDetailSubchannelCashClosing);
router.put('/detail-subchannel-cash-closing/:id', updateDetailSubchannelCashClosing);
router.put('/detail-subchannel-cash-closing-remove/:id', statusDetailSubchannelCashClosing);
router.get('/detail-subchannel-cash-closing/:id', getDetailSubchannelCashClosingForId);
router.post('/detail-subchannel-cash-closing-for-cash-desk-closing', readSubchannelCashClosingForCashRegister);

export default router;