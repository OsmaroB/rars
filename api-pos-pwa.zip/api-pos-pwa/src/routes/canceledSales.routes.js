import { Router } from "express";
import {
    getCanceledSales,
    getCanceledSaleForId,
    createCanceledSale,
    updateCanceledSale,
    statusCanceledSale
} from '../controllers/canceled-sales.controller.js';

const router = Router();

router.get('/canceled-sales', getCanceledSales);
router.post('/canceled-sales', createCanceledSale);
router.put('/canceled-sales/:id', updateCanceledSale);
router.put('/canceled-sales-remove/:id', statusCanceledSale);
router.get('/canceled-sales/:id', getCanceledSaleForId);

export default router;