import { Router } from "express";
import {
    getCodeAuthorizeds,
    getCodeAuthorizedsForId,
    createCodeAuthorized,
    updateCodeAuthorized,
    statusCodeAuthorized,
} from '../controllers/codeAuthorized.controller.js';

const router = Router();

router.get('/code-authorizations', getCodeAuthorizeds);
router.post('/code-authorizations', createCodeAuthorized);
router.put('/code-authorizations/:id', updateCodeAuthorized);
router.put('/code-authorizations-remove/:id', statusCodeAuthorized);
router.get('/code-authorizations/:id', getCodeAuthorizedsForId);

export default router;