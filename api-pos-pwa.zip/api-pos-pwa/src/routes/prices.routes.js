import { Router } from "express";
import {
    getPrices,
    updatePrice,
    createPrices,
    statusPrice
} from '../controllers/prices.controllers.js';

const router = Router();

router.get('/prices', getPrices);
router.post('/prices', createPrices);
router.put('/prices/:id', updatePrice);
router.put('/prices-remove/:id', statusPrice);

export default router;