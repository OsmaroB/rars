import { Router } from "express";
import {
    getSales,
    getSaleForId,
    createSale,
    updateSale,
    statusSale,
    getSalesForDateChannelAndCashRegister,
    getSalesForDatePaymentAndCashRegister,
    saleForCashDesk,
    getSalesForDate,
} from '../controllers/sales.controller.js';

const router = Router();

router.get('/sales', getSales);
router.post('/sales-for-date-channel-cashregister', getSalesForDateChannelAndCashRegister)
router.post('/sales-for-date-payment-cashregister', getSalesForDatePaymentAndCashRegister)
router.post('/sales', createSale);
router.post('/sales-for-date', getSalesForDate)
router.put('/sales/:id', updateSale);
router.put('/sales-remove/:id', statusSale);
router.get('/sales-desk/:cutX',saleForCashDesk);
router.get('/sales/:id', getSaleForId);


export default router;