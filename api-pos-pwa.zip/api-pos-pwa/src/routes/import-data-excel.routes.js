import { Router } from "express";
import {
    importDataModifiers,
    importDataModifierPrices,
    updateDataProducts,
    updateDataModifiers,
    deleteLogicProductsForChannelAndSubChannel,
    createProductsButtons
} from '../controllers/import-data-excel.controller.js';

const router = Router();

router.post('/import-excel-data-modifiers', importDataModifiers);
router.post('/import-excel-data-modifiers-prices', importDataModifierPrices);
// new import data
router.post('/update-data-excel-products', updateDataProducts)
router.post('/update-data-excel-modifiers', updateDataModifiers)
// 
router.post('/delete-prices-for-category-channel', deleteLogicProductsForChannelAndSubChannel);
router.post('/create-products-for-excel', createProductsButtons);
export default router;