import { Router } from "express";
import {
    getRecipeArticles,
    getRecipeArticleForId,
    updateRecipeArticle,
    createRecipeArticle,
    statusRecipeArticle
} from '../controllers/recipe-articles.controllers.js'

const router = Router();

router.get('/recipes-articles', getRecipeArticles);
router.post('/recipes-articles', createRecipeArticle);
router.put('/recipes-articles/:id', updateRecipeArticle);
router.put('/recipes-articles-remove/:id', statusRecipeArticle);
router.get('/recipes-articles/:id', getRecipeArticleForId);

export default router;