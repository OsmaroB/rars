import { Router } from "express";
import {
    createEmployee, 
    getEmployees, 
    updateEmployee, 
    statusEmployee,
    getEmployeeForId,
} from '../controllers/employees.controllers.js'

const router = Router();

/** 
 * @openapi
 * /employees:
 *  get:
 *    tags:
 *      - Employee
 *    summary: Get all elements
 *    description: Get all items in table
 *    responses:
 *      '200':
 *        description: A successful response
*/
router.get('/employees', getEmployees);
/**
 * @openapi
 * /employees:
 *  post:
 *      tags:
 *          - Employee
 *      summary: Register item in table with success structure
 *      description: use to create item in table
 *      responses:
 *          '200':
 *              description: A successful response
 *      requestBody:
 *          required: true
 *          content:
 *              application/json:
 *                  schema:
 *                      $ref: '#/components/schemas/CreateEmployeeInput'
 * 
 */
router.post('/employees', createEmployee);
/**
 * @openapi
 * /employees/1:
 *  put:
 *      tags:
 *          - Employee
 *      summary: Update element
 *      description: use to update item in table with success structure
 *      responses:
 *          '200':
 *              description: A successful response
 *      requestBody:
 *          required: true
 *          content:
 *              application/json:
 *                  schema:
 *                      $ref: '#/components/schemas/updateEmployeeInput'
 */
router.put('/employees/:id', updateEmployee);
/**
 * @openapi
 * /employees-remove/1:
 *  put:
 *      tags:
 *          - Employee
 *      summary: Remove logit item for status in table
 *      description: Update column status in table
 *      responses:
 *          '200':
 *              description: A successful response
 *      requestBody:
 *          required: true
 *          content:
 *              application/json:
 *                  schema:
 *                      $ref: '#/components/schemas/deleteEmployeeInput'
 * 
 */
router.put('/employees-remove/:id',statusEmployee);
/**
 * @openapi
 * /employees/1:
 *  get:
 *      tags:
 *          - Employee
 *      summary: Get element for Id
 *      description: Read element for id in table
 *      responses:
 *          '200':
 *              description: A successful response
 * 
 */
router.get('/employees/:id', getEmployeeForId);


export default router;