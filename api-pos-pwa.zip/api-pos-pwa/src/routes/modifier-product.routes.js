import { Router } from "express";
import {
    createModifierProduct,
    updateModifierProduct,
    getModifierProductForId,
    getModifierProducts,
    statusModifierProduct
} from '../controllers/modifier-products.controllers.js';

const router = Router();

router.get('/modifier-products', getModifierProducts);
router.post('/modifier-products', createModifierProduct);
router.put('/modifier-products/:id', updateModifierProduct);
router.put('/modifier-products-remove/:id', statusModifierProduct);
router.get('/modifier-products/:id', getModifierProductForId);

export default router;