import { Router } from "express";
import {
    getUsers,
    getUserForId,
    updateUser,
    createUser,
    statusUser,
    login,
    changePassword,
    createCodeAuthorization,
    getuserForCode,
    userRepeat
} from '../controllers/user.controllers.js'
import { authJwt } from "../middlewares/index.js";

const router = Router();

router.get('/users', [authJwt.verifyToken], getUsers);
router.post('/users', [authJwt.verifyToken], createUser);
router.post('/get-user-for-code', [authJwt.verifyToken], getuserForCode);
router.put('/users/:id', [authJwt.verifyToken], updateUser);
router.put('/add-code-authorization/:id', [authJwt.verifyToken], createCodeAuthorization);
router.put('/users-remove/:id', [authJwt.verifyToken], statusUser);
router.get('/users/:id', [authJwt.verifyToken], getUserForId);
router.post('/user-repeat', [authJwt.verifyToken], userRepeat);
router.post('/login', login);
router.put('/change-password/:id', [authJwt.verifyToken], changePassword);

export default router;