import { Router } from "express";
import {
    getCategoryButton,
    getCategoryButtonForId,
    createCategoryButton,
    updateCategoryButton,
    statusCategoryButton
} from '../controllers/category-buttons.controllers.js'

const router = Router();

router.get('/category-buttons', getCategoryButton);
router.post('/category-buttons', createCategoryButton);
router.put('/category-buttons/:id', updateCategoryButton);
router.put('/category-buttons-remove/:id', statusCategoryButton);
router.get('/category-buttons/:id', getCategoryButtonForId);

export default router;