import { Router } from "express";
import { 
    createSubchannel,
    getSubchannelForId,
    getSubchannels,
    statusSubchannel,
    updateSubchannel
} from '../controllers/subchannel.controllers.js';

const router = Router();

router.get('/subchannels', getSubchannels);
router.post('/subchannels', createSubchannel);
router.put('/subchannels/:id', updateSubchannel);
router.put('/subchannels-remove/:id', statusSubchannel);
router.get('/subchannels/:id', getSubchannelForId);

export default router;