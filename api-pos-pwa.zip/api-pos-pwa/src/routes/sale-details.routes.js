import { Router } from "express";
import {
    getSaleDetails,
    getSaleDetailForId,
    createSaleDetail,
    updateSaleDetail,
    getSaleDetailsForSaleID,
    getSaleDetailForSaleID
} from '../controllers/sale-details.controllers.js'

const router = Router();

router.get('/sale-details', getSaleDetails);
router.post('/sale-details', createSaleDetail);
router.post('/sale-details-for-sale', getSaleDetailsForSaleID);
router.put('/sale-details/:id', updateSaleDetail);
// router.put('/sale-details-remove/:id', statusSale);

router.get('/sale-details/:id', getSaleDetailForId);
router.post('/sale-details-for-saleID', getSaleDetailForSaleID)
export default router;