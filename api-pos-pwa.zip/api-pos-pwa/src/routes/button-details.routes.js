import { Router } from "express";
import {
    getButtonDetails,
    getButtonDetailForId,
    createButtonDetail,
    updateButtonDetail,
    statusButtonDetail
} from '../controllers/buttons-details.controllers.js';

const router = Router();

router.get('/button-details', getButtonDetails);
router.post('/button-details', createButtonDetail);
router.put('/button-details/:id', updateButtonDetail);
router.put('/button-details-remove/:id', statusButtonDetail);
router.get('/button-details/:id', getButtonDetailForId);

export default router;