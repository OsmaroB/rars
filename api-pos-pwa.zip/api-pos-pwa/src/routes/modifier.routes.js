import { Router } from "express";
import {
    createModifier,
    updateModifier,
    getModifiers,
    getModifierForId,
    statusModifier
} from '../controllers/modifiers.controllers.js';

const router = Router();

router.get('/modifiers', getModifiers);
router.post('/modifiers', createModifier);
router.put('/modifiers/:id', updateModifier);
router.put('/modifiers-remove/:id', statusModifier);
router.get('/modifiers/:id', getModifierForId);

export default router;