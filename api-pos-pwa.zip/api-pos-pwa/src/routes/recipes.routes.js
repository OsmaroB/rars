import { Router } from "express";
import {
    getRecipes,
    getRecipeForId,
    updateRecipe,
    createRecipe,
    statusRecipe
} from '../controllers/recipes.controllers.js'

const router = Router();

router.get('/recipes', getRecipes);
router.post('/recipes', createRecipe);
router.put('/recipes/:id', updateRecipe);
router.put('/recipes-remove/:id', statusRecipe);
router.get('/recipes/:id', getRecipeForId);

export default router;