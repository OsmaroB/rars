import { Router } from "express";
import {
    getChannels,
    getChannelsForId,
    createChannel,
    updateChannel,
    statusChannel
} from '../controllers/channels.controller.js';

const router = Router();

router.get('/channels', getChannels);
router.post('/channels', createChannel);
router.put('/channels/:id', updateChannel);
router.put('/channels-remove/:id', statusChannel);
router.get('/channels/:id', getChannelsForId);

export default router;