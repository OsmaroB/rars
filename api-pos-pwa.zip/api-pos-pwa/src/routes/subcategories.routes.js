import { Router } from "express";
import { 
    getSubCategories,
    getSubCategoryForId,
    createSubCategory,
    updateSubCategory,
    statusSubCategory
} from '../controllers/subcategories.controllers.js';

const router = Router();

router.get('/subcategories', getSubCategories);
router.post('/subcategories', createSubCategory);
router.put('/subcategories/:id', updateSubCategory);
router.put('/subcategories-remove/:id', statusSubCategory);
router.get('/subcategories/:id', getSubCategoryForId);

export default router;