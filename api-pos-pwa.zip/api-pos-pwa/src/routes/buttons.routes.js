import { Router } from "express";
import { 
    createButtons, 
    getButtonForId, 
    getButtons, 
    statusButton, 
    updateButton 
} from '../controllers/buttons.controllers.js';

const router = Router();

router.get('/buttons', getButtons);
router.post('/buttons', createButtons);
router.put('/buttons/:id', updateButton);
router.put('/buttons-remove/:id', statusButton);
router.get('/buttons/:id', getButtonForId);

export default router;