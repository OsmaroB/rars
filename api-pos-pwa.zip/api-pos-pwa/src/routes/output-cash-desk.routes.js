import { Router } from "express";
import {
    getOutputCashDesk,
    getOutputCashDeskForId,
    createOutputCashDesk,
    updateOutputCashDesk,
    statusOutputCashDesk,
    getOutputCashDeskForCut,
    getOutputCashDeskForCutAndStatus,
} from '../controllers/output-cash-desk.controller.js';

const router = Router();

router.get('/output-cash-desk', getOutputCashDesk);
router.post('/output-cash-desk-for-cut', getOutputCashDeskForCut);
router.post('/output-cash-desk-for-cut-and-status', getOutputCashDeskForCutAndStatus);
router.post('/output-cash-desk', createOutputCashDesk);
router.put('/output-cash-desk/:id', updateOutputCashDesk);
router.put('/output-cash-desk-remove/:id', statusOutputCashDesk);
router.get('/output-cash-desk/:id', getOutputCashDeskForId);

export default router;