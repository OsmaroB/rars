import { Router } from "express";
import {
    getDocumentTypes,
    getDocumentTypeForId,
    createDocumentType,
    updateDocumentType,
    statusDocument
} from '../controllers/document-types.controllers.js';

const router = Router();

router.get('/document-types', getDocumentTypes);
router.post('/document-types', createDocumentType);
router.put('/document-types/:id', updateDocumentType);
router.put('/document-types-remove/:id', statusDocument);
router.get('/document-types/:id', getDocumentTypeForId);

export default router;