import { Router } from "express";
import {
    getRoles,
    getRoleForId,
    createRole,
    updateRole,
    statusRole,
} from '../controllers/roles.controllers.js'

const router = Router();

router.get('/roles', getRoles);
router.post('/roles', createRole);
router.put('/roles/:id', updateRole);
router.put('/roles-remove/:id',statusRole);
router.get('/roles/:id', getRoleForId);

export default router;