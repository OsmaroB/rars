import { Router } from "express";
import {
    printCanceledSale,
    printCutX,
    printReportCut,
    printTiket,
    printCutZ,
    printOutputCash
} from '../controllers/prints.controller.js';

const router = Router();

router.post('/print-tiket', printTiket);
router.post('/print-output-cash', printOutputCash);
router.post('/print-canceled-sale', printCanceledSale);
router.post('/print-report-cut', printReportCut);
router.post('/print-cut-x', printCutX);
router.post('/print-cut-z', printCutZ);

export default router;