import { Router } from "express";
import {
    createDepmodifier,
    updateDepmodifier,
    getDepmodifiers,
    getDepmodifierForId,
    statusDepmodifier,
} from '../controllers/depmodifier.controller.js';

const router = Router();

router.get('/depmodifiers', getDepmodifiers);
router.post('/depmodifiers', createDepmodifier);
router.put('/depmodifiers/:id', updateDepmodifier);
router.put('/depmodifiers-remove/:id', statusDepmodifier);
router.get('/depmodifiers/:id', getDepmodifierForId);

export default router;