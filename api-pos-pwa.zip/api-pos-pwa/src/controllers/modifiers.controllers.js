
import { Modifiers } from '../models/Modifiers.js';
import {maskText} from '../global/mask.js';

export const getModifiers = async (req, res) => {
    try {
        const modifiers = await Modifiers.findAll();
        res.json(modifiers);
    } catch (error) {
        return res.status(500).json({message: error.message})
    }
};

export const getModifierForId = async (req, res) => {
    try {
        const {id} = req.params;
        const modifier = await Modifiers.findByPk(id);
        res.json(modifier);
    } catch (error) {
        return res.status(500).json({message: error.message})
    }
};

export const createModifier = async (req, res) => {
    const {mask, name, status, userCreate} = req.body;
    if(!name || status == undefined) return res.sendStatus(400);
    try {
        const newModifier = await Modifiers.create({
            mask,
            name,
            status,
            userCreate
        });
        const modifier = await Modifiers.findByPk(newModifier.id);
        modifier.mask = maskText('MOD', newModifier.id);
        await modifier.save();
        res.status(200).json(modifier);
    } catch (error) {
        return res.status(500).json({message: error.message});
    }
};

export const updateModifier = async (req, res) => {
    try {
        const {id} = req.params;
        const {name, userUpdate} = req.body;
        if(!name || !id) return res.sendStatus(400);

        const modifier = await Modifiers.findByPk(id);
        modifier.name = name;
        modifier.userUpdate = userUpdate;
        await modifier.save();
        res.json(modifier);
    } catch (error) {
        return res.status(500).json({message: error.message});
    }
};

export const statusModifier = async (req, res) => {
    try {
        const {id} = req.params;
        const {status} = req.body;
        const modifier = await Modifiers.findByPk(id);
        modifier.status = status;
        await modifier.save();
        res.json(modifier);
    } catch (error) {
        return res.status(500).json({message: error.message});
    }
};