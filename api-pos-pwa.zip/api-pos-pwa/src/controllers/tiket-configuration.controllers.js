import { TiketConfiguration } from "../models/TiketConfiguration.js";

export const getTiketConfiguration = async (req, res) => {
    try {
        const configuration = await TiketConfiguration.findAll();
        res.status(200).json(configuration);

    } catch (error) {
        return res.status(500).json({message: error.message})
    }
};


export const createTiketConfiguration = async (req, res) => {
    const {
        enterprise,
        nit,
        item,
        address,
        resolution,
        serie,
        authorizationDate,
        cashRegisterNumber,
        link,
        paragraph1,
        paragraph2,
        userCreate
    } = req.body;
    try {
        const newConfiguration = await TiketConfiguration.create({
            enterprise,
            nit,
            item,
            address,
            resolution,
            serie,
            authorizationDate,
            cashRegisterNumber,
            link,
            paragraph1,
            paragraph2,
            userCreate
        });
        res.status(200).json(newConfiguration);
    } catch (error) {
        return res.status(500).json({message: error.message});
    }
};

export const updateTiketConfiguration = async (req, res) => {
    try {
        const {id} = req.params;
        const {
            enterprise,
            nit,
            item,
            address,
            resolution,
            serie,
            authorizationDate,
            cashRegisterNumber,
            link,
            paragraph1,
            paragraph2,
            userUpdate
        } = req.body;
        const configuration = await TiketConfiguration.findByPk(id);
        configuration.enterprise = enterprise;
        configuration.nit = nit;
        configuration.item = item;
        configuration.address = address;
        configuration.resolution = resolution;
        configuration.serie = serie;
        configuration.authorizationDate = authorizationDate;
        configuration.cashRegisterNumber = cashRegisterNumber;
        configuration.link = link;
        configuration.paragraph1 = paragraph1;
        configuration.paragraph2 = paragraph2;
        configuration.userUpdate = userUpdate;
        await configuration.save();
        res.json(configuration);
    } catch (error) {
        console.log(error);
        return res.status(500).json({message: error.message});
    }
};
