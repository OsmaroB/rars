import {Articles} from '../models/Articles.js'
import {maskText} from '../global/mask.js';

export const getArticles = async (req, res) => {
    try {
        const articles = await Articles.findAll();
        res.json(articles);
    } catch (error) {
        return res.status(500).json({message: error.message})
    }
};

export const getArticleForId = async (req, res) => {
    try {
        const {id} = req.params;
        const article = await Articles.findByPk(id);
        res.json(article);
    } catch (error) {
        return res.status(500).json({message: error.message})
    }
};

export const createArticle = async (req, res) => {
    const {
        mask,
        name,
        purchasing_unit,
        quantity_purchasing_unit,
        sales_unit,
        quantity_sales_unit,
        stock,
        status,
        userCreate
    } = req.body;
    try {
        const newArticle = await Articles.create({
            mask,
            name,
            purchasing_unit,
            quantity_purchasing_unit,
            sales_unit,
            quantity_sales_unit,
            stock,
            status,
            userCreate
        });
        const article = await Articles.findByPk(newArticle.id);
        article.mask = maskText('ART', newArticle.id);
        await article.save();
        res.status(200).json(article);
    } catch (error) {
        return res.status(500).json({message: error.message});
    }
};

export const updateArticle = async (req, res) => {
    try {
        const {id} = req.params;
        const {
            mask,
            name,
            purchasing_unit,
            quantity_purchasing_unit,
            sales_unit,
            quantity_sales_unit,
            stock,
            userUpdate
        } = req.body;
        const article = await Articles.findByPk(id);
        article.mask = mask;
        article.name = name;
        article.purchasing_unit = purchasing_unit;
        article.quantity_purchasing_unit = quantity_purchasing_unit;
        article.sales_unit = sales_unit;
        article.quantity_sales_unit = quantity_sales_unit;
        article.stock = stock;
        article.userUpdate = userUpdate;
        await article.save();
        res.json(article);
    } catch (error) {
        return res.status(500).json({message: error.message});
    }
};

export const statusArticle = async (req, res) => {
    try {
        const {id} = req.params;
        const {status} = req.body;
        const article = await Articles.findByPk(id);
        article.status = status;
        await article.save();
        res.json(article);
    } catch (error) {
        return res.status(500).json({message: error.message});
    }
};