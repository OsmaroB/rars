import {Optionals} from '../models/Optionals.js';
import {Products} from '../models/Products.js'
import { OptionalProducts } from '../models/OptionalProducts.js';

export const getOptionalProducts = async (req, res) => {
    try {
        const optionalProducts = await OptionalProducts.findAll({
            include:[
                {model: Optionals},{model: Products}
            ]
        });
        res.json(optionalProducts);
    } catch (error) {
        return res.status(500).json({message: error.message})
    }
};

export const getOptionalProductForId = async (req, res) => {
    try {
        const {id} = req.params;
        const optionalProduct = await OptionalProducts.findOne({
            where:{
                id
            },
            include:[
                {model: Optionals},{model: Products}
            ]
        });
        res.json(optionalProduct);
    } catch (error) {
        return res.status(500).json({message: error.message});
    }
};

export const createOptionalProduct = async (req, res) => {
    const {
        status,
        userCreate,
        productID,
        optionalID
    } = req.body;
    try {
        const newOptionalProduct = await OptionalProducts.create({
            status,
            userCreate,
            productID,
            optionalID
        });
        res.status(200).json(newOptionalProduct);
    } catch (error) {
        return res.status(500).json({message: error.message});
    }
};

export const updateOptionalProduct = async (req, res) => {
    try {
        const {id} = req.params;
        const {
            productID,
            optionalID,
            userUpdate
        } = req.body;
        const optionalProduct = await OptionalProducts.findByPk(id);
        optionalProduct.productID = productID;
        optionalProduct.optionalID = optionalID;
        optionalProduct.userUpdate = userUpdate;
        await optionalProduct.save();
        res.json(optionalProduct);
    } catch (error) {
        return res.status(500).json({message: error.message});
    }
};

export const statusOptionalProduct = async (req, res) => {
    try {
        const {id} = req.params;
        const {status} = req.body;
        const optionalProduct = await OptionalProducts.findByPk(id);
        optionalProduct.status = status;
        await optionalProduct.save();
        res.json(optionalProduct);
    } catch (error) {
        return res.status(500).json({message: error.message});
    }
};