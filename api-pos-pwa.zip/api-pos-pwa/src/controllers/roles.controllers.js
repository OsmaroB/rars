import {Role} from '../models/Role.js';
import {maskText} from '../global/mask.js';


export const getRoles = async (req, res) => {
    try {
        const roles = await Role.findAll();
        res.json(roles);
    } catch (error) {
        return res.status(500).json({message: error.message})
    }
};

export const getRoleForId = async (req, res) => {
    try {
        const {id} = req.params;
        const role = await Role.findByPk(id);
        res.json(role);
    } catch (error) {
        return res.status(500).json({message: error.message})
    }
};

export const createRole = async (req, res) => {
    const {mask, name, description, status, userCreate} = req.body;
    try {
        const newRole = await Role.create({
            mask,
            name,
            description,
            status,
            userCreate
        });
        const role = await Role.findByPk(newRole.id);
        role.mask = maskText('ROL', newRole.id);
        await role.save();
        res.status(200).json(role);
    } catch (error) {
        return res.status(500).json({message: error.message});
    }
};

export const updateRole = async (req, res) => {
    try {
        const {id} = req.params;
        const {mask, name, description, userUpdate} = req.body;

        const role = await Role.findByPk(id);
        role.mask = mask;
        role.name = name;
        role.description = description;
        role.userUpdate = userUpdate;
        await role.save();
        res.json(role);
    } catch (error) {
        return res.status(500).json({message: error.message});
    }
};

export const statusRole = async (req, res) => {
    try {
        const {id} = req.params;
        const {status} = req.body;
        const role = await Role.findByPk(id);
        role.status = status;
        await role.save();
        res.json(role);
    } catch (error) {
        return res.status(500).json({message: error.message});
    }
};