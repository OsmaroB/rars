import { Prices } from '../models/Prices.js';
import { ButtonDetails } from '../models/ButtonDetails.js';
import { ChannelsSubchannels } from '../models/ChannelsSubchannels.js';
import { Subchannel } from '../models/Subchannel.js';
import { OptionalProducts } from '../models/OptionalProducts.js';
import { Products } from '../models/Products.js';
import { Buttons } from '../models/Buttons.js';
import { Optionals } from '../models/Optionals.js';
import { ModifierProducts } from '../models/ModifierProducts.js';
import { Modifiers } from '../models/Modifiers.js'; 
import {Categories} from '../models/Categories.js';
import { ButtonCategories } from '../models/ButtonCategories.js';
import { Submodifiers } from '../models/Submodifiers.js';
import { Depmodifiers } from '../models/DepModifiers.js';
import { Discounts } from '../models/Discounts.js';

export const getPrices = async (req, res) => {
    try {
        const prices = await Prices.findAll({
            include:[
                { model: ButtonDetails, 
                    include:[
                        {model: Products},
                        {model: Buttons,
                            include:[
                                {model:ButtonCategories,
                                    include:[
                                        {model:Categories}
                                    ]
                                }
                            ]
                        }
                    ] 
                },
                { model: ChannelsSubchannels },
                { model: Subchannel,
                    include:[{model: ChannelsSubchannels}]    
                },
                { model: OptionalProducts, 
                    include:[
                        {model: Optionals}, 
                        {model: Products}
                    ] 
                },
                {   model: ModifierProducts,
                    include:[
                        {model: Modifiers},
                        {model: Products},
                        {model: Submodifiers},
                        {model: Depmodifiers},
                    ]
                },{
                    model: Discounts,
                }

            ]
        });
        res.json(prices);
    } catch (error) {
        return res.status(500).json({
            message: error
        });
    }
};

export const createPrices = async (req, res) => {
    let {
        price,
        status,
        userCreate,
        buttonDetailID,
        channelID,
        subchannelID,
        optionalProductID,
        modifierProductID
    } = req.body;
    if(buttonDetailID == ''){
        buttonDetailID = null;
    }
    if(channelID == ''){
        channelID = null;
    }
    if(subchannelID == ''){
        subchannelID = null;
    }
    if(optionalProductID == ''){
        optionalProductID = null;
    }
    if(modifierProductID == ''){
        modifierProductID = null;
    }
    try {
        const newPrice = await Prices.create({
            price,
            status,
            userCreate,
            buttonDetailID,
            channelID,
            subchannelID,
            optionalProductID,
            modifierProductID
        });
        res.status(200).json(newPrice);
    } catch (error) {
        console.log(error);
        return res.json({
            message: error
        })
    }
};

export const updatePrice = async (req, res) => {
    try {
        const {id} = req.params;
        let {
            price,
            userUpdate,
            buttonDetailID,
            channelID,
            subchannelID,
            optionalProductID,
            modifierProductID
        } = req.body;
        if(buttonDetailID == ''){
            buttonDetailID = null;
        }
        if(channelID == ''){
            channelID = null;
        }
        if(subchannelID == ''){
            subchannelID = null;
        }
        if(optionalProductID == ''){
            optionalProductID = null;
        }
        if(modifierProductID == ''){
            modifierProductID = null;
        }
        const updatePrice = await Prices.findByPk(id);
        updatePrice.price = price;
        updatePrice.userUpdate = userUpdate;
        updatePrice.buttonDetailID = buttonDetailID;
        updatePrice.channelID = channelID;
        updatePrice.subchannelID = subchannelID;
        updatePrice.optionalProductID = optionalProductID;
        updatePrice.modifierProductID = modifierProductID
        await updatePrice.save();
        res.json(updatePrice);
    } catch (error) {
        return res.status(500).json({
            message: error
        })
    }
};

export const statusPrice = async (req, res) => {
    try {
        const {id} = req.params;
        const {status} = req.body;
        const price = await Prices.findByPk(id);
        price.status = status;
        await updatePrice.save(); 
    } catch (error) {
        return res.status(500).json({
            message: error
        });
    }
};