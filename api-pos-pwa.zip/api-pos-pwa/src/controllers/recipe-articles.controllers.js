import {RecipeArticles} from '../models/RecipeArticles.js'
import {Articles} from '../models/Articles.js'
import {Recipes} from '../models/Recipes.js'
import Sequelize from 'sequelize';
import {maskText} from '../global/mask.js';


export const getRecipeArticles = async (req, res) => {
    try {
        const recipesArticles = await RecipeArticles.findAll({
            include: [
                {model: Articles},{model: Recipes}
            ]
        });
        res.json(recipesArticles);
    } catch (error) {
        return res.status(500).json({message: error.message})
    }
};

export const getRecipeArticleForId = async (req, res) => {
    try {
        const {id} = req.params;
        const recipeArticle = await RecipeArticles.findOne({
            where:{
                id
            },
            include: [
                {model: Articles},{model: Recipes}
            ]
        });
        res.json(recipeArticle); 
    } catch (error) {
        return res.status(500).json({message: error.message})
    }
};

export const createRecipeArticle = async (req, res) => {
    const {
        quantity,
        status,
        articleID,
        recipeID,
        userCreate
    } = req.body;
    try {
        const newRecipeArticle = await RecipeArticles.create({
            quantity,
            status,
            articleID,
            recipeID,
            userCreate
        });
        const recipeArticle = await RecipeArticles.findByPk(newRecipeArticle.id);
        recipeArticle.mask = maskText('DRA', newRecipeArticle.id);
        await recipeArticle.save();
        res.status(200).json(recipeArticle);
    } catch (error) {
        console.log(error);
        return res.status(500).json({message: error.message});
    }
};

export const updateRecipeArticle = async (req, res) => {
    try {
        const {id} = req.params;
        const {
            quantity,
            articleID,
            recipeID,
            userUpdate
        } = req.body;
        const recipeArticle = await RecipeArticles.findByPk(id);
        recipeArticle.quantity = quantity;
        recipeArticle.articleID = articleID;
        recipeArticle.recipeID = recipeID;
        recipeArticle.userUpdate = userUpdate;
        await recipeArticle.save();
        res.json(recipeArticle);
    } catch (error) {
        return res.status(500).json({message: error.message});
    }
};

export const statusRecipeArticle = async (req, res) => {
    try {
        const {id} = req.params;
        const {status} = req.body;
        const recipeArticle = await RecipeArticles.findByPk(id);
        recipeArticle.status = status;
        await recipeArticle.save();
        res.json(recipeArticle);
    } catch (error) {
        return res.status(500).json({message: error.message});
    }
};