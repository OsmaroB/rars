import {OutputCashDesk} from '../models/OutputCashDesk.js';
import {CashDeskClosing} from '../models/CashDeskClosing.js';
import { User } from '../models/User.js';

export const getOutputCashDesk = async (req, res) => {
    try {
        const outputCashDesk = await OutputCashDesk.findAll({
            include:[
                {model: User},
                {model: CashDeskClosing}
            ]
        });
        res.json(outputCashDesk);
    } catch (error) {
        return res.status(500).json({message: error.message})
    }
};

export const getOutputCashDeskForCut = async (req, res) => {
    try {
        const {
            cashDeskClosingID, 
        } = req.body;
        const outputCashDesk = await OutputCashDesk.findAll({
            include:[
                {model: User},
                {model: CashDeskClosing}
            ],
            where:{
                cashDeskClosingID,
            }
        });
        res.json(outputCashDesk);
    } catch (error) {
        return res.status(500).json({message: error.message})
    }
};

export const getOutputCashDeskForCutAndStatus = async (req, res) => {
    try {
        const {
            cashDeskClosingID, 
            status
        } = req.body;
        const outputCashDesk = await OutputCashDesk.findAll({
            include:[
                {model: User},
                {model: CashDeskClosing}
            ],
            where:{
                cashDeskClosingID,
                status,
            }
        });
        res.json(outputCashDesk);
    } catch (error) {
        return res.status(500).json({message: error.message})
    }
};

export const getOutputCashDeskForId = async (req, res) => {
    try {
        const {id} = req.params;
        const outputCashDesk = await OutputCashDesk.findOne({
            include:[
                {model: User},
                {model: CashDeskClosing}
            ],
            where:{
                id
            },
        });
        res.json(outputCashDesk);
    } catch (error) {
        return res.status(500).json({message: error.message});
    }
};

export const createOutputCashDesk = async (req, res) => {
    const {
        output,
        description,
        cashDeskClosingID,
        userID,
        status,
        userCreate,
        userAproved
    } = req.body;
    try {
        const newOutputCashDesk = await OutputCashDesk.create({
            output,
            description,
            cashDeskClosingID,
            userID,
            status,
            userCreate,
            userAproved
        });
        res.status(200).json(newOutputCashDesk);
    } catch (error) {
        return res.status(500).json({message: error.message});
    }
};

export const updateOutputCashDesk = async (req, res) => {
    try {
        const {id} = req.params;
        const {
            output,
            description,
            cashDeskClosingID,
            userID,
            status,
            userUpdate
        } = req.body;
        const outputCashDesk = await OutputCashDesk.findByPk(id);
        outputCashDesk.output = output;
        outputCashDesk.description = description;
        outputCashDesk.cashDeskClosingID = cashDeskClosingID;
        outputCashDesk.userID = userID;
        outputCashDesk.status = status;
        outputCashDesk.userUpdate = userUpdate;
        await outputCashDesk.save();
        res.json(outputCashDesk);
    } catch (error) {
        return res.status(500).json({message: error.message});
    }
};

export const statusOutputCashDesk = async (req, res) => {
    try {
        const {id} = req.params;
        const {status} = req.body;
        const outputCashDesk = await OutputCashDesk.findByPk(id);
        outputCashDesk.status = status;
        await outputCashDesk.save();
        res.json(outputCashDesk);
    } catch (error) {
        return res.status(500).json({message: error.message});
    }
};