import {Recipes} from '../models/Recipes.js';
import {maskText} from '../global/mask.js';

export const getRecipes = async (req, res) => {
    try {
        const recipes = await Recipes.findAll();
        res.json(recipes);
    } catch (error) {
        return res.status(500).json({message: error.message})
    }
};

export const getRecipeForId = async (req, res) => {
    try {
        const {id} = req.params;
        const recipe = await Recipes.findByPk(id);
        res.json(recipe);
    } catch (error) {
        return res.status(500).json({message: error.message})
    }
};

export const createRecipe = async (req, res) => {
    const {
        mask,
        name,
        status,
        userCreate
    } = req.body;
    try {
        const newRecipe = await Recipes.create({
            mask,
            name,
            status,
            userCreate
        });
        const recipe = await Recipes.findByPk(newRecipe.id);
        recipe.mask = maskText('REC', newRecipe.id);
        await recipe.save();
        res.status(200).json(recipe);
    } catch (error) {
        return res.status(500).json({message: error.message});
    }
};

export const updateRecipe = async (req, res) => {
    try {
        const {id} = req.params;
        const {
            mask,
            name,
            status,
            userUpdate
        } = req.body;
        const recipe = await Recipes.findByPk(id);
        recipe.mask = mask;
        recipe.name = name;
        recipe.status = status;
        recipe.userUpdate = userUpdate;
        await recipe.save();
        res.json(recipe);
    } catch (error) {
        return res.status(500).json({message: error.message});
    }
};

export const statusRecipe = async (req, res) => {
    try {
        const {id} = req.params;
        const {status} = req.body;
        const recipe = await Recipes.findByPk(id);
        recipe.status = status;
        await recipe.save();
        res.json(recipe);
    } catch (error) {
        return res.status(500).json({message: error.message});
    }
};