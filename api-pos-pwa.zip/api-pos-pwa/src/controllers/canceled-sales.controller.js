import {Sales} from '../models/Sales.js';
import { CanceledSales } from '../models/CanceledSales.js';
import {maskText} from '../global/mask.js';


export const getCanceledSales = async (req, res) => {
    try {
        const sales = await CanceledSales.findAll({
            include:[
                {model: Sales},
            ]
        });
        res.json(sales);
    } catch (error) {
        return res.status(500).json({message: error.message})
    }
};

export const getCanceledSaleForId = async (req, res) => {
    try {
        const {id} = req.params;
        const sales = await CanceledSales.findByPk(id);
        res.json(sales);
    } catch (error) {
        return res.status(500).json({message: error.message})
    }
};

export const createCanceledSale = async (req, res) => {
    const {
        tiketNumber,
        cashRegisterNumber,
        restaurant,
        channel,
        paymentMethod,
        date,
        hour,
        totalWithoutTax,
        totalDiscount,
        totalWithDiscount,
        tax,
        totalWithTax,
        tip,
        status,
        saleID,
        userCreate, 
    } = req.body;
    try {
        const newSale = await CanceledSales.create({
            tiketNumber,
            cashRegisterNumber,
            restaurant,
            channel,
            paymentMethod,
            date,
            hour,
            totalWithoutTax,
            totalDiscount,
            totalWithDiscount,
            tax,
            totalWithTax,
            tip,
            status,
            saleID,
            userCreate
        });
        res.status(200).json(newSale);
    } catch (error) {
        return res.status(500).json({message: error.message});
    }
};

export const updateCanceledSale = async (req, res) => {
    try {
        const {id} = req.params;
        const {
            tiketNumber,
            cashRegisterNumber,
            restaurant,
            channel,
            paymentMethod,
            date,
            hour,
            totalWithoutTax,
            totalDiscount,
            totalWithDiscount,
            tax,
            totalWithTax,
            tip,
            saleID,
            userUpdate
        } = req.body;

        const sale = await CanceledSales.findByPk(id);
        sale.tiketNumber = tiketNumber;
        sale.cashRegisterNumber = cashRegisterNumber
        sale.restaurant = restaurant;
        sale.channel = channel;
        sale.paymentMethod = paymentMethod;
        sale.date = date;
        sale.hour = hour;
        sale.totalWithoutTax = totalWithoutTax;
        sale.totalDiscount = totalDiscount;
        sale.totalWithDiscount = totalWithDiscount;
        sale.tax = tax;
        sale.totalWithTax = totalWithTax;
        sale.tip = tip;
        sale.saleID = saleID;
        sale.userUpdate = userUpdate;
        await sale.save();
        res.json(sale);
    } catch (error) {
        return res.status(500).json({message: error.message});
    }
};

export const statusCanceledSale = async (req, res) => {
    try {
        const {id} = req.params;
        const {status} = req.body;
        const sale = await CanceledSales.findByPk(id);
        sale.status = status;
        await sale.save();
        res.json(sale);
    } catch (error) {
        return res.status(500).json({message: error.message});
    }
};