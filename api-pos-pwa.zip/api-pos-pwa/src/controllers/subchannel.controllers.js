import { Subchannel } from '../models/Subchannel.js';
import {ChannelsSubchannels} from '../models/ChannelsSubchannels.js'
import {maskText} from '../global/mask.js';


export const getSubchannels = async (req, res) => {
    try {
        const subchannels = await Subchannel.findAll({
            include:[
                {model: ChannelsSubchannels}
            ]
        });
        res.json(subchannels);
    } catch (error) {
        return res.status(500).json({message: error.message})
    }
};

export const getSubchannelForId = async (req, res) => {
    try {
        const {id} = req.params;
        const subchannel = await Subchannel.findByPk(id);
        res.json(subchannel);
    } catch (error) {
        return res.status(500).json({message: error.message})
    }
};

export const createSubchannel = async (req, res) => {
    const {mask, name, description, status, userCreate, channelID} = req.body;
    try {
        const newSubchannel = await Subchannel.create({
            mask,
            name,
            description,
            status,
            channelID,
            userCreate
        });
        const subchannel = await Subchannel.findByPk(newSubchannel.id);
        subchannel.mask = maskText('SB', newSubchannel.id);
        await subchannel.save();
        res.status(200).json(subchannel);
    } catch (error) {
        console.log(error);
        return res.status(500).json({message: error.message});
    }
};

export const updateSubchannel = async (req, res) => {
    try {
        const {id} = req.params;
        const {mask, name, description, userUpdate, channelID} = req.body;

        const subchannel = await Subchannel.findByPk(id);
        subchannel.mask = mask;
        subchannel.name = name;
        subchannel.channelID = channelID
        subchannel.description = description;
        subchannel.userUpdate = userUpdate;
        await subchannel.save();
        res.json(subchannel);
    } catch (error) {
        return res.status(500).json({message: error.message});
    }
};

export const statusSubchannel = async (req, res) => {
    try {
        const {id} = req.params;
        const {status} = req.body;
        const subchannel = await Subchannel.findByPk(id);
        subchannel.status = status;
        await subchannel.save();
        res.json(subchannel);
    } catch (error) {
        return res.status(500).json({message: error.message});
    }
};