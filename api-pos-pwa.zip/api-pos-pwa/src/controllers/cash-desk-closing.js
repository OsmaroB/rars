import {CashDeskClosing} from '../models/CashDeskClosing.js';
import {maskText} from '../global/mask.js';
import { User } from '../models/User.js';

export const getCashDeskClosing = async (req, res) => {
    try {
        const cashDeskClosing = await CashDeskClosing.findAll({
            include:[
                {model: User}
            ]
        });
        res.json(cashDeskClosing);
    } catch (error) {
        return res.status(500).json({message: error.message})
    }
};

export const getCashDeskClosingForTypeDate = async (req, res) =>{
    try {
        const {
            date,
            type,
            cashRegister
        } = req.body;
        const cashDeskClosing = await CashDeskClosing.findAll({
            include:[
                {model: User}
            ],
            where:{
                date,
                cashRegister,
                type
            },
        });
        res.json(cashDeskClosing);
    } catch (error) {
        return res.status(500).json({message: error.message});
    }
};

export const readCashDeskClosingForDateCashDeskStatus = async (req,res) =>{
    try {
        const {
            date,
            cashRegister,
            status,
        } = req.body;
        const cashDeskClosing = await CashDeskClosing.findAll({
            include:[
                {model: User}
            ],
            where:{
                date,
                cashRegister,
                status,
            },
        });
        res.json(cashDeskClosing); 
    } catch (error) {
        console.log(error);
        return res.status(500).json({message: error.message});
    }
};

export const getCashDeskClosingForId = async (req, res) => {
    try {
        const {id} = req.params;
        const cashDeskClosing = await CashDeskClosing.findOne({
            include:[
                {model: User}
            ],
            where:{
                id
            },
        });
        res.json(cashDeskClosing);
    } catch (error) {
        return res.status(500).json({message: error.message});
    }
};

export const createCashDeskClosing = async (req, res) => {
    const {
        mask,
        date,
        cash,
        hour,
        type,
        status,
        prettyCash,
        cashRegister,
        userID,
        userCreate,
        userAproved
    } = req.body;
    try {
        const newcashDeskClosing = await CashDeskClosing.create({
            mask,
            date,
            cash,
            hour,
            type,
            status,
            prettyCash,
            cashRegister,
            userID,
            userCreate,
            userAproved
        });
        const cashDeskClosing = await CashDeskClosing.findByPk(newcashDeskClosing.id);
        cashDeskClosing.mask = maskText('CDC', newcashDeskClosing.id);
        await cashDeskClosing.save();
        res.status(200).json(cashDeskClosing);
    } catch (error) {
        return res.status(500).json({message: error.message});
    }
};

export const startCashDeskClosingX = async (req, res) => {
    const {
        prettyCash,
        date,
        cashRegister,
        userID,
        userCreate
    } = req.body;
    try {
        const newcashDeskClosing = await CashDeskClosing.create({
            type:0,
            date,
            status:0,
            prettyCash,
            cashRegister,
            userID,
            userCreate
        });
        const cashDeskClosing = await CashDeskClosing.findByPk(newcashDeskClosing.id);
        cashDeskClosing.mask = maskText('CDC', newcashDeskClosing.id);
        await cashDeskClosing.save();
        res.status(200).json(cashDeskClosing);
    } catch (error) {
        return res.status(500).json({message: error.message});
    }
};

export const updatePrettyCashCashDeskClosing = async (req,res) =>{
    try {
        const {id} = req.params;
        const {
            prettyCash,
        } = req.body;
        const cashDeskClosing = await CashDeskClosing.findByPk(id);
        cashDeskClosing.prettyCash = prettyCash;
        await cashDeskClosing.save();
        res.json(cashDeskClosing);
    } catch (error) {
        return res.status(500).json({message: error.message});
    }
}
export const updateCashCashDeskClosing = async (req,res) =>{
    try {
        const {id} = req.params;
        const {
            cash,
        } = req.body;
        const cashDeskClosing = await CashDeskClosing.findByPk(id);
        cashDeskClosing.cash = cash;
        await cashDeskClosing.save();
        res.json(cashDeskClosing);
    } catch (error) {
        return res.status(500).json({message: error.message});
    }
}

export const updateCashDeskClosing = async (req, res) => {
    try {
        const {id} = req.params;
        const {
            hour,
            cash,
            status,
            userID,
            userUpdate,
            userAproved
        } = req.body;
        const cashDeskClosing = await CashDeskClosing.findByPk(id);
        cashDeskClosing.hour = hour;
        cashDeskClosing.cash = cash;
        cashDeskClosing.status = status;
        cashDeskClosing.userID = userID;
        cashDeskClosing.userUpdate = userUpdate;
        cashDeskClosing.userAproved=userAproved;
        await cashDeskClosing.save();
        res.json(cashDeskClosing);
    } catch (error) {
        return res.status(500).json({message: error.message});
    }
};

export const statusCashDeskClosing = async (req, res) => {
    try {
        const {id} = req.params;
        const {status} = req.body;
        const cashDeskClosing = await CashDeskClosing.findByPk(id);
        cashDeskClosing.status = status;
        await cashDeskClosing.save();
        res.json(cashDeskClosing);
    } catch (error) {
        return res.status(500).json({message: error.message});
    }
};