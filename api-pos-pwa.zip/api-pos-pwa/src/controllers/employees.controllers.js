import {Employee} from '../models/Employee.js';
import {maskText} from '../global/mask.js';

export const getEmployees = async (req, res) => {
    try {
        const employees = await Employee.findAll();
        res.json(employees);
    } catch (error) {
        return res.status(500).json({message: error.message})
    }
};

export const getEmployeeForId = async (req, res) => {
    try {
        const {id} = req.params;
        const employee = await Employee.findByPk(id);
        res.json(employee);
    } catch (error) {
        return res.status(500).json({message: error.message})
    }
};

export const createEmployee = async (req, res) => {
    const {mask, name, lastName, status, userCreate} = req.body;
    if(!name || !lastName || status == undefined) return res.sendStatus(400);
    try {
        const newEmployee = await Employee.create({
            mask,
            name,
            lastName,
            status,
            userCreate
        });
        const employee = await Employee.findByPk(newEmployee.id);
        employee.mask = maskText('EMP', newEmployee.id);
        await employee.save();
        res.status(200).json(employee);
    } catch (error) {
        return res.status(500).json({message: error.message});
    }
};

export const updateEmployee = async (req, res) => {
    try {
        const {id} = req.params;
        const {name, lastName, userUpdate} = req.body;
        if(!name || !lastName || !id) return res.sendStatus(400);

        const employee = await Employee.findByPk(id);
        employee.name = name;
        employee.lastName = lastName;
        employee.userUpdate = userUpdate;
        await employee.save();
        res.json(employee);
    } catch (error) {
        return res.status(500).json({message: error.message});
    }
};

export const statusEmployee = async (req, res) => {
    try {
        const {id} = req.params;
        const {status} = req.body;
        const employee = await Employee.findByPk(id);
        employee.status = status;
        await employee.save();
        res.json(employee);
    } catch (error) {
        return res.status(500).json({message: error.message});
    }
};
