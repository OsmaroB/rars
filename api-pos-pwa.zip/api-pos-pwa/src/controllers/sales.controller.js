import {User} from '../models/User.js';
import {Sales} from '../models/Sales.js';
import {Documents} from '../models/Documents.js';
import { DocumentTypes } from '../models/DocumentTypes.js';
import {Customers} from '../models/Customers.js';
import {maskText} from '../global/mask.js';
import { Op } from 'sequelize';


export const getSales = async (req, res) => {
    try {
        const sales = await Sales.findAll({
            include:[
                {model: User},
                {model: Documents,
                    include:[
                        {model: DocumentTypes}
                    ]
                },
                {model: Customers},
            ]
        });
        res.json(sales);
    } catch (error) {
        console.log(error);
        return res.status(500).json({message: error.message})
    }
};

export const getSalesForDate = async (req,res) => {
    try {
        const {
            date, 
        } = req.body;
        console.log(req.body);
        if(date == ''){
            res.status(500).json({message: 'No puedes dejar vacia la fecha'});
        }
        const sales = await Sales.findAll({
            where:{
                date:date,
            },
            include:[
                {model: Documents},
                {model: Customers},
                {model: User},
            ]
        });
        res.json(sales);  
    } catch (error) {
        return res.status(500).json({message: error})
    }
}

export const getSalesForDateChannelAndCashRegister = async (req,res) => {
    try {
        const {
            date, 
            channel,
            cutX,
            cashRegisterNumber,
        } = req.body;
        const sales = await Sales.findAll({
            where:{
                date:date,
                // channel:channel,
                cashRegisterNumber:cashRegisterNumber,
                cutX:cutX,
                channel:{
                    [Op.like]: `%${channel}%`
                }
            },
            include:[
                {model: Documents},
                {model: Customers},
                {model: User},
            ]

        });
        res.json(sales);
    } catch (error) {
        console.log(error);
        return res.status(500).json({message: error.message})
    }
};

export const getSalesForDatePaymentAndCashRegister = async (req,res) => {
    try {
        const {
            date, 
            paymentMethod,
            cashRegisterNumber,
            cutX,
        } = req.body;
        const sales = await Sales.findAll({
            where:{
                date:date,
                paymentMethod:paymentMethod,
                cashRegisterNumber:cashRegisterNumber,
                cutX:cutX,
            },
            include:[
                {model: Documents},
                {model: Customers},
                // {model: User},
            ]

        });
        res.json(sales);
    } catch (error) {
        console.log(error);
        return res.status(500).json({message: error.message})
    }
};

export const getSaleForId = async (req, res) => {
    try {
        const {id} = req.params;
        const sales = await Sales.findByPk(id);
        res.json(sales);
    } catch (error) {
        return res.status(500).json({message: error.message})
    }
};

export const createSale = async (req, res) => {
    const {
        mask, 
        tiketNumber,
        cashRegisterNumber,
        restaurant,
        channel,
        paymentMethod,
        date,
        hour,
        totalWithoutTax,
        totalDiscount,
        totalWithDiscount,
        tax,
        totalWithTax,
        tip,
        cutX,
        status,
        documentID,
        userID,
        customerID,
        userCreate, 
        channelID,
    } = req.body;
    console.log(userID);
    try {
        const newSale = await Sales.create({
            mask, 
            tiketNumber,
            cashRegisterNumber,
            restaurant,
            channel,
            paymentMethod,
            date,
            hour,
            totalWithoutTax,
            totalDiscount,
            totalWithDiscount,
            tax,
            totalWithTax,
            tip,
            cutX,
            status,
            documentID,
            userID,
            customerID,
            userCreate,
            channelID,
        });
        const sale = await Sales.findByPk(newSale.id);
        sale.mask = maskText('SALE', newSale.id);
        await sale.save();
        res.status(200).json(sale);
    } catch (error) {
        console.log(error);
        return res.status(500).json({message: error.message});
    }
};

export const updateSale = async (req, res) => {
    try {
        const {id} = req.params;
        const {
            mask, 
            tiketNumber,
            cashRegisterNumber,
            restaurant,
            channel,
            paymentMethod,
            date,
            hour,
            totalWithoutTax,
            totalDiscount,
            totalWithDiscount,
            tax,
            totalWithTax,
            tip,
            documentID,
            userID,
            customerID, 
            userUpdate,
            channelID,
        } = req.body;

        const sale = await Sales.findByPk(id);
        sale.mask = mask;
        sale.tiketNumber = tiketNumber;
        sale.cashRegisterNumber = cashRegisterNumber
        sale.restaurant = restaurant;
        sale.channel = channel;
        sale.paymentMethod = paymentMethod;
        sale.date = date;
        sale.hour = hour;
        sale.totalWithoutTax = totalWithoutTax;
        sale.totalDiscount = totalDiscount;
        sale.totalWithDiscount = totalWithDiscount;
        sale.tax = tax;
        sale.totalWithTax = totalWithTax;
        sale.tip = tip;
        sale.documentID = documentID;
        sale.userID = userID;
        sale.customerID = customerID;
        sale.userUpdate = userUpdate;
        sale.channelID = channelID;
        await sale.save();
        res.json(sale);
    } catch (error) {
        return res.status(500).json({message: error.message});
    }
};

export const saleForCashDesk=async(req,res)=>{
    try {
        const {cutX}=req.params;
        const sales=await Sales.findAll({
            where:{
                cutX:cutX,
            },
            include:[
                {model: User},
                {model: Documents,
                    include:[
                        {model: DocumentTypes}
                    ]
                },
                {model: Customers},
            ]
        })
        res.json(sales);
    } catch (error) {
        console.log(error);
        return res.status(500).json({message: error.message})
    }
}

export const statusSale = async (req, res) => {
    try {
        const {id} = req.params;
        const {status} = req.body;
        const {userAproved}=req.body;
        const sale = await Sales.findByPk(id);
        sale.status = status;
        sale.userAproved=userAproved;
        await sale.save();
        res.json(sale);
    } catch (error) {
        return res.status(500).json({message: error.message});
    }
};