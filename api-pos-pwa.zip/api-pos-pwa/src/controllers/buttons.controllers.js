import {Buttons} from '../models/Buttons.js'
import {maskText} from '../global/mask.js';

export const getButtons = async (req, res) => {
    try {
        const buttons = await Buttons.findAll();
        res.json(buttons);
    } catch (error) {
        return res.status(500).json({message: error.message})
    }
};

export const getButtonForId = async (req, res) => {
    try {
        const {id} = req.params;
        const button = await Buttons.findOne({
            where:{
                id
            },
        });
        res.json(button);
    } catch (error) {
        return res.status(500).json({message: error.message});
    }
};

export const createButtons = async (req, res) => {
    const {
        mask,
        name,
        position,
        status,
        userCreate
    } = req.body;
    try {
        const newButton = await Buttons.create({
            mask,
            name,
            position,
            status,
            userCreate
        });
        const button = await Buttons.findByPk(newButton.id);
        button.mask = maskText('BUT', newButton.id);
        await button.save();
        res.status(200).json(button);
    } catch (error) {
        return res.status(500).json({message: error.message});
    }
};

export const updateButton = async (req, res) => {
    try {
        const {id} = req.params;
        const {
            mask,
            name,
            position,
            userUpdate
        } = req.body;
        const button = await Buttons.findByPk(id);
        button.mask = mask;
        button.name = name;
        button.position = position;
        button.userUpdate = userUpdate;
        await button.save();
        res.json(button);
    } catch (error) {
        return res.status(500).json({message: error.message});
    }
};

export const statusButton = async (req, res) => {
    try {
        const {id} = req.params;
        const {status} = req.body;
        const button = await Buttons.findByPk(id);
        button.status = status;
        await button.save();
        res.json(button);
    } catch (error) {
        return res.status(500).json({message: error.message});
    }
};