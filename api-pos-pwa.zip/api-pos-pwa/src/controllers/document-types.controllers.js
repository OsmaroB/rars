import {DocumentTypes} from '../models/DocumentTypes.js';
import {maskText} from '../global/mask.js';

export const getDocumentTypes = async (req, res) => {
    try {
        const document = await DocumentTypes.findAll();
        res.json(document);
    } catch (error) {
        return res.status(500).json({message: error.message})
    }
};

export const getDocumentTypeForId = async (req, res) => {
    try {
        const {id} = req.params;
        const document = await DocumentTypes.findOne({
            where:{
                id
            },
        });
        res.json(document);
    } catch (error) {
        return res.status(500).json({message: error.message});
    }
};

export const createDocumentType = async (req, res) => {
    const {
        mask,
        name,
        description,
        status,
        userCreate
    } = req.body;
    try {
        const newDocument = await DocumentTypes.create({
            mask,
            name,
            description,
            status,
            userCreate
        });
        const document = await DocumentTypes.findByPk(newDocument.id);
        document.mask = maskText('DOC', newDocument.id);
        await document.save();
        res.status(200).json(document);
    } catch (error) {
        return res.status(500).json({message: error.message});
    }
};

export const updateDocumentType = async (req, res) => {
    try {
        const {id} = req.params;
        const {
            mask,
            name,
            description,
            userUpdate
        } = req.body;
        const document = await DocumentTypes.findByPk(id);
        document.mask = mask;
        document.name = name;
        document.description = description;
        document.userUpdate = userUpdate;
        await document.save();
        res.json(document);
    } catch (error) {
        return res.status(500).json({message: error.message});
    }
};

export const statusDocument = async (req, res) => {
    try {
        const {id} = req.params;
        const {status} = req.body;
        const document = await DocumentTypes.findByPk(id);
        document.status = status;
        await document.save();
        res.json(document);
    } catch (error) {
        return res.status(500).json({message: error.message});
    }
};