import {ChannelsSubchannels} from '../models/ChannelsSubchannels.js'
import {maskText} from '../global/mask.js';

export const getChannels= async (req, res) => {
    try {
        const channels = await ChannelsSubchannels.findAll();
        res.json(channels);
    } catch (error) {
        return res.status(500).json({message: error.message})
    }
};

export const getChannelsForId = async (req, res) => {
    try {
        const {id} = req.params;
        const channel = await ChannelsSubchannels.findOne({
            where:{
                id
            },
        });
        res.json(channel);
    } catch (error) {
        return res.status(500).json({message: error.message});
    }
};

export const createChannel = async (req, res) => {
    const {
        mask,
        name,
        description,
        restaurant,
        isChannel,
        status,
        userCreate
    } = req.body;
    try {
        const newChannel = await ChannelsSubchannels.create({
            mask,
            name,
            description,
            restaurant,
            isChannel,
            status,
            userCreate
        });
        const channel = await ChannelsSubchannels.findByPk(newChannel.id);
        channel.mask = maskText('CHA', newChannel.id);
        await channel.save();
        res.status(200).json(channel);
    } catch (error) {
        return res.status(500).json({message: error.message});
    }
};

export const updateChannel = async (req, res) => {
    try {
        const {id} = req.params;
        const {
            mask,
            name,
            description,
            restaurant,
            isChannel,
            userUpdate
        } = req.body;
        const channel = await ChannelsSubchannels.findByPk(id);
        channel.mask = mask;
        channel.name = name;
        channel.description = description;
        channel.restaurant = restaurant;
        channel.isChannel = isChannel;
        channel.userUpdate = userUpdate;
        await channel.save();
        res.json(channel);
    } catch (error) {
        return res.status(500).json({message: error.message});
    }
};

export const statusChannel = async (req, res) => {
    try {
        const {id} = req.params;
        const {status} = req.body;
        const channel = await ChannelsSubchannels.findByPk(id);
        channel.status = status;
        await channel.save();
        res.json(channel);
    } catch (error) {
        return res.status(500).json({message: error.message});
    }
};