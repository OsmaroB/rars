import { Discounts } from '../models/Discounts.js';
import { Subchannel } from '../models/Subchannel.js';
import { ChannelsSubchannels } from '../models/ChannelsSubchannels.js';
import {maskText} from '../global/mask.js';

export const getDiscounts= async (req, res) => {
    try {
        const discounts = await Discounts.findAll({
            include:[
                {model: Subchannel},
                {model: ChannelsSubchannels}
            ]
        });
        res.json(discounts);
    } catch (error) {
        return res.status(500).json({message: error})
    }
};

export const getDiscountForId = async (req, res) => {
    try {
        const {id} = req.params;
        const discount = await Discounts.findOne({
            include:[
                {model: Subchannel},
                {model: ChannelsSubchannels}
            ],
            where:{
                id
            },
        });
        res.json(discount);
    } catch (error) {
        return res.status(500).json({message: error.message});
    }
};

export const createDiscount = async (req, res) => {
    const {
        name,
        isGlobal,
        type,
        discountInfo,
        status,
        channelID,
        subchannelID,
        userCreate
    } = req.body;
    try {
        const newDiscount = await Discounts.create({
            name,
            isGlobal,
            type,
            discountInfo,
            status,
            channelID,
            subchannelID,
            userCreate
        });
        const discountUpdate = await Discounts.findByPk(newDiscount.id);
        discountUpdate.mask = maskText('CHA', newDiscount.id);
        await discountUpdate.save();
        res.status(200).json(discountUpdate);
    } catch (error) {
        return res.status(500).json({message: error.message});
    }
};

export const updateDiscount = async (req, res) => {
    try {
        const {id} = req.params;
        const {
            name,
            isGlobal,
            type,
            discountInfo,
            channelID,
            subchannelID,
            userUpdate
        } = req.body;
        const discountUpdate = await Discounts.findByPk(id);
        discountUpdate.name = name;
        discountUpdate.isGlobal = isGlobal;
        discountUpdate.type = type;
        discountUpdate.discountInfo = discountInfo;
        discountUpdate.channelID = channelID;
        discountUpdate.subchannelID = subchannelID;
        discountUpdate.userUpdate = userUpdate;
        await discountUpdate.save();
        res.json(discountUpdate);
    } catch (error) {
        return res.status(500).json({message: error.message});
    }
};

export const statusDiscount = async (req, res) => {
    try {
        const {id} = req.params;
        const {status} = req.body;
        const discount = await Discounts.findByPk(id);
        discount.status = status;
        await discount.save();
        res.json(discount);
    } catch (error) {
        return res.status(500).json({message: error.message});
    }
};