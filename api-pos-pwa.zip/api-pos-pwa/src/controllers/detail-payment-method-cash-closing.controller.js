import {DetailPaymentMethodCashClosing} from '../models/DetailPaymentMethodCashClosing.js';
import { PaymentMethodDetails } from '../models/PaymentMethodDetails.js';
import { CashDeskClosing } from '../models/CashDeskClosing.js';

export const getDetailPaymentMethodCashClosing = async (req, res) => {
    try {
        const detailPaymentMethodCashClosing = await DetailPaymentMethodCashClosing.findAll({
            include:[
                {model: CashDeskClosing},
                {model: PaymentMethodDetails},
            ]
        });
        res.json(detailPaymentMethodCashClosing);
    } catch (error) {
        return res.status(500).json({message: error.message})
    }
};

export const readtDetailPaymentMethodCashClosingForCashRegister = async (req, res) => {
    try {
        const {cashDeskClosingID} = req.body;
        const detailPaymentMethodCashClosing = await DetailPaymentMethodCashClosing.findAll({
            include:[
                {model: CashDeskClosing},
                {model: PaymentMethodDetails,
                    where:{
                        status:0
                    }
                },
            ],
            where:{
                cashDeskClosingID
            }
        });
        res.json(detailPaymentMethodCashClosing);
    } catch (error) {
        return res.status(500).json({message: error.message})
    }
};

export const getDetailPaymentMethodCashClosingForId = async (req, res) => {
    try {
        const {id} = req.params;
        const detailPaymentMethodCashClosing = await DetailPaymentMethodCashClosing.findOne({
            include:[
                {model: CashDeskClosing},
                {model: PaymentMethodDetails},
            ],
            where:{
                id
            },
        });
        res.json(detailPaymentMethodCashClosing);
    } catch (error) {
        return res.status(500).json({message: error.message});
    }
};

export const createDetailPaymentMethodCashClosing = async (req, res) => {
    const {
        total,
        status,
        cashDeskClosingID,
        paymentMethodDetailID,
        userCreate
    } = req.body;
    try {
        const newDetailPaymentMethodCashClosing = await DetailPaymentMethodCashClosing.create({
            total,
            status,
            cashDeskClosingID,
            paymentMethodDetailID,
            userCreate
        });
        res.status(200).json(newDetailPaymentMethodCashClosing);
    } catch (error) {
        return res.status(500).json({message: error.message});
    }
};

export const updateDetailPaymentMethodCashClosing = async (req, res) => {
    try {
        const {id} = req.params;
        const {
            total,
            status,
            cashDeskClosingID,
            paymentMethodDetailID,
            userUpdate
        } = req.body;
        const detailPaymentMethodCashClosing = await DetailPaymentMethodCashClosing.findByPk(id);
        detailPaymentMethodCashClosing.total = total;
        detailPaymentMethodCashClosing.status = status;
        detailPaymentMethodCashClosing.cashDeskClosingID = cashDeskClosingID;
        detailPaymentMethodCashClosing.paymentMethodDetailID = paymentMethodDetailID;
        detailPaymentMethodCashClosing.userUpdate = userUpdate;
        await detailPaymentMethodCashClosing.save();
        res.json(detailPaymentMethodCashClosing);
    } catch (error) {
        return res.status(500).json({message: error.message});
    }
};

export const statusDetailPaymentMethodCashClosing = async (req, res) => {
    try {
        const {id} = req.params;
        const {status} = req.body;
        const detailPaymentMethodCashClosing = await DetailPaymentMethodCashClosing.findByPk(id);
        detailPaymentMethodCashClosing.status = status;
        await detailPaymentMethodCashClosing.save();
        res.json(detailPaymentMethodCashClosing);
    } catch (error) {
        return res.status(500).json({message: error.message});
    }
};