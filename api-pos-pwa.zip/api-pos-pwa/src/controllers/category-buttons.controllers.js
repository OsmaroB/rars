import {Categories} from '../models/Categories.js';
import {Buttons} from '../models/Buttons.js'
import {ButtonCategories} from '../models/ButtonCategories.js';

export const getCategoryButton = async (req, res) => {
    try {
        const categoryButton = await ButtonCategories.findAll({
            include:[
                {model: Categories},{model: Buttons}
            ]
        });
        res.json(categoryButton);
    } catch (error) {
        return res.status(500).json({message: error.message})
    }
};

export const getCategoryButtonForId = async (req, res) => {
    try {
        const {id} = req.params;
        const categoryButton = await ButtonCategories.findOne({
            where:{
                id
            },
            include:[
                {model: Categories},{model: Buttons}
            ]
        });
        res.json(categoryButton);
    } catch (error) {
        return res.status(500).json({message: error.message});
    }
};

export const createCategoryButton = async (req, res) => {
    const {
        status,
        buttonID,
        categoryID,
        userCreate,
        days,
        specificDate,
        untilDate
    } = req.body;
    try {
        const newCategory = await ButtonCategories.create({
            buttonID,
            categoryID,
            status,
            userCreate,
            days,
            specificDate,
            untilDate
        });
        res.status(200).json(newCategory);
    } catch (error) {
        return res.status(500).json({message: error.message});
    }
};

export const updateCategoryButton = async (req, res) => {
    try {
        const {id} = req.params;
        const {
            buttonID,
            categoryID,
            userUpdate,
            days,
            specificDate,
            untilDate
        } = req.body;
        const category = await ButtonCategories.findByPk(id);
        category.buttonID = buttonID;
        category.categoryID = categoryID;
        category.userUpdate = userUpdate;
        category.days = days;
        category.specificDate = specificDate;
        category.untilDate = untilDate
        await category.save();
        res.json(category);
    } catch (error) {
        return res.status(500).json({message: error.message});
    }
};

export const statusCategoryButton = async (req, res) => {
    try {
        const {id} = req.params;
        const {status} = req.body;
        const category = await ButtonCategories.findByPk(id);
        category.status = status;
        await category.save();
        res.json(category);
    } catch (error) {
        return res.status(500).json({message: error.message});
    }
};