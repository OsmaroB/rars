// import {ButtonDetails} from '../models/ButtonDetails.js';
// import {Buttons} from '../models/Buttons.js'
import { Products } from '../models/Products.js';
import { Modifiers } from '../models/Modifiers.js'
import { ModifierProducts } from '../models/ModifierProducts.js';
import { ButtonDetails } from '../models/ButtonDetails.js';
import {Prices} from '../models/Prices.js'
import {Recipes} from '../models/Recipes.js'
import { Op } from 'sequelize';

import XLSX from "xlsx";
import { Buttons } from '../models/Buttons.js';
import { ButtonCategories } from '../models/ButtonCategories.js';


export const deleteLogicProductsForChannelAndSubChannel = async (req,res) =>{
    try {
        const prices = await Prices.findAll({
            where:{
                buttonDetailID:{
                    [Op.not]: null,
                }
            },
            include:[
                {
                    model:ButtonDetails,
                    include:[{model:Buttons}]
                },
            ]
        });
        res.json(prices);
    } catch (error) {
        res.json(error);
        
    }
} 

export const createProductsButtons = async (req,res) => {
    try {
        const excel = XLSX.readFile("C:\\Users\\osma2\\Documents\\GitLab\\subwa\\api-pos-pwa\\src\\excel\\update-buttons.xlsx");
        var nameSheet = excel.SheetNames;
        // nameSheet puede cambiar segun la ubicación
        let products = XLSX.utils.sheet_to_json(excel.Sheets[nameSheet[6]]);
        let fistTime = XLSX.utils.sheet_to_json(excel.Sheets[nameSheet[5]]);

        const promise = new Promise((resolve,rejected)=>{
            let newProducts = [];
            let newRecipes = [];
            let newButtons = [];
            let newButtonCategories = [];
            let newButtonDetails = [];
            let newPrices = [];

            let count = 0;
            fistTime.map(async(product)=>{
                const dataProduct = {
                    mask:product.mask,
                    name:product.name.toUpperCase(),
                    nickname:product.nickname,
                    status:0,
                    userCreate:1,
                    userUpdate:0,
                };
                const dataRecipe = {
                    mask:product.mask,
                    name:`RECETA ${product.name.toUpperCase()}`,
                    position:1,
                    status:0,
                    userCreate:1,
                    userUpdate:0,
                };
                const newProduct = await Products.create(dataProduct);
                const newRecipe = await Recipes.create(dataRecipe);
                newProducts.push(newProduct);
                newRecipes.push(newRecipe);
                count++;
                if(count == fistTime.length){
                    const newElementProducts = [];
                    products.map(async(product)=>{
                        let repeat = newProducts.filter((rep)=>{
                            return rep.name == product.name;
                        })
                        if(repeat.length > 0){
                            newElementProducts.push({...product,id:repeat[0]?.id});
                        }
                    });
                    setTimeout(()=>{
                        if(newElementProducts.length == products.length){
                            let newProductsSize = 0;
                            newElementProducts.map(async(product)=>{
                                try {
                                    const dataButton = {
                                        mask:product.mask,
                                        name:product.name.toUpperCase(),
                                        position:1,
                                        status:0,
                                        userCreate:1,
                                        userUpdate:0,
                                    }
                                    newProductsSize++;
                                    const newButton = await Buttons.create(dataButton);
                                    newButtons.push(newButton)
                                    if(newButtons.length == newElementProducts.length){
                                        let newButtonSize = 0;
                                        newButtons.map(async(button)=>{
                                            const dataButtonCategory={
                                                buttonID:button.id,
                                                categoryID:newElementProducts[newButtonSize].categoryID,
                                                status:0,
                                                userCreate:1,
                                                userUpdate:0,
                                            }
                                            const dataButtonDetail={
                                                buttonID:button.id,
                                                productID:newElementProducts[newButtonSize].id,
                                                status:0,
                                                userCreate:1,
                                                userUpdate:0,
                                            }
                                            newButtonSize++;
                                            const newButtonCategory = await ButtonCategories.create(dataButtonCategory);
                                            const newButtonDetail = await ButtonDetails.create(dataButtonDetail);
                                            newButtonCategories.push(newButtonCategory);
                                            newButtonDetails.push(newButtonDetail);
                                            console.log(newButtonSize);
                                            if(newButtonDetails.length == newButtons.length 
                                                && newButtonCategories.length == newButtons.length){
                                                let newButtonDetailsSize = 0;
                                                newButtonDetails.map(async(buttonDetail)=>{
                                                    // console.log(newElementProducts[0]);x|
                                                    const dataPrice = {
                                                        price:newElementProducts[newButtonDetailsSize].price,
                                                        status:0,
                                                        userCreate:1,
                                                        userUpdate:0,
                                                        buttonDetailID:buttonDetail.id,
                                                        channelID:newElementProducts[newButtonDetailsSize].channelID,
                                                        subchannelID:newElementProducts[newButtonDetailsSize].subchannelID == 0 
                                                        ? null : newElementProducts[newButtonDetailsSize].subchannelID,
                                                    };
                                                    newButtonDetailsSize++
                                                    const newPrice = await Prices.create(dataPrice);
                                                    newPrices.push(newPrice);
                                                    if(newPrices.length == newButtonDetails.length){
                                                        resolve({
                                                            newRecipes,
                                                            newButtons,
                                                            newProduct,
                                                            newButtonCategories,
                                                            newButtonDetails,
                                                            newPrices
                                                        })
                                                    }
                                                })
                                            }
                                        })
                                    }
                                    
                                } catch (error) {
                                    rejected(error);
                                }
                            })
                        }
                    },1000);
                }
            });
        });
        const data = await promise
        res.json(data);
    } catch (error) {
        res.json(error);
    }
}

export const updateDataProducts = async (req,res) =>{
    try {
        const excel = XLSX.readFile("C:\\Users\\user\\Documents\\GitLab\\api-pos-pwa\\src\\excel\\update-buttons.xlsx");
        var nameSheet = excel.SheetNames;
        let products = XLSX.utils.sheet_to_json(excel.Sheets[nameSheet[1]]);
        let promise = new Promise((resolve, rejected)=>{
            let productsData = [];
            products.map(async(product)=>{
                const buttonDetail = await ButtonDetails.findAll({
                    where:{
                        productID:product.id
                    },
                })
                buttonDetail.map(async(buttonD)=>{
                    try {
                        const prices = await Prices.findAll({
                            where:{
                                buttonDetailID:buttonD.dataValues.id
                            }
                        });
                        prices.map(async(price)=>{
                            price.price = product.price;
                            price.status = product.Estado == 'Activo' ? 0 : 1 
                            await price.save();
                        })
                    } catch (error) {
                        return res.status(500).json({message: error.message});
                    }
                })
                productsData.push(buttonDetail.dataValues)
            });
            setTimeout(()=>{
                resolve(productsData)
            },2000)
        })
        const buttonDetailData = await promise;
        res.json({products,buttonDetailData});
        
    } catch (error) {
        console.log(error);
        res.json(error);
    }
}


export const updateDataModifiers = async (req,res) =>{
    try {
        const excel = XLSX.readFile("C:\\Users\\user\\Documents\\GitLab\\api-pos-pwa\\src\\excel\\update-buttons.xlsx");
        var nameSheet = excel.SheetNames;
        let modifiers = XLSX.utils.sheet_to_json(excel.Sheets[nameSheet[2]]);
        let promise = new Promise((resolve, rejected)=>{
            let productsData = [];
            modifiers.map(async(modifier)=>{
                const modifierProduct = await ModifierProducts.findAll({
                    where:{
                        modifierID:modifier.id
                    },
                })
                modifierProduct.map(async(modifierP)=>{
                    const prices = await Prices.findAll({
                        where:{
                            modifierProductID:modifierP.dataValues.id
                        }
                    });
                    prices.map(async(price)=>{
                        price.price = modifier.price;
                        price.status = modifier.Estado == 'Activo' ? 0 : 1
                        await price.save();
                    })
                })
                productsData.push(modifierProduct.dataValues)
            });
            setTimeout(()=>{
                resolve(productsData)
            },2000)
        })
        const buttonDetailData = await promise;
        res.json({modifiers,buttonDetailData});
        
    } catch (error) {
        console.log(error);
        res.json(error);
    }
}

export const importDataModifiers = async (req,res) => {
    try {
        const excel = XLSX.readFile("C:\\Users\\osma2\\Documents\\GitLab\\api-pos-pwa\\src\\excel\\Botones Subway (1).xlsx");
        var nameSheet = excel.SheetNames;
        let data = XLSX.utils.sheet_to_json(excel.Sheets[nameSheet[8]]);
        let dataRes = [];
        const productData = await Products.findAll();
        const modifierData = await Modifiers.findAll();
        data.map((modifier,index)=>{
            let addData={index};
            productData.map((product)=>{
                if(modifier.Producto == product.name){
                    addData = {
                        ...addData,
                        status:0,
                        productName:product.name,
                        userCreate:1,
                        userUpdate:0,
                        productID:product.id,
                    }
                }
            })
            modifierData.map((modifierSql)=>{
                if(modifier.Modificador == modifierSql.name){
                    addData = {
                        ...addData,
                        modifierID:modifierSql.id,
                        modifierName:modifierSql.name
                    }
                }
            })
            if(addData?.modifierID != null){
                dataRes.push(addData);
            }
        })

        const intento =  dataRes.map(async (data)=>{
            const newModifierProduct = {
                status:data.status,
                userCreate:data.userCreate,
                userUpdate:data.userUpdate,
                modifierID:data.modifierID,
                productID:data.productID,
            };
            // const res = await ModifierProducts.create(newModifierProduct);
            return res;
        })
        res.json(intento);
    } catch (error) {
        console.log(error);
    }
}

export const importDataModifierPrices = async(req,res)=>{
    const excel = XLSX.readFile("C:\\Users\\osma2\\Documents\\GitLab\\api-pos-pwa\\src\\excel\\Botones Subway (1).xlsx");
    var nameSheet = excel.SheetNames;
    let data = XLSX.utils.sheet_to_json(excel.Sheets[nameSheet[8]]);
    let dataRes = [];
    const modifierProductData = await ModifierProducts.findAll({
        include:[
            {model: Products},
            {model: Modifiers}
        ],
    })
    data.map((modifier,index)=>{
        modifierProductData.map((modifierProduct)=>{
            let dataNewPrice = {index};
            if(modifierProduct?.product != null && modifierProduct?.modifier != null){
                if(modifier.Producto == modifierProduct.product.name && modifier.Modificador == modifierProduct.modifier.name){
                    dataNewPrice={
                        ...dataNewPrice,
                        modifierName:modifierProduct.modifier.name,
                        productName:modifierProduct.product.name,
                        price:modifier.Precio,
                        status:0,
                        categoria:modifier.Categoria,
                        userCreate:1,
                        userUpdate:0,
                        channel:modifier.PuntoVenta,
                        modifierProductID:modifierProduct.id
                    }
                    dataRes.push(dataNewPrice);
                }
            }
        })
    })

    const dataRestaurant = dataRes.filter((data)=>{
        return data.channel == 'Restaurante' || data.channel == 'Restaurante/Delivery'
    });

    const dataDelivery = dataRes.filter((data)=>{
        return data.channel == 'Delivery' || data.channel == 'Restaurante/Delivery'
    });

    // insertando en todos los canales
    const dataRestaurantChannel = dataRestaurant.map(async (data)=>{
        let dataInsert = {
            price:data.price,
            status:data.status,
            userCreate:data.userCreate,
            userUpdate:data.userUpdate,
            modifierProductID:data.modifierProductID,
            channelID:'2'
        }
        // const res = await Prices.create(dataInsert);
        return dataInsert;
    })

    const dataEmployeeAdmin = dataRestaurant.map(async (data)=>{
        let dataInsert = {
            price:data.price,
            status:data.status,
            userCreate:data.userCreate,
            userUpdate:data.userUpdate,
            modifierProductID:data.modifierProductID,
            channelID:'4',
            subchannelID:'4'
        }
        // const res = await Prices.create(dataInsert);
        return dataInsert;
    })

    const dataAdministrative = dataRestaurant.map(async (data)=>{
        let dataInsert = {
            price:data.price,
            status:data.status,
            userCreate:data.userCreate,
            userUpdate:data.userUpdate,
            modifierProductID:data.modifierProductID,
            channelID:'4',
            subchannelID:'5'
        }
        // const res = await Prices.create(dataInsert);
        return dataInsert;
    })

    const dataUberEats = dataDelivery.map(async (data)=>{
        let dataInsert = {
            price:data.price,
            status:data.status,
            userCreate:data.userCreate,
            userUpdate:data.userUpdate,
            modifierProductID:data.modifierProductID,
            channelID:'3',
            subchannelID:'3'
        }
        // const res = await Prices.create(dataInsert);
        return dataInsert;
    })
    const dataPedidosYa = dataDelivery.map(async (data)=>{
        let dataInsert = {
            price:data.price,
            status:data.status,
            userCreate:data.userCreate,
            userUpdate:data.userUpdate,
            modifierProductID:data.modifierProductID,
            channelID:'3',
            subchannelID:'1'
        }
        // const res = await Prices.create(dataInsert);
        return dataInsert;
    })

    res.json({
        dataRestaurantChannel, 
        dataEmployeeAdmin, 
        dataAdministrative,
        dataUberEats,
        dataPedidosYa,
    });


};