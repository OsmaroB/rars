import {Optionals} from '../models/Optionals.js';
import {maskText} from '../global/mask.js';


export const getOptionals = async (req, res) => {
    try {
        const optionals = await Optionals.findAll();
        res.json(optionals);
    } catch (error) {
        return res.status(500).json({message: error.message})
    }
};

export const getOptionalForId = async (req, res) => {
    try {
        const {id} = req.params;
        const optional = await Optionals.findOne({
            where:{
                id
            },
        });
        res.json(optional);
    } catch (error) {
        return res.status(500).json({message: error.message});
    }
};

export const createOptional = async (req, res) => {
    const {
        mask,
        name,
        status,
        userCreate
    } = req.body;
    try {
        const newOptional = await Optionals.create({
            mask,
            name,
            status,
            userCreate
        });
        const optional = await Optionals.findByPk(newOptional.id);
        optional.mask = maskText('OPT', newOptional.id);
        await optional.save();
        res.status(200).json(optional);
    } catch (error) {
        return res.status(500).json({message: error.message});
    }
};

export const updateOptional = async (req, res) => {
    try {
        const {id} = req.params;
        const {
            mask,
            name,
            userUpdate
        } = req.body;
        const optional = await Optionals.findByPk(id);
        optional.mask = mask;
        optional.name = name;
        optional.userUpdate = userUpdate;
        await optional.save();
        res.json(optional);
    } catch (error) {
        return res.status(500).json({message: error.message});
    }
};

export const statusOptional = async (req, res) => {
    try {
        const {id} = req.params;
        const {status} = req.body;
        const optional = await Optionals.findByPk(id);
        optional.status = status;
        await optional.save();
        res.json(optional);
    } catch (error) {
        return res.status(500).json({message: error.message});
    }
};