import {RoleDetail} from '../models/RoleDetail.js';
import {maskText} from '../global/mask.js';

export const getRoleDetails = async (req, res) => {
    try {
        const rolesDetails = await RoleDetail.findAll();
        res.json(rolesDetails);
    } catch (error) {
        return res.status(500).json({message: error.message})
    }
};

export const getRoleDetailForId = async (req, res) => {
    try {
        const {id} = req.params;
        const roleDetail = await RoleDetail.findByPk(id);
        res.json(roleDetail);
    } catch (error) {
        return res.status(500).json({message: error.message})
    }
};

export const createRoleDetail = async (req, res) => {
    const {mask, url, status, roleID, userCreate} = req.body;
    try {
        const newRoleDetail = await RoleDetail.create({
            mask,
            url,
            status,
            roleID,
            userCreate
        });
        const roleDetail = await RoleDetail.findByPk(newRoleDetail.id);
        roleDetail.mask = maskText('RDT', newRoleDetail.id);
        await roleDetail.save();
        res.status(200).json(roleDetail)
    } catch (error) {
        return res.status(500).json({message: error.message});
    }
};

export const updateRoleDetail = async (req, res) => {
    try {
        const {id} = req.params;
        const {mask, url, roleID, userUpdate} = req.body;
        const roleDetail = await RoleDetail.findByPk(id);
        roleDetail.mask = mask;
        roleDetail.url = url;
        roleDetail.roleID = roleID;
        roleDetail.userUpdate = userUpdate;
        await roleDetail.save();
        res.json(roleDetail);
    } catch (error) {
        return res.status(500).json({message: error.message});
    }
};

export const statusRoleDetail = async (req, res) => {
    try {
        const {id} = req.params;
        const {status} = req.body;
        const roleDetail = await RoleDetail.findByPk(id);
        roleDetail.status = status;
        await roleDetail.save();
        res.json(roleDetail);
    } catch (error) {
        return res.status(500).json({message: error.message});
    }
};