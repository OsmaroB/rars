import {User} from '../models/User.js';
import bcryptjs from 'bcryptjs'
import jwt from 'jsonwebtoken';
import { SECRET } from "../config/config.js";
import {maskText} from '../global/mask.js';
import { Employee } from '../models/Employee.js';
import { Role } from '../models/Role.js';
import { RoleDetail } from '../models/RoleDetail.js';



export const getUsers = async (req, res) => {
    try {
        const users = await User.findAll();
        res.json(users);
    } catch (error) {
        return res.status(500).json({message: error.message})
    }
};

export const getuserForCode = async (req,res) =>{
    try {
        const {code} = req.body;
        const user = await User.findOne({
            where:{
                code
            }
        })
        res.json(user);
    } catch (error) {
        return res.status(500).json({message: error.message});
    }
};

export const createCodeAuthorization = async (req,res) =>{
    try {
        const {id} = req.params;
        const {code} = req.body;
        const user = await User.findByPk(id);
        user.code = code;
        await user.save();
        res.json(user);
    } catch (error) {
        return res.status(500).json({message: error.message});
    }
};

export const getUserForId = async (req, res) => {
    try {
        const {id} = req.params;
        const user = await User.findByPk(id);
        res.json(user);
    } catch (error) {
        return res.status(500).json({message: error.message})
    }
};

export const createUser = async (req, res) => {
    const {mask, email, password, status, employeeID, roleID, userCreate} = req.body;
    const hash = await bcryptjs.hash(password, 8);
    try {
        const newUser = await User.create({
            mask,
            email,
            password: hash,
            status,
            employeeID,
            roleID,
            userCreate
        });
        const user = await User.findByPk(newUser.id);
        user.mask = maskText('USR', newUser.id);
        await user.save();
        res.status(200).json(user);
    } catch (error) {
        res.json({status:500, message: error.message});
        return res.status(500);
    }
};

export const updateUser = async (req, res) => {
    try {
        const {id} = req.params;
    const {mask, email, employeeID, roleID, userUpdate} = req.body;
        const user = await User.findByPk(id);
        user.mask = mask;
        user.email = email;
        user.employeeID = employeeID;
        user.roleID = roleID;
        user.userUpdate = userUpdate;
        await user.save();
        res.json(user);
    } catch (error) {
        res.json({status:500,message: error.message});
        res.status(500)
    }
};

export const statusUser = async (req, res) => {
    try {
        const {id} = req.params;
        const {status} = req.body;
        const user = await User.findByPk(id);
        user.status = status;
        await user.save();
        res.json(user);
    } catch (error) {
        return res.status(500).json({message: error.message});
    }
};

export const changePassword = async (req, res) => {
    const {password, newPassword, newPassword2} = req.body;
    const {id} = req.params;
    const user = await User.findByPk(id);
    const compare = bcryptjs.compareSync(password, user.password);
        if(compare){
            if(newPassword === newPassword2){
                const hash = await bcryptjs.hash(newPassword, 8);
                const user = await User.findByPk(id);
                user.password = hash;
                await user.save();
                res.json({message: "Contraseña actualizada con éxito"})
            }else{
                return res.status(500).json({message: "Las contraseñas nuevas no son iguales"});
            }
        }else{
            return res.status(500).json({message: "Ingrese correctamente la contraseña actual"});
        }
};


export const userRepeat = async (req, res) => {
    try {
        const {email,id} = req.body;
        const user = await User.findAll({
            where:{
                email,
                id:!id,
            }
        });
        if(user.length>0){
            return res.status(500).json({status:true,  message:'Este usuario esta repetido'})
        }else{
            return res.json({status:false})
        }

    } catch (error) {
        return res.status(500).json({message: "No se encontraron resultados"});
    }
}

export const login = async (req, res) => {
    try {
        const {email, password} = req.body;
        console.log(email);
        console.log(password);
        const user = await User.findOne({
            where:{
                email
            },
            include:[
                {model: Role},
                {model: Employee},
            ]
        });
        const roleDetail = await RoleDetail.findAll({
            where:{
                roleID:user.roleID
            }
        })
        console.log(user);
        const compare = bcryptjs.compareSync(password, user.password);
        if(compare){
            const token = jwt.sign({id: user.id}, SECRET, {
                expiresIn: 43200, // 5 hours
            });
            return res.status(200).json({ 
                userID:user.id,
                token,
                employeeName:user.employee.name,
                roleID:user.role.id,
                roleDetail
             });
        }else{
            res.json('El correo o contraseña son incorrectos');
        }
        // res.json({user,roleDetail,compare});

    } catch (error) {
        return res.status(200).json('Su email no concuerda con ningun usuario revise si lo escribio correctamente');
    }
};