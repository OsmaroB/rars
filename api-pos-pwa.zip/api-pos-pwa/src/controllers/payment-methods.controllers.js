import {Categories} from '../models/Categories.js';
import {PaymentMethods} from '../models/PaymentMethods.js';
import {maskText} from '../global/mask.js';


export const getPaymentMethods = async (req, res) => {
    try {
        const paymentMethods = await PaymentMethods.findAll();
        res.json(paymentMethods);
    } catch (error) {
        return res.status(500).json({message: error.message})
    }
};

export const getPaymentMethodForId = async (req, res) => {
    try {
        const {id} = req.params;
        const paymentMethod = await PaymentMethods.findOne({
            where:{
                id
            },
        });
        res.json(paymentMethod);
    } catch (error) {
        return res.status(500).json({message: error.message});
    }
};

export const createPaymentMethod = async (req, res) => {
    const {
        mask,
        name,
        description,
        status,
        userCreate
    } = req.body;
    try {
        const newPaymentMethod = await PaymentMethods.create({
            mask,
            name,
            status,
            description,
            userCreate
        });
        const paymentMethod = await PaymentMethods.findByPk(newPaymentMethod.id);
        paymentMethod.mask = maskText('PAY', newPaymentMethod.id);
        await paymentMethod.save();
        res.status(200).json(paymentMethod);
    } catch (error) {
        return res.status(500).json({message: error.message});
    }
};

export const updatePaymentMethod = async (req, res) => {
    try {
        const {id} = req.params;
        const {
            mask,
            name,
            description,
            userUpdate
        } = req.body;
        const paymentMethod = await PaymentMethods.findByPk(id);
        paymentMethod.mask = mask;
        paymentMethod.name = name;
        paymentMethod.description = description;
        paymentMethod.userUpdate = userUpdate;
        await paymentMethod.save();
        res.json(paymentMethod);
    } catch (error) {
        return res.status(500).json({message: error.message});
    }
};

export const statusPaymentMethod = async (req, res) => {
    try {
        const {id} = req.params;
        const {status} = req.body;
        const paymentMethod = await PaymentMethods.findByPk(id);
        paymentMethod.status = status;
        await paymentMethod.save();
        res.json(paymentMethod);
    } catch (error) {
        return res.status(500).json({message: error.message});
    }
};