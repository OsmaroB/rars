import { ModifierProducts } from '../models/ModifierProducts.js';
import { Modifiers } from '../models/Modifiers.js';
import { Products } from '../models/Products.js';
import { Submodifiers } from '../models/Submodifiers.js';
import { Depmodifiers } from '../models/DepModifiers.js';
import {maskText} from '../global/mask.js';


export const getModifierProducts = async (req, res) => {
    try {
        const modifierProducts = await ModifierProducts.findAll({
            include:[
                {model: Modifiers},
                {model: Products},
                {model: Submodifiers},
                {model: Depmodifiers},
            ]
        });
        res.json(modifierProducts);
    } catch (error) {
        return res.status(500).json({message: error.message})
    }
};

export const getModifierProductForId = async (req, res) => {
    try {
        const {id} = req.params;
        const modifierProduct = await ModifierProducts.findAll({
            include:[
                {model: Modifiers},{model: Products}
            ],
            where:{
                productID: id
            },
        });
        res.json(modifierProduct);
    } catch (error) {
        return res.status(500).json({message: error.message});
    }
};

export const createModifierProduct = async (req, res) => {
    const {
        status,
        modifierID,
        productID,
        submodifierID,
        depModifierID,
        userCreate
    } = req.body;
    if(submodifierID == ''){
        submodifierID == null;
    }
    try {
        const newModifierProduct = await ModifierProducts.create({
            status,
            modifierID,
            productID,
            submodifierID,
            depModifierID,
            userCreate
        });
        const modifierProduct = await ModifierProducts.findByPk(newModifierProduct.id);
        modifierProduct.mask = maskText('MOP', newModifierProduct.id);
        await modifierProduct.save();
        res.status(200).json(modifierProduct);
    } catch (error) {
        console.log(error);
        return res.status(500).json({message: error.message});
    }
};

export const updateModifierProduct = async (req, res) => {
    try {
        const {id} = req.params;
        const {
            modifierID,
            productID,
            submodifierID,
            depModifierID,
            userUpdate
        } = req.body;
        const modifierProduct = await ModifierProducts.findByPk(id);
        modifierProduct.modifierID = modifierID;
        modifierProduct.productID = productID;
        modifierProduct.submodifierID = submodifierID;
        modifierProduct.depModifierID = depModifierID;
        modifierProduct.userUpdate = userUpdate;
        await modifierProduct.save();
        res.json(modifierProduct);
    } catch (error) {
        return res.status(500).json({message: error.message});
    }
};

export const statusModifierProduct = async (req, res) => {
    try {
        const {id} = req.params;
        const {status} = req.body;
        const modifierProduct = await ModifierProducts.findByPk(id);
        modifierProduct.status = status;
        await modifierProduct.save();
        res.json(modifierProduct);
    } catch (error) {
        return res.status(500).json({message: error.message});
    }
};