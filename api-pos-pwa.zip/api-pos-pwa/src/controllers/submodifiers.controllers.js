
import { Submodifiers } from '../models/Submodifiers.js';
import {Modifiers} from '../models/Modifiers.js';
import {maskText} from '../global/mask.js';

export const getSubmodifiers = async (req, res) => {
    try {
        const submodifiers = await Submodifiers.findAll({
            include:[
                {model: Modifiers}
            ]
        });
        res.json(submodifiers);
    } catch (error) {
        return res.status(500).json({message: error.message})
    }
};

export const getSubmodifierForId = async (req, res) => {
    try {
        const {id} = req.params;
        const submodifier = await Submodifiers.findByPk(id);
        res.json(submodifier);
    } catch (error) {
        return res.status(500).json({message: error.message})
    }
};

export const createSubmodifier = async (req, res) => {
    const {mask, name, status, modifierID, userCreate} = req.body;
    if(!name) return res.sendStatus(400);
    try {
        const newSubmodifier = await Submodifiers.create({
            mask,
            name,
            status,
            modifierID,
            userCreate
        });
        const submodifier = await Submodifiers.findByPk(newSubmodifier.id);
        submodifier.mask = maskText('SUBMOD', newSubmodifier.id);
        await submodifier.save();
        res.status(200).json(submodifier);
    } catch (error) {
        return res.status(500).json({message: error.message});
    }
};

export const updateSubmodifier = async (req, res) => {
    try {
        const {id} = req.params;
        const {name, modifierID, userUpdate} = req.body;
        if(!name || !id) return res.sendStatus(400);

        const submodifier = await Submodifiers.findByPk(id);
        submodifier.name = name;
        submodifier.userUpdate = userUpdate;
        submodifier.modifierID = modifierID;
        await submodifier.save();
        res.json(submodifier);
    } catch (error) {
        return res.status(500).json({message: error.message});
    }
};

export const statusSubmodifier = async (req, res) => {
    try {
        const {id} = req.params;
        const {status} = req.body;
        const submodifier = await Submodifiers.findByPk(id);
        submodifier.status = status;
        await submodifier.save();
        res.json(submodifier);
    } catch (error) {
        return res.status(500).json({message: error.message});
    }
};