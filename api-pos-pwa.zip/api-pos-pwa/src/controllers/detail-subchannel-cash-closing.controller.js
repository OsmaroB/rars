import { DetailSubchannelCashClosing } from '../models/DetailSubchannelClosing.js';
import { CashDeskClosing } from '../models/CashDeskClosing.js';
import { Subchannel } from '../models/Subchannel.js';

export const getDetailSubchannelCashClosing = async (req, res) => {
    try {
        const detailSubchannelCashClosing = await DetailSubchannelCashClosing.findAll({
            include:[
                {model: CashDeskClosing},
                {model: Subchannel},
            ]
        });
        res.json(detailSubchannelCashClosing);
    } catch (error) {
        return res.status(500).json({message: error.message})
    }
};

export const readSubchannelCashClosingForCashRegister = async (req, res) => {
    try {
        const {cashDeskClosingID} = req.body;
        const detailSubchannelCashClosing = await DetailSubchannelCashClosing.findAll({
            include:[
                {model: CashDeskClosing},
                {model: Subchannel,
                    where:{
                        status:0
                    }
                },
            ],
            where:{
                cashDeskClosingID
            }
        });
        res.json(detailSubchannelCashClosing);
    } catch (error) {
        return res.status(500).json({message: error.message})
    }
};

export const getDetailSubchannelCashClosingForId = async (req, res) => {
    try {
        const {id} = req.params;
        const detailSubchannelCashClosing = await DetailSubchannelCashClosing.findOne({
            include:[
                {model: CashDeskClosing},
                {model: Subchannel},
            ],
            where:{
                id
            },
        });
        res.json(detailSubchannelCashClosing);
    } catch (error) {
        return res.status(500).json({message: error.message});
    }
};

export const createDetailSubchannelCashClosing = async (req, res) => {
    const {
        total,
        status,
        cashDeskClosingID,
        subchannelID,
        userCreate
    } = req.body;
    try {
        const newDetailSubchannelCashClosing = await DetailSubchannelCashClosing.create({
            total,
            status,
            cashDeskClosingID,
            subchannelID,
            userCreate
        });
        res.status(200).json(newDetailSubchannelCashClosing);
    } catch (error) {
        return res.status(500).json({message: error.message});
    }
};

export const updateDetailSubchannelCashClosing = async (req, res) => {
    try {
        const {id} = req.params;
        const {
            total,
            status,
            cashDeskClosingID,
            subchannelID,
            userUpdate
        } = req.body;
        const detailSubchannelCashClosing = await DetailSubchannelCashClosing.findByPk(id);
        detailSubchannelCashClosing.total = total;
        detailSubchannelCashClosing.status = status;
        detailSubchannelCashClosing.cashDeskClosingID = cashDeskClosingID;
        detailSubchannelCashClosing.subchannelID = subchannelID;
        detailSubchannelCashClosing.userUpdate = userUpdate;
        await detailSubchannelCashClosing.save();
        res.json(detailSubchannelCashClosing);
    } catch (error) {
        return res.status(500).json({message: error.message});
    }
};

export const statusDetailSubchannelCashClosing = async (req, res) => {
    try {
        const {id} = req.params;
        const {status} = req.body;
        const detailSubchannelCashClosing = await DetailSubchannelCashClosing.findByPk(id);
        detailSubchannelCashClosing.status = status;
        await detailSubchannelCashClosing.save();
        res.json(detailSubchannelCashClosing);
    } catch (error) {
        return res.status(500).json({message: error.message});
    }
};