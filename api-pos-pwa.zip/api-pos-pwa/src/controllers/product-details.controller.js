import {ProductDetails} from '../models/ProductDetails.js';
import {Recipes} from '../models/Recipes.js';
import {Products} from '../models/Products.js'
import {maskText} from '../global/mask.js';

export const getProductDetails = async (req, res) => {
    try {
        const productDetails = await ProductDetails.findAll({
            include:[
                {model: Recipes},{model: Products}
            ]
            
        });
        res.json(productDetails);
    } catch (error) {
        return res.status(500).json({message: error.message})
    }
};

export const getProductDetailForId = async (req, res) => {
    try {
        const {id} = req.params;
        const productDetail = await ProductDetails.findOne({
            where:{
                id
            },
            include:[
                {model: Recipes},{model: Products}
            ]
        });
        res.json(productDetail);
    } catch (error) {
        return res.status(500).json({message: error.message});
    }
};

export const createProductDetail = async (req, res) => {
    const {
        status,
        recipeID,
        productID,
        userCreate
    } = req.body;
    try {
        const newProductDetail = await ProductDetails.create({
            status,
            recipeID,
            productID,
            userCreate
        });
        res.status(200).json(newProductDetail);
    } catch (error) {
        return res.status(500).json({message: error.message});
    }
};

export const updateProductDetail = async (req, res) => {
    try {
        const {id} = req.params;
        const {
            recipeID,
            productID,
            userUpdate
        } = req.body;
        const productDetail = await ProductDetails.findByPk(id);
        productDetail.recipeID = recipeID;
        productDetail.productID = productID;
        productDetail.userUpdate = userUpdate;
        await productDetail.save();
        res.json(productDetail);
    } catch (error) {
        return res.status(500).json({message: error.message});
    }
};

export const statusProductDetail = async (req, res) => {
    try {
        const {id} = req.params;
        const {status} = req.body;
        const productDetail = await ProductDetails.findByPk(id);
        productDetail.status = status;
        await productDetail.save();
        res.json(productDetail);
    } catch (error) {
        return res.status(500).json({message: error.message});
    }
};