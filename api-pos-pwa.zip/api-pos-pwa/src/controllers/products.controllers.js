import {Products} from '../models/Products.js'
import {maskText} from '../global/mask.js';


export const getProducts = async (req, res) => {
    try {
        const products = await Products.findAll();
        res.json(products);
    } catch (error) {
        return res.status(500).json({message: error.message})
    }
};

export const getProductForId = async (req, res) => {
    try {
        const {id} = req.params;
        const product = await Products.findByPk(id);
        res.json(product);
    } catch (error) {
        return res.status(500).json({message: error.message});
    }
};

export const createProduct = async (req, res) => {
    const {
        mask,
        name,
        nickname,
        status,
        userCreate
    } = req.body;
    try {
        const newProduct = await Products.create({
            mask,
            name,
            nickname,
            status,
            userCreate
        });
        const product = await Products.findByPk(newProduct.id);
        product.mask = maskText('PRO', newProduct.id);
        await product.save();
        res.status(200).json(product);
    } catch (error) {
        return res.status(500).json({message: error.message});
    }
};

export const updateProduct = async (req, res) => {
    try {
        const {id} = req.params;
        const {
            mask,
            name,
            nickname,
            status,
            userUpdate
        } = req.body;
        const product = await Products.findByPk(id);
        product.mask = mask;
        product.name = name;
        product.status = status;
        product.nickname = nickname;
        product.userUpdate = userUpdate;
        await product.save();
        res.json(product);
    } catch (error) {
        return res.status(500).json({message: error.message});
    }
};

export const statusProduct = async (req, res) => {
    try {
        const {id} = req.params;
        const {status} = req.body;
        const product = await Products.findByPk(id);
        product.status = status;
        await product.save();
        res.json(product);
    } catch (error) {
        return res.status(500).json({message: error.message});
    }
};