import {PaymentMethodDetails} from '../models/PaymentMethodDetails.js';
import {PaymentMethods} from '../models/PaymentMethods.js'
import {maskText} from '../global/mask.js';


export const getPaymentMethodDetails = async (req, res) => {
    try {
        const paymentMethodDetails = await PaymentMethodDetails.findAll({
            include:[
                {model:PaymentMethods}
            ]
        });
        res.json(paymentMethodDetails);
    } catch (error) {
        return res.status(500).json({message: error.message})
    }
};

export const getPaymentMethodForId = async (req, res) => {
    try {
        const {id} = req.params;
        const paymentMethodDetail = await PaymentMethodDetails.findOne({
            where:{
                id
            },
        });
        res.json(paymentMethodDetail);
    } catch (error) {
        return res.status(500).json({message: error.message});
    }
};

export const createPaymentMethodDetail = async (req, res) => {
    const {
        mask,
        name,
        description,
        status,
        userCreate,
        paymentMethodID
    } = req.body;
    try {
        const newPaymentMethodDetail = await PaymentMethodDetails.create({
            mask,
            name,
            status,
            description,
            userCreate,
            paymentMethodID
        });
        const paymentMethodDetail = await PaymentMethodDetails.findByPk(newPaymentMethodDetail.id);
        paymentMethodDetail.mask = maskText('PAYDT', newPaymentMethodDetail.id);
        await paymentMethodDetail.save();
        res.status(200).json(paymentMethodDetail);
    } catch (error) {
        return res.status(500).json({message: error.message});
    }
};

export const updatePaymentMethodDetail = async (req, res) => {
    try {
        const {id} = req.params;
        const {
            mask,
            name,
            description,
            userUpdate,
            paymentMethodID

        } = req.body;
        const paymentMethodDetail = await PaymentMethodDetails.findByPk(id);
        paymentMethodDetail.mask = mask;
        paymentMethodDetail.name = name;
        paymentMethodDetail.description = description;
        paymentMethodDetail.userUpdate = userUpdate;
        paymentMethodDetail.paymentMethodID = paymentMethodID;
        await paymentMethodDetail.save();
        res.json(paymentMethod);
    } catch (error) {
        return res.status(500).json({message: error.message});
    }
};

export const statusPaymentMethod = async (req, res) => {
    try {
        const {id} = req.params;
        const {status} = req.body;
        const paymentMethodDetail = await PaymentMethodDetails.findByPk(id);
        paymentMethodDetail.status = status;
        await paymentMethodDetail.save();
        res.json(paymentMethodDetail);
    } catch (error) {
        return res.status(500).json({message: error.message});
    }
};