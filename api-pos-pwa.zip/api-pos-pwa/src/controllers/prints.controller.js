import { ThermalPrinter, PrinterTypes }  from 'node-thermal-printer';
import moment from "moment";
import printer from '@flovy/node-printer';
import {PRINTER} from '../config/config.js'

export const printTiket = async (req,res) =>{
  try {
    const {
      tiketConfiguration,
      detailSale,
      document,
      employeeName,
      datePrint,
      description,
      channel,
      channelName,
      customerName,
      discountSubchannel,
    } = req.body;


    const thermalPrinter = new ThermalPrinter({
      type: PrinterTypes.EPSON, 
      options: {
        timeout: 1000,
      }
    });
    // Header
    const tiketConf = tiketConfiguration[0]
    // const date = moment(new Date()).format("YYYY-MM-DD");
    const date = moment(datePrint).format("YYYY-MM-DD");
    const hour = moment(new Date()).format("HH:mm:ss");


    thermalPrinter.alignCenter();
    thermalPrinter.bold(true); 
    thermalPrinter.println((tiketConf.enterprise).toUpperCase());
    thermalPrinter.println(`Fecha ${date} ${hour}`);
    thermalPrinter.println(`Tipo de documento ${(document.documentType.name).toUpperCase()}`);
    thermalPrinter.println(`Canal de venta - ${channelName}`);
    if(description != ''){
      thermalPrinter.println(`Descripción: ${description}`);
    }
    
    thermalPrinter.bold(false); 
    thermalPrinter.println((tiketConf.address).toUpperCase());
    thermalPrinter.println(`NIT: ${(tiketConf.nit).toUpperCase()}`);
    thermalPrinter.println(`TIENDA: #72217`);
    thermalPrinter.println(`CAJA ${(tiketConf.cashRegisterNumber).toUpperCase()} Tiquete N°${tiketConf.serie}${document.actualCorrelative}`);
    thermalPrinter.println(`Cajero ${employeeName}`);
    thermalPrinter.println(``); 
    thermalPrinter.tableCustom([                                       
      { text:"CANT", align:"LEFT", width:0.1 },
      { text:"DESC.", align:"LEFT", width:0.5 },
      { text:"P/UNI", align:"LEFT", width:0.25},
      { text:"TOTAL", align:"LEFT", cols:7 }
    ]);

    // SALE DETAIL
    let total = 0.00;
    detailSale.map((product)=>{
      if(product.modifierProduct[0] != null){
        total += (product.cost * product.cant);
        let resul = product.name.substr(0,18)
        thermalPrinter.tableCustom([                                      
          { text:`${product.cant}`, align:"LEFT", width:0.1 },
          { text:`${resul}`, align:"LEFT", width:0.5 },
          { text:`$${parseFloat(product.cost).toFixed(2)}`, align:"LEFT", width:0.25},
          { text:`$${parseFloat((product.cost * product.cant)).toFixed(2)}`, align:"LEFT", cols:7 }
        ]);
        
        (product.modifierProduct).map((modifierP)=>{
          if(modifierP?.id != null){
            total += modifierP.price * modifierP.cantModifier;
            thermalPrinter.tableCustom([                                       
              { text:`${modifierP.cantModifier}`, align:"LEFT", width:0.1 },
              { text:`*${modifierP.modifier.name}`, align:"LEFT", width:0.5 },
              { text:`$${parseFloat(modifierP.price).toFixed(2)}`, align:"LEFT", width:0.25},
              { text:`$${parseFloat(modifierP.price * modifierP.cantModifier).toFixed(2)}`, align:"LEFT", cols:7 }
            ]);
          }
        })

        // discount in modifier
        if(product.discount != null){
          if(product.discount.type == 1){
            total -= (product.discount.discountInfo * product.cost);
            thermalPrinter.tableCustom([                                       
              { text:`1`, align:"LEFT", width:0.1 },
              { text:`${product.discount.name}`, align:"LEFT", width:0.5 },
              { text:`-`, align:"LEFT", width:0.25,},
              { text:`-$${parseFloat(product.discount.discountInfo * product.cost).toFixed(2)}`, align:"LEFT", cols:6 }
            ]);
          }else{
            total -= product.discount.discountInfo;
            thermalPrinter.tableCustom([                                       
              { text:`1`, align:"LEFT", width:0.1 },
              { text:`${product.discount.name}`, align:"LEFT", width:0.5 },
              { text:`-`, align:"LEFT", width:0.25, },
              { text:`-$${parseFloat(product.discount.discountInfo).toFixed(2)}`, align:"LEFT", cols:6 }
            ]);
          }
        }
      }else{
        total += (product.cost * product.cant);                                    
        thermalPrinter.tableCustom([   
          { text:`${product.cant}`, align:"LEFT", width:0.1 },
          { text:`${product.name.substr(0,18)}`, align:"LEFT", width:0.5 },
          { text:`$${parseFloat(product.cost).toFixed(2)}`, align:"LEFT", width:0.25,},
          { text:`$${parseFloat((product.cost * product.cant)).toFixed(2)}`, align:"LEFT", cols:7 }
        ]);

        // discount off modifier
        if(product.discount != null){
          if(product.discount.type == 1){
            total -= (product.discount.discountInfo * product.cost);
            thermalPrinter.tableCustom([                                       
              { text:`1`, align:"LEFT", width:0.1 },
              { text:`${product.discount.name}`, align:"LEFT", width:0.5 },
              { text:`-`, align:"LEFT", width:0.25,},
              { text:`-$${parseFloat(product.discount.discountInfo * product.cost).toFixed(2)}`, align:"LEFT", cols:7 }
            ]);
          }else{
            total -= product.discount.discountInfo;
            thermalPrinter.tableCustom([                                       
              { text:`1`, align:"LEFT", width:0.1 },
              { text:`${product.discount.name}`, align:"LEFT", width:0.5 },
              { text:`-`, align:"LEFT", width:0.25,},
              { text:`-$${parseFloat(product.discount.discountInfo).toFixed(2)}`, align:"LEFT", cols:7 }
            ]);
          }
        }
      }
    })
    const totalDiscountSubchannel = total-discountSubchannel
    thermalPrinter.tableCustom([                                       
      { text:`Descuentos`, align:"LEFT", width:0.85 },
      { text:`$${parseFloat(discountSubchannel).toFixed(2)}`, align:"LEFT", cols:7 }
    ]);
    thermalPrinter.println(``);
    thermalPrinter.tableCustom([                                       
      { text:`Sub-total Ventas Gravadas`, align:"LEFT", width:0.85 },
      { text:`$${parseFloat(totalDiscountSubchannel).toFixed(2)}`, align:"LEFT", cols:7 }
    ]);

    thermalPrinter.tableCustom([                                       
      { text:`Sub-total Ventas Excentas`, align:"LEFT", width:0.85 },
      { text:`$0.00`, align:"LEFT", cols:7 }
    ]);

    thermalPrinter.tableCustom([                                       
      { text:`Sub-total Ventas No sujetas`, align:"LEFT", width:0.85 },
      { text:`$${parseFloat(totalDiscountSubchannel).toFixed(2)}`, align:"LEFT", cols:7 }
    ]);
    thermalPrinter.bold(true); 
    thermalPrinter.tableCustom([                                       
      { text:`TOTAL`, align:"LEFT", width:0.85 },
      { text:`$${parseFloat(totalDiscountSubchannel).toFixed(2)}`, align:"LEFT", cols:7 }
    ]);
    thermalPrinter.bold(false); 

    thermalPrinter.println(``);
    thermalPrinter.println(`Autorizado por Resolución ${(tiketConf.resolution).toUpperCase()}`);
    thermalPrinter.println(`DEL ${tiketConf.serie}${document.startCorrelative} AL ${tiketConf.serie}${document.finishCorrelative}`);
    thermalPrinter.println(`GIRO ${(tiketConf.item).toUpperCase()}`);
    thermalPrinter.println(`-Cuenta Cerrada-`);
    
    thermalPrinter.println(``);
    thermalPrinter.printQR(tiketConf.link, {
      cellSize: 8,             // 1 - 8
      correction: 'M',         // L(7%), M(15%), Q(25%), H(30%)
      model: 2                 // 1 - Model 1 2 - Model 2 (standard) 3 - Micro QR
    });  
    thermalPrinter.println(``);
    const paragraph1Text = ((tiketConf.paragraph1)).split('/');
    paragraph1Text.map((text)=>{
      thermalPrinter.println(text);
    })
    const paragraph2Text = ((tiketConf.paragraph2)).split('/');
    paragraph2Text.map((text)=>{
      thermalPrinter.println(text);
    })
    thermalPrinter.bold(true); 
    if(customerName != null && (channel == 4 || channel == 5)){
      thermalPrinter.println(`Nombre: ${customerName}`);
      thermalPrinter.println(``);
      thermalPrinter.println(``);
      thermalPrinter.println(``);
      thermalPrinter.println(`F_____________________________________________`);
      thermalPrinter.println(``);
    }
    thermalPrinter.cut();
    thermalPrinter.openCashDrawer();
    const data = thermalPrinter.getBuffer();
    printer.printDirect({
        data: data,
        type: 'RAW',
        printer : PRINTER,
        success:function(jobID){
            console.log("sent to printer with ID: "+jobID);
              // res.status(200).json({"success":'print successfull'});
        },
        error:function(err){console.log(err);
        }
    })
    printer.printDirect({
      data: data,
      type: 'RAW',
      printer : PRINTER,
      success:function(jobID){
        console.log("sent to printer with ID: "+jobID);
          // res.status(200).json({"success":'print successfull'});
        },
        error:function(err){console.log(err);
        }
      })
      res.status(200).json({"success":'print successfull'});
  } catch (error) {
    console.log(error)
    res.status(500).json({"error":error});
  }
};

export const printCanceledSale = async (req,res) =>{
  try {
    const {
      tiketConfiguration,
      detailSale,
      document,
      employeeName,
      typeTiket,
    } = req.body;


    const thermalPrinter = new ThermalPrinter({
      type: PrinterTypes.EPSON, 
      options: {
        timeout: 1000,
      }
    });
    // Header
    const tiketConf = tiketConfiguration[0];
    const date = moment(new Date()).format("YYYY-MM-DD");
    const hour = moment(new Date()).format("HH:mm:ss");


    thermalPrinter.alignCenter();
    thermalPrinter.bold(true); 
    thermalPrinter.println((tiketConf.enterprise).toUpperCase());
    thermalPrinter.println(`Fecha ${date} ${hour}`);
    thermalPrinter.println(`Tipo de documento ${(document.documentType.name).toUpperCase()}`);
    thermalPrinter.bold(false); 
    thermalPrinter.println((tiketConf.address).toUpperCase());
    thermalPrinter.println(`NIT: ${(tiketConf.nit).toUpperCase()}`);
    thermalPrinter.println(`CAJA ${(tiketConf.cashRegisterNumber).toUpperCase()} Tiquete N° ${document.actualCorrelative}`);
    thermalPrinter.println(`Cajero ${employeeName}`);
    thermalPrinter.println(``); 
    thermalPrinter.tableCustom([                                       
      { text:"CANT", align:"LEFT", width:0.1 },
      { text:"DESC.", align:"LEFT", width:0.5 },
      { text:"P/UNI", align:"CENTER", width:0.25, bold:true },
      { text:"TOTAL", align:"RIGHT", cols:7 }
    ]);

    // SALE DETAIL
    const detailSaleTypeProduct = detailSale.filter((product)=>{
      return product?.typeDetail == 0;
    })
    detailSaleTypeProduct.map((product)=>{
      if(product.modifier != ''){
        thermalPrinter.tableCustom([                                      
          { text:`${product.cant}`, align:"LEFT", width:0.1 },
          { text:`${product.product}`, align:"LEFT", width:0.5 },
          { text:`$${parseFloat(product.cost).toFixed(2)}`, align:"CENTER", width:0.25 },
          { text:`$${parseFloat((product.cost * product.cant)).toFixed(2)}`, align:"RIGHT", cols:7 }
        ]);
        const modifiers = ((product.modifier).split(' ').join('')).split('-');
        // the last productModifier Index delete
        const productsModifiers = modifiers.filter((modifier)=>{
          return (modifier.toLowerCase()).indexOf('$') === -1 && (modifier.toLowerCase()).indexOf('cant:');
        })
        // falta colocarlo en la factura
        const priceModifiers = modifiers.filter((modifier)=>{
          return (modifier.toLowerCase()).indexOf('$') !== -1;
        })
        // falta colocarlo en la factura
        const cantModifier = modifiers.filter((modifier)=>{
          return (modifier.toLowerCase()).indexOf('cant:') !== -1;
        })

        priceModifiers.forEach((priceModifier, index) => {
          const cantPriceModifier = cantModifier[index].slice(5);
          const costPriceModifier = priceModifiers[index].slice(1);
          thermalPrinter.tableCustom([                                       
            { text:`${cantPriceModifier}`, align:"LEFT", width:0.1 },
            { text:`*${productsModifiers[index]}`, align:"LEFT", width:0.5 },
            { text:`$${parseFloat(costPriceModifier).toFixed(2)}`, align:"CENTER", width:0.25 },
            { text:`$${parseFloat(cantPriceModifier*costPriceModifier).toFixed(2)}`, align:"RIGHT", cols:7 }
          ]);
        });
       
      }else{
        thermalPrinter.tableCustom([                                       
          { text:`${product.cant}`, align:"LEFT", width:0.1 },
          { text:`${product.product}`, align:"LEFT", width:0.5 },
          { text:`$${parseFloat(product.cost).toFixed(2)}`, align:"CENTER", width:0.25, bold:true },
          { text:`$${parseFloat((product.cost * product.cant)).toFixed(2)}`, align:"RIGHT", cols:7 }
        ]);
      }
    })

    thermalPrinter.println(``);
    thermalPrinter.println(`Autorizado por Resolución ${(tiketConf.resolution).toUpperCase()}`);
    thermalPrinter.println(`DEL ${tiketConf.serie}${document.startCorrelative} AL ${tiketConf.serie}${document.finishCorrelative}`);
    thermalPrinter.println(`GIRO ${(tiketConf.item).toUpperCase()}`);
    thermalPrinter.println(`-Cuenta Cerrada-`);
    
    thermalPrinter.alignCenter();
    thermalPrinter.setTextSize(3,5);  
    thermalPrinter.println(`${typeTiket == 1 ? 'CANCELADA' : 'DEVOLUCIÓN'}`);
    thermalPrinter.setTextNormal();  

    thermalPrinter.println(``);
    thermalPrinter.printQR(tiketConf.link, {
      cellSize: 8,             // 1 - 8
      correction: 'M',         // L(7%), M(15%), Q(25%), H(30%)
      model: 2                 // 1 - Model 1 2 - Model 2 (standard) 3 - Micro QR
      });  
      thermalPrinter.println(``);
      const paragraph1Text = ((tiketConf.paragraph1)).split('/');
      paragraph1Text.map((text)=>{
        thermalPrinter.println(text);
      })
      const paragraph2Text = ((tiketConf.paragraph2)).split('/');
      paragraph2Text.map((text)=>{
        thermalPrinter.println(text);
      })
      thermalPrinter.println(``);
      thermalPrinter.alignCenter();
      thermalPrinter.bold(true); 
      thermalPrinter.println((tiketConf.enterprise).toUpperCase());
      thermalPrinter.println(`Fecha ${date} ${hour}`);
      thermalPrinter.println(`Tipo de documento ${(document.documentType.name).toUpperCase()}`);
      thermalPrinter.bold(false); 
      thermalPrinter.println((tiketConf.address).toUpperCase());
      thermalPrinter.println(`NIT: ${(tiketConf.nit).toUpperCase()}`);
      thermalPrinter.println(`CAJA ${(tiketConf.cashRegisterNumber).toUpperCase()} Tiquete N° ${document.actualCorrelative}`);
      thermalPrinter.println(`Cajero ${employeeName}`);
      thermalPrinter.println(``); 
      thermalPrinter.println('Copia al cliente');
      thermalPrinter.alignCenter();
      thermalPrinter.setTextSize(3,5);  
      thermalPrinter.println(`${typeTiket == 1 ? 'CANCELADA' : 'DEVOLUCIÓN'}`);
      thermalPrinter.cut();
      if(typeTiket == 2){
      thermalPrinter.openCashDrawer();
      }
      const data = thermalPrinter.getBuffer();
    
    printer.printDirect({
        data: data,
        type: 'RAW',
        printer : PRINTER,
        success:function(jobID){
            console.log("sent to printer with ID: "+jobID);
              res.status(200).json({"success":'print successfull'});
        },
        error:function(err){console.log(err);
        }
    })
  } catch (error) {
    console.log(error)
    res.status(500).json({"error":error});
  }
};

export const printReportCut = async (req,res) => {
  try {
    const {
      tiketConfiguration,
      employeeName,
      reportsForCashDeskClosing,
      datePrint,
    } = req.body;

    const thermalPrinter = new ThermalPrinter({
      type: PrinterTypes.EPSON, 
      options: {
        timeout: 1000,
      }
    });
    // Header
    const tiketConf = tiketConfiguration[0];
    const date = datePrint;
    // const date = moment(new Date()).format("YYYY-MM-DD");
    const hour = moment(new Date()).format("HH:mm:ss");


    thermalPrinter.println((tiketConf.enterprise).toUpperCase());
    thermalPrinter.println((tiketConf.address).toUpperCase());
    thermalPrinter.println(`NIT: ${(tiketConf.nit).toUpperCase()}`);
    thermalPrinter.println(`CAJA ${(tiketConf.cashRegisterNumber).toUpperCase()}`);
    thermalPrinter.println(`Fecha ${date} ${hour}`);
    thermalPrinter.println(`Cajero ${employeeName}`);
    thermalPrinter.println(`Tipo de documento Reporte de faltante/sobrante`);
    thermalPrinter.println(``); 
    if((reportsForCashDeskClosing.data).length > 0){
      thermalPrinter.println(`EXPLICACIÓN: ${(reportsForCashDeskClosing.data)[0].description}`); 
    }
    thermalPrinter.tableCustom([                                       
      { text:"DETA.", align:"LEFT", width:0.5},
      { text:"SOBR.", align:"CENTER", width:0.25},
      { text:"FALT.", align:"RIGHT", cols:8 }
    ]);

    (reportsForCashDeskClosing.data).map((report)=>{
      thermalPrinter.tableCustom([                  
        { text:`${report.detail}`, align:"LEFT", width:0.5 },
        { text:`$${report.ofMore == null ? '0.00': parseFloat(report.ofMore).toFixed(2)}`, align:"CENTER", width:0.25 },
        { text:`$${report.missing == null ? '0.00': parseFloat(report.missing*-1).toFixed(2)}`, align:"RIGHT", cols:8 }
      ]);
    });
    
    thermalPrinter.println(``);
    thermalPrinter.println(`GIRO ${(tiketConf.item).toUpperCase()}`);

    thermalPrinter.println(``);
    thermalPrinter.println((tiketConf.enterprise).toUpperCase());
    thermalPrinter.println((tiketConf.address).toUpperCase());
    thermalPrinter.println(`NIT: ${(tiketConf.nit).toUpperCase()}`);
    thermalPrinter.println(`CAJA ${(tiketConf.cashRegisterNumber).toUpperCase()}`);
    thermalPrinter.println(`Fecha ${date} ${hour}`);
    
    thermalPrinter.cut();
    thermalPrinter.openCashDrawer();
    const data = thermalPrinter.getBuffer();
    
    printer.printDirect({
        data: data,
        type: 'RAW',
        printer : PRINTER,
        success:function(jobID){
            console.log("sent to printer with ID: "+jobID);
              res.status(200).json({"success":'print successfull'});
        },
        error:function(err){console.log(err);
        }
    })
  } catch (error) {
    console.log(error)
    res.status(500).json({"error":error});
  }
};

export const printCutX = async (req,res) => {
  try {
    const {
      tiketConfiguration,
      employeeName,
      detailPaymentMethodCashClosing,
      detailChannelCashClosing,
      reportsForCashDeskClosing,
      detailPaymentCut,
      detailSubchannelCut,
      datePrint,
      sales,
      saleDetailForSalesID
    } = req.body;
    let totalWithTaxCash = 0;
    let totalWithTaxCard = 0;
    let totalWithTaxBitcoin = 0;
    let totalWithTaxDeliery = 0;
    let totalWithTax = 0;

    const thermalPrinter = new ThermalPrinter({
      type: PrinterTypes.EPSON, 
      options: {
        timeout: 1000,
      }
    });
    
    const transactionsActive = (sales.data).filter((sale)=>{
      return sale.status == 0;
    });
    const transactions = transactionsActive.length;
    // SUM totalWithTax
    transactionsActive.map((sale)=>{
      if(sale?.paymentMethod == 'Dolar estadounidense'){
        totalWithTax = totalWithTax + sale?.totalWithTax;
        totalWithTaxCash = totalWithTaxCash + sale?.totalWithTax;
      }
      else if(sale?.paymentMethod == 'Delivery'){
        totalWithTaxDeliery = totalWithTaxDeliery + sale?.totalWithTax;
        totalWithTax = totalWithTax + sale?.totalWithTax;
      }
      else if(sale?.paymentMethod == 'Bitcoin'){
        totalWithTax = totalWithTax + sale?.totalWithTax;
        totalWithTaxBitcoin = totalWithTaxBitcoin + sale?.totalWithTax;
      }else{
        totalWithTax = totalWithTax + sale?.totalWithTax;
        totalWithTaxCard = totalWithTaxCard + sale?.totalWithTax;
      }
    })

    // Header
    const tiketConf = tiketConfiguration[0];
    // const date = moment(new Date()).format("YYYY-MM-DD");
    const date = datePrint;
    const hour = moment(new Date()).format("HH:mm:ss");

    thermalPrinter.alignCenter();
    thermalPrinter.bold(true); 
    thermalPrinter.println((tiketConf.enterprise).toUpperCase());
    thermalPrinter.bold(false); 
    thermalPrinter.println((tiketConf.address).toUpperCase());
    thermalPrinter.println(`NIT: ${(tiketConf.nit).toUpperCase()}`);
    thermalPrinter.println(`CAJA ${(tiketConf.cashRegisterNumber).toUpperCase()}`);
    thermalPrinter.println(`Cajero ${employeeName}`);
    thermalPrinter.bold(true); 
    thermalPrinter.println(`Fecha ${date} ${hour}`);
    thermalPrinter.println(`Tipo de documento CorteX`);
    thermalPrinter.bold(false); 
    thermalPrinter.println(``); 
    thermalPrinter.tableCustom([                     
      { text:"SUBTOTAL GRAVADO:", align:"LEFT", width:0.5 },
      { text:`$${parseFloat(totalWithTax).toFixed(2)}`, align:"LEFT", cols:7 }
    ]);
    thermalPrinter.tableCustom([                     
      { text:"SUBTOTAL EXCENTO:", align:"LEFT", width:0.5 },
      { text:`$${parseFloat(0).toFixed(2)}`, align:"LEFT", cols:8 }
    ]);
    thermalPrinter.tableCustom([                     
      { text:"SUBTOTAL NO SUJETAS:", align:"LEFT", width:0.5 },
      { text:`$${parseFloat(0).toFixed(2)}`, align:"LEFT", cols:8 }
    ]);
    thermalPrinter.tableCustom([                     
      { text:"DESCUENTOS:", align:"LEFT", width:0.5 },
      { text:`$${parseFloat(0).toFixed(2)}`, align:"LEFT", cols:8 }
    ]);
    thermalPrinter.tableCustom([                     
      { text:"DEVOLUCION:", align:"LEFT", width:0.5 },
      { text:`$${parseFloat(0).toFixed(2)}`, align:"LEFT", cols:8 }
    ]);
    thermalPrinter.println(`Transacciones: ${transactions}`);
    thermalPrinter.println(`Devoluciones: 0`);
    thermalPrinter.println(``);
    thermalPrinter.println(`______________________________________________`);
    thermalPrinter.println(`RESUMEN DE PAGOS`);
    thermalPrinter.tableCustom([                     
      { text:"EFECTIVO:", align:"LEFT", width:0.5 },
      { text:`$${parseFloat(totalWithTaxCash).toFixed(2)}`, align:"LEFT", cols:8}
    ]);
    thermalPrinter.tableCustom([                     
      { text:"TARJETA:", align:"LEFT", width:0.5 },
      { text:`$${parseFloat(totalWithTaxCard).toFixed(2)}`, align:"LEFT", cols:8}
    ]);
    thermalPrinter.tableCustom([                     
      { text:"BITCOIN:", align:"LEFT", width:0.5 },
      { text:`$${parseFloat(totalWithTaxBitcoin).toFixed(2)}`, align:"LEFT", cols:8}
    ]);
    thermalPrinter.tableCustom([                     
      { text:"DELIVERY:", align:"LEFT", width:0.5 },
      { text:`$${parseFloat(totalWithTaxDeliery).toFixed(2)}`, align:"LEFT", cols:8}
    ]);
    thermalPrinter.tableCustom([                     
      { text:"CUPONES:", align:"LEFT", width:0.5 },
      { text:`$${parseFloat(0).toFixed(2)}`, align:"LEFT", cols:6 }
    ]);
    thermalPrinter.println(``); 
    thermalPrinter.println(``); 
    thermalPrinter.println(``); 
    // thermalPrinter.tableCustom([                     
    //   { text:"DESC.", align:"LEFT", width:0.5 },
    //   { text:"TOTAL", align:"RIGHT", cols:6 }
    // ]);

    // (detailPaymentMethodCashClosing.data).map((paymentMethod)=>{
    //   thermalPrinter.tableCustom([                  
    //     { text:`${paymentMethod.paymentMethodDetail.name}`, align:"LEFT", width:0.5 },
    //     { text:`$${parseFloat(paymentMethod.total).toFixed(2)}`, align:"RIGHT", cols:8 }
    //   ]);
    // });

    // (detailChannelCashClosing.data).map((channelCash)=>{
    //   thermalPrinter.tableCustom([                  
    //     { text:`${channelCash.subchannel.name}`, align:"LEFT", width:0.5 },
    //     { text:`$${parseFloat(channelCash.total).toFixed(2)}`, align:"RIGHT", cols:6 }
    //   ]);
    // });    
    thermalPrinter.println(`RESUMEN DE REPORTES`);
    thermalPrinter.tableCustom([                                       
      { text:"DETA.", align:"LEFT", width:0.5},
      { text:"SOBR.", align:"CENTER", width:0.25},
      { text:"FALT.", align:"RIGHT", cols:8 }
    ]);
    (reportsForCashDeskClosing.data).map((report)=>{
      thermalPrinter.tableCustom([                  
        { text:`${report.detail}`, align:"LEFT", width:0.5 },
        { text:`$${report.ofMore == null ? '0.00': parseFloat(report.ofMore).toFixed(2)}`, align:"CENTER", width:0.25 },
        { text:`$${report.missing == null ? '0.00': parseFloat(report.missing*-1).toFixed(2)}`, align:"RIGHT", cols:8 }
      ]);
    });

    thermalPrinter.println(`RESUMEN DE INGRESO DE CORTE X`);
    detailPaymentCut.map((payment)=>{
      thermalPrinter.tableCustom([
        { text:`${payment.name}`, align:"LEFT", width:0.22 },
        { text:`$${parseFloat(payment.money).toFixed(2)}`, align:"LEFT", cols:7 }
      ]);
    });
    detailSubchannelCut.map((subchannel)=>{
      thermalPrinter.tableCustom([
        { text:`${subchannel.name}`, align:"LEFT", width:0.16 },
        { text:`$${parseFloat(subchannel.money).toFixed(2)}`, align:"LEFT", cols:7 }
      ]);
    });

    thermalPrinter.println(`REVISADO POR _________________________________`);
    thermalPrinter.println(``);
    thermalPrinter.println(`RESUMEN DE VENTAS POR PRODUCTOS`);

    let productsArray = [];
    let modifiersArray = [];
    const detailSaleTypeProduct = saleDetailForSalesID.filter((product)=>{
      return product?.typeDetail == 0;
    })
    detailSaleTypeProduct.map((saleDetail)=>{
      productsArray.push({
        name:saleDetail.product,
        cant:saleDetail.cant,
        price:(saleDetail.cant * saleDetail.price.price),
        modifier:saleDetail.modifier
      })

      if(saleDetail.modifier != ''){
        // aca veremos los modificadores
        const modifiers = ((saleDetail.modifier).split(' ').join('')).split('-');
        // the last productModifier Index delete
        const productsModifiers = modifiers.filter((modifier)=>{
          return (modifier.toLowerCase()).indexOf('$') === -1 && (modifier.toLowerCase()).indexOf('cant:');
        })
        // falta colocarlo en la factura
        const priceModifiers = modifiers.filter((modifier)=>{
          return (modifier.toLowerCase()).indexOf('$') !== -1;
        })
        // falta colocarlo en la factura
        const cantModifier = modifiers.filter((modifier)=>{
          return (modifier.toLowerCase()).indexOf('cant:') !== -1;
        })

        priceModifiers.forEach((priceModifier, index) => {
          const cantPriceModifier = parseInt(cantModifier[index].slice(5));
          const costPriceModifier = parseFloat(priceModifiers[index].slice(1));
          const totalPriceModifier = parseFloat(cantPriceModifier*costPriceModifier)
          modifiersArray.push({
            name:productsModifiers[index],
            cant:parseInt(cantPriceModifier),
            price:parseFloat(totalPriceModifier).toFixed(2)
          }
          )
        });
      }

    });
    // last dataProduct
    let dataProduct=[];
    productsArray.map((product)=>{
      const filt = dataProduct.filter((product2)=>{
          return product?.name?.toLowerCase() == product2?.name?.toLowerCase();
      })
      if(filt.length > 0){
        // Aca debo de sumar los que ya se encuentren
        dataProduct.map((product2, index2)=>{
          if(product.name == product2.name){
            dataProduct[index2] = {
              name:product.name,
              cant:parseInt(product.cant) + parseInt(product2.cant),
              price:parseFloat(product.price) + parseFloat(product2.price),
              modifier:product.modifier
            }
          }
        })
      }else{
        dataProduct.push(product);
      }
    });

    // modifiersArray
    let dataModifier=[];
    modifiersArray.map((product)=>{
      const filt = dataModifier.filter((product2)=>{
          return product?.name?.toLowerCase() == product2?.name?.toLowerCase();
      })
      if(filt.length > 0){
        // Aca debo de sumar los que ya se encuentren
        dataModifier.map((product2, index2)=>{
          if(product.name == product2.name){
            const plus = parseInt(product.cant) + parseInt(product2.cant);
            const plusPrice = parseFloat(product.price) + parseFloat(product2.price)
            dataModifier[index2] = {
              name:product.name,
              cant:plus,
              price:parseFloat(plusPrice).toFixed(2)
            }
          }
        })
      }else{
        dataModifier.push(product);
      }
    });

    // print dataProductDetail
    dataProduct.map((product)=>{
      thermalPrinter.tableCustom([
        { text:`${product.name}`, align:"LEFT", width:0.6 },
        { text:`${product.cant}`, align:"LEFT", width:0.20},
        { text:`$${parseFloat(product.price).toFixed(2)}`, align:"LEFT", cols:8 }
      ]);
    });
    dataModifier.map((product)=>{
      thermalPrinter.tableCustom([
        { text:`*${product.name}`, align:"LEFT", width:0.6 },
        { text:`${product.cant}`, align:"LEFT", width:0.20},
        { text:`$${parseFloat(product.price).toFixed(2)}`, align:"LEFT", cols:8 }
      ]);
    });


    thermalPrinter.println(``);
    thermalPrinter.println(`GIRO ${(tiketConf.item).toUpperCase()}`);
    thermalPrinter.println(``);
    thermalPrinter.bold(true); 
    thermalPrinter.println((tiketConf.enterprise).toUpperCase());
    thermalPrinter.bold(false); 
    thermalPrinter.println((tiketConf.address).toUpperCase());
    thermalPrinter.println(`NIT: ${(tiketConf.nit).toUpperCase()}`);
    thermalPrinter.bold(true); 
    thermalPrinter.println(`CAJA ${(tiketConf.cashRegisterNumber).toUpperCase()}`);
    thermalPrinter.println(`Fecha ${date} ${hour}`);
    thermalPrinter.bold(false); 
    thermalPrinter.cut();
    thermalPrinter.openCashDrawer();
    const data = thermalPrinter.getBuffer();
    
    printer.printDirect({
        data: data,
        type: 'RAW',
        printer : PRINTER,
        success:function(jobID){
            console.log("sent to printer with ID: "+jobID);
              res.status(200).json({"success":'print successfull'});
        },
        error:function(err){console.log(err);
        }
    })
  } catch (error) {
    console.log(error)
    res.status(500).json({"error":error});
  }
};

export const printCutZ = async (req,res) => {
  try {
    const {
      tiketConfiguration,
      employeeName,
      detailPaymentMethodCashClosing,
      detailChannelCashClosing,
      datePrint,
      sales,
      saleDetailForSalesID
    } = req.body;
    const transactions = sales.length;
    let totalWithTaxCash = 0;
    let totalWithTaxCard = 0;
    let totalWithTaxBitcoin = 0;
    let totalWithTaxDeliery = 0;
    let totalWithTax = 0;
    const thermalPrinter = new ThermalPrinter({
      type: PrinterTypes.EPSON, 
      options: {
        timeout: 1000,
      }
    });
    // SUM totalWithTax
    sales.map((sale)=>{
      if(sale?.paymentMethod == 'Dolar estadounidense'){
        totalWithTaxCash = totalWithTaxCash + sale?.totalWithTax;
        totalWithTax = totalWithTax + sale?.totalWithTax;
      }
      else if(sale?.paymentMethod == 'Delivery'){
        totalWithTaxDeliery = totalWithTaxDeliery + sale?.totalWithTax;
        totalWithTax = totalWithTax + sale?.totalWithTax;
      }
      else if(sale?.paymentMethod == 'Bitcoin'){
        totalWithTax = totalWithTax + sale?.totalWithTax;
        totalWithTaxBitcoin = totalWithTaxBitcoin + sale?.totalWithTax;
      }else{
        totalWithTax = totalWithTax + sale?.totalWithTax;
        totalWithTaxCard = totalWithTaxCard + sale?.totalWithTax;
      }
    })
    // Header
    const tiketConf = tiketConfiguration[0];
    const date = datePrint;
    // const date = moment(new Date()).format("YYYY-MM-DD");
    const hour = moment(new Date()).format("HH:mm:ss");


    thermalPrinter.println((tiketConf.enterprise).toUpperCase());
    thermalPrinter.println((tiketConf.address).toUpperCase());
    thermalPrinter.println(`NIT: ${(tiketConf.nit).toUpperCase()}`);
    thermalPrinter.println(`CAJA ${(tiketConf.cashRegisterNumber).toUpperCase()}`);
    thermalPrinter.println(`Fecha ${date} ${hour}`);
    thermalPrinter.println(`Cajero ${employeeName}`);
    thermalPrinter.println(`Tipo de documento Corte Z`);
    thermalPrinter.println(``); 
    thermalPrinter.tableCustom([                     
      { text:"SUBTOTAL GRAVADO:", align:"LEFT", width:0.5 },
      { text:`$${parseFloat(totalWithTax).toFixed(2)}`, align:"RIGHT", cols:6 }
    ]);
    thermalPrinter.tableCustom([                     
      { text:"SUBTOTAL EXCENTO:", align:"LEFT", width:0.5 },
      { text:`$${parseFloat(0).toFixed(2)}`, align:"RIGHT", cols:6 }
    ]);
    thermalPrinter.tableCustom([                     
      { text:"SUBTOTAL NO SUJETAS:", align:"LEFT", width:0.5 },
      { text:`$${parseFloat(0).toFixed(2)}`, align:"RIGHT", cols:6 }
    ]);
    thermalPrinter.tableCustom([                     
      { text:"DESCUENTOS:", align:"LEFT", width:0.5 },
      { text:`$${parseFloat(0).toFixed(2)}`, align:"RIGHT", cols:6 }
    ]);
    thermalPrinter.tableCustom([                     
      { text:"DEVOLUCION:", align:"LEFT", width:0.5 },
      { text:`$${parseFloat(0).toFixed(2)}`, align:"RIGHT", cols:6 }
    ]);
    thermalPrinter.println(`Transacciones: ${transactions}`);
    thermalPrinter.println(`Devoluciones: 0`);
    thermalPrinter.println(``);
    thermalPrinter.println(`RESUMEN DE PAGOS`);
    thermalPrinter.tableCustom([                     
      { text:"EFECTIVO:", align:"LEFT", width:0.5 },
      { text:`$${parseFloat(totalWithTaxCash).toFixed(2)}`, align:"RIGHT", cols:6 }
    ]);
    thermalPrinter.tableCustom([                     
      { text:"TARJETA:", align:"LEFT", width:0.5 },
      { text:`$${parseFloat(totalWithTaxCard).toFixed(2)}`, align:"RIGHT", cols:6 }
    ]);
    thermalPrinter.tableCustom([                     
      { text:"BITCOIN:", align:"LEFT", width:0.5 },
      { text:`$${parseFloat(totalWithTaxBitcoin).toFixed(2)}`, align:"RIGHT", cols:6 }
    ]);
    thermalPrinter.tableCustom([                     
      { text:"CUPONES:", align:"LEFT", width:0.5 },
      { text:`$${parseFloat(0).toFixed(2)}`, align:"RIGHT", cols:6 }
    ]);
    thermalPrinter.println(``); 


    // thermalPrinter.tableCustom([                     
    //   { text:"DESC.", align:"LEFT", width:0.5 },
    //   { text:"TOTAL", align:"RIGHT", cols:6 }
    // ]);

    // (detailPaymentMethodCashClosing.data).map((paymentMethod)=>{
    //   thermalPrinter.tableCustom([                  
    //     { text:`${paymentMethod.paymentMethodDetail.name}`, align:"LEFT", width:0.5 },
    //     { text:`$${parseFloat(paymentMethod.total).toFixed(2)}`, align:"RIGHT", cols:8 }
    //   ]);
    // });

    // (detailChannelCashClosing.data).map((channelCash)=>{
    //   thermalPrinter.tableCustom([                  
    //     { text:`${channelCash.subchannel.name}`, align:"LEFT", width:0.5 },
    //     { text:`$${parseFloat(channelCash.total).toFixed(2)}`, align:"RIGHT", cols:8 }
    //   ]);
    // });    


    thermalPrinter.println(``);
    thermalPrinter.println(`REVISADO POR _________________________________`);
    thermalPrinter.println(``);
    thermalPrinter.println(`RESUMEN DE PRODUCTOS`);

    let productsArray = [];
    let modifiersArray = [];
    
    const detailSaleTypeProduct = saleDetailForSalesID.filter((product)=>{
      return product?.typeDetail == 0;
    })
    detailSaleTypeProduct.map((saleDetail)=>{
      productsArray.push({
        name:saleDetail.product,
        cant:parseInt(saleDetail.cant),
        price:(parseInt(saleDetail.cant )*parseFloat(saleDetail.price.price)),
      })

      if(saleDetail.modifier != ''){
        // aca veremos los modificadores
        const modifiers = ((saleDetail.modifier).split(' ').join('')).split('-');
        // the last productModifier Index delete
        const productsModifiers = modifiers.filter((modifier)=>{
          return (modifier.toLowerCase()).indexOf('$') === -1 && (modifier.toLowerCase()).indexOf('cant:');
        })
        // falta colocarlo en la factura
        const priceModifiers = modifiers.filter((modifier)=>{
          return (modifier.toLowerCase()).indexOf('$') !== -1;
        })
        // falta colocarlo en la factura
        const cantModifier = modifiers.filter((modifier)=>{
          return (modifier.toLowerCase()).indexOf('cant:') !== -1;
        })

        priceModifiers.forEach((priceModifier, index) => {
          const cantPriceModifier = parseInt(cantModifier[index].slice(5));
          const costPriceModifier = parseFloat(priceModifiers[index].slice(1));
          const totalPriceModifier = parseFloat(cantPriceModifier) * parseFloat(costPriceModifier)
          modifiersArray.push({
            name:productsModifiers[index],
            cant:parseInt(cantPriceModifier),
            price:parseFloat(totalPriceModifier).toFixed(2)
          }
          )
        });
      }
    });


    // last dataProduct
    let dataProduct=[];
    productsArray.map((product)=>{
      const filt = dataProduct.filter((product2)=>{
          return product?.name?.toLowerCase() == product2?.name?.toLowerCase();
      })
      if(filt.length > 0){
        // Aca debo de sumar los que ya se encuentren
        dataProduct.map((product2, index2)=>{
          if(product.name == product2.name){
            dataProduct[index2] = {
              name:product.name,
              cant:parseInt(product.cant) + parseInt(product2.cant),
              price:parseFloat(product.price) + parseFloat(product2.price),
            }
          }
        })
      }else{
        dataProduct.push(product);
      }
    });

    // modifiersArray
    let dataModifier=[];
    modifiersArray.map((product)=>{
      const filt = dataModifier.filter((product2)=>{
          return product?.name?.toLowerCase() == product2?.name?.toLowerCase();
      })
      if(filt.length > 0){
        // Aca debo de sumar los que ya se encuentren
        dataModifier.map((product2, index2)=>{
          if(product.name == product2.name){
            const plus = parseInt(product.cant) + parseInt(product2.cant);
            const plusPrice = parseFloat(product.price) + parseFloat(product2.price)
            dataModifier[index2] = {
              name:product.name,
              cant:plus,
              price:parseFloat(plusPrice).toFixed(2)
            }
          }
        })
      }else{
        dataModifier.push(product);
      }
    });

    // print dataProductDetail
    dataProduct.map((product)=>{
      thermalPrinter.tableCustom([
        { text:`${product.name}`, align:"LEFT", width:0.6 },
        { text:`${product.cant}`, align:"LEFT", width:0.25},
        { text:`$${parseFloat(product.price).toFixed(2)}`, align:"LEFT", cols:7 }
      ]);
    });
    // print dataModifierDetail
    dataModifier.map((product)=>{
      thermalPrinter.tableCustom([
        { text:`*${product.name}`, align:"LEFT", width:0.6 },
        { text:`${product.cant}`, align:"LEFT", width:0.25},
        { text:`$${parseFloat(product.price).toFixed(2)}`, align:"LEFT", cols:7 }
      ]);
    });

    thermalPrinter.println(``);
    thermalPrinter.println(`GIRO ${(tiketConf.item).toUpperCase()}`);

    thermalPrinter.println(``);
    thermalPrinter.println((tiketConf.enterprise).toUpperCase());
    thermalPrinter.println((tiketConf.address).toUpperCase());
    thermalPrinter.println(`NIT: ${(tiketConf.nit).toUpperCase()}`);
    thermalPrinter.println(`CAJA ${(tiketConf.cashRegisterNumber).toUpperCase()}`);
    thermalPrinter.println(`Fecha ${date} ${hour}`);
    
    thermalPrinter.cut();
    thermalPrinter.openCashDrawer();
    const data = thermalPrinter.getBuffer();
    printer.printDirect({
        data: data,
        type: 'RAW',
        printer : PRINTER,
        success:function(jobID){
            // console.log("sent to printer with ID: "+jobID);
              res.status(200).json({"success":'print successfull'});
        },
        error:function(err){console.log(err);
        }
    })
  } catch (error) { 
    console.log(error)
    res.status(500).json({"error":error});
  }
};

export const printOutputCash = async (req,res) => {
  try {
    const {
      tiketConfiguration,
      employeeName,
      outputCash,
      totalOutputCashDesk,
      description,
    } = req.body;

    const thermalPrinter = new ThermalPrinter({
      type: PrinterTypes.EPSON, 
      options: {
        timeout: 1000,
      }
    });
    // Header
    const tiketConf = tiketConfiguration[0];
    const date = moment(new Date()).format("YYYY-MM-DD");
    const hour = moment(new Date()).format("HH:mm:ss");


    thermalPrinter.println((tiketConf.enterprise).toUpperCase());
    thermalPrinter.println((tiketConf.address).toUpperCase());
    thermalPrinter.println(`NIT: ${(tiketConf.nit).toUpperCase()}`);
    thermalPrinter.println(`CAJA ${(tiketConf.cashRegisterNumber).toUpperCase()}`);
    thermalPrinter.println(`Fecha ${date} ${hour}`);
    thermalPrinter.println(`Cajero ${employeeName}`);
    thermalPrinter.println(`---RETIRO DE EFECTIVO---`);
    thermalPrinter.println(``); 
    thermalPrinter.println(`SALDO PREVIO`); 
    const totalOut = (parseFloat(outputCash)+parseFloat(totalOutputCashDesk))
    thermalPrinter.println(`${parseFloat(totalOut).toFixed(2)}`); 
    thermalPrinter.println(`SALDO DE SALIDA`); 
    thermalPrinter.println(`${parseFloat(outputCash).toFixed(2)}`); 
    thermalPrinter.println(`SALDO RESTANTE`); 
    thermalPrinter.println(`${parseFloat(totalOutputCashDesk).toFixed(2)}`); 
    thermalPrinter.println(`DESCRIPCIÓN DE RETIRO`); 
    thermalPrinter.println(`${description}`); 
    


    thermalPrinter.println(``);
    thermalPrinter.println(`GIRO ${(tiketConf.item).toUpperCase()}`);

    thermalPrinter.println(``);
    thermalPrinter.println((tiketConf.enterprise).toUpperCase());
    thermalPrinter.println((tiketConf.address).toUpperCase());
    thermalPrinter.println(`NIT: ${(tiketConf.nit).toUpperCase()}`);
    thermalPrinter.println(`CAJA ${(tiketConf.cashRegisterNumber).toUpperCase()}`);
    thermalPrinter.println(`Fecha ${date} ${hour}`);
    
    thermalPrinter.cut();
    thermalPrinter.openCashDrawer();
    const data = thermalPrinter.getBuffer();
    
    printer.printDirect({
        data: data,
        type: 'RAW',
        printer : PRINTER,
        success:function(jobID){
            console.log("sent to printer with ID: "+jobID);
              res.status(200).json({"success":'print successfull'});
        },
        error:function(err){console.log(err);
        }
    })
  } catch (error) {
    console.log(error)
    res.status(500).json({"error":error});
  }
};
