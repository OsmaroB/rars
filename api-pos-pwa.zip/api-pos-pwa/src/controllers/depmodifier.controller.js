import { Depmodifiers } from '../models/DepModifiers.js';
import {Modifiers} from '../models/Modifiers.js';
import { Submodifiers } from '../models/Submodifiers.js';
import {maskText} from '../global/mask.js';

export const getDepmodifiers = async (req, res) => {
    try {
        const depmodifiers = await Depmodifiers.findAll({
            include:[
                {model: Submodifiers,
                    include:[
                        {model: Modifiers}
                    ]
                }
            ]
        });
        res.json(depmodifiers);
    } catch (error) {
        return res.status(500).json({message: error.message})
    }
};

export const getDepmodifierForId = async (req, res) => {
    try {
        const {id} = req.params;
        const depmodifier = await Depmodifiers.findByPk(id);
        res.json(depmodifier);
    } catch (error) {
        return res.status(500).json({message: error.message})
    }
};

export const createDepmodifier = async (req, res) => {
    const {mask, name, status, submodifierID, userCreate} = req.body;
    if(!name) return res.sendStatus(400);
    try {
        const newDepmodifier = await Depmodifiers.create({
            mask,
            name,
            status,
            submodifierID,
            userCreate
        });
        const depmodifier = await Depmodifiers.findByPk(newDepmodifier.id);
        depmodifier.mask = maskText('SUBMOD', newDepmodifier.id);
        await depmodifier.save();
        res.status(200).json(depmodifier);
    } catch (error) {
        return res.status(500).json({message: error.message});
    }
};

export const updateDepmodifier = async (req, res) => {
    try {
        const {id} = req.params;
        const {name, submodifierID, userUpdate} = req.body;
        if(!name || !id) return res.sendStatus(400);

        const depmodifier = await Depmodifiers.findByPk(id);
        depmodifier.name = name;
        depmodifier.userUpdate = userUpdate;
        depmodifier.submodifierID = submodifierID;
        await depmodifier.save();
        res.json(depmodifier);
    } catch (error) {
        return res.status(500).json({message: error.message});
    }
};

export const statusDepmodifier = async (req, res) => {
    try {
        const {id} = req.params;
        const {status} = req.body;
        const depmodifier = await Depmodifiers.findByPk(id);
        depmodifier.status = status;
        await depmodifier.save();
        res.json(depmodifier);
    } catch (error) {
        return res.status(500).json({message: error.message});
    }
};