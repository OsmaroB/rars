import {ButtonDetails} from '../models/ButtonDetails.js';
import {Products} from '../models/Products.js';
import {Buttons} from '../models/Buttons.js'

export const getButtonDetails = async (req, res) => {
    try {
        const buttonDetails = await ButtonDetails.findAll({
            include:[
                {model: Buttons},{model: Products}
            ]
        });
        res.json(buttonDetails);
    } catch (error) {
        console.log(error);
        return res.status(500).json({message: error.message})
    }
};

export const getButtonDetailForId = async (req, res) => {
    try {
        const {id} = req.params;
        const buttonDetail = await ButtonDetails.findOne({
            where:{
                id
            },
            include:[
                {model: Buttons},{model: Products}
            ]
        });
        res.json(buttonDetail);
    } catch (error) {
        return res.status(500).json({message: error.message});
    }
};

export const createButtonDetail = async (req, res) => {
    const {
        status,
        productID,
        buttonID,
        userCreate
    } = req.body;
    try {
        const newButtonDetail = await ButtonDetails.create({
            status,
            productID,
            buttonID,
            userCreate
        });
        res.status(200).json(newButtonDetail);
    } catch (error) {
        return res.status(500).json({message: error.message});
    }
};

export const updateButtonDetail = async (req, res) => {
    try {
        const {id} = req.params;
        const {
            productID,
            buttonID,
            userUpdate
        } = req.body;
        const buttonDetail = await ButtonDetails.findByPk(id);
        buttonDetail.productID = productID;
        buttonDetail.buttonID = buttonID;
        buttonDetail.userUpdate = userUpdate;
        await buttonDetail.save();
        res.json(buttonDetail);
    } catch (error) {
        return res.status(500).json({message: error.message});
    }
};

export const statusButtonDetail = async (req, res) => {
    try {
        const {id} = req.params;
        const {status} = req.body;
        const buttonDetail = await ButtonDetails.findByPk(id);
        buttonDetail.status = status;
        await buttonDetail.save();
        res.json(buttonDetail);
    } catch (error) {
        return res.status(500).json({message: error.message});
    }
};