import {SaleDetails} from '../models/SaleDetails.js';
import { Sales } from '../models/Sales.js';
import {Prices} from '../models/Prices.js';
import {maskText} from '../global/mask.js';
import { Op } from 'sequelize';
import { ButtonDetails } from '../models/ButtonDetails.js';
import { Products } from '../models/Products.js';
import { Buttons } from '../models/Buttons.js';
import { ButtonCategories } from '../models/ButtonCategories.js';
import { Categories } from '../models/Categories.js';
import { ChannelsSubchannels } from '../models/ChannelsSubchannels.js';
import { Subchannel } from '../models/Subchannel.js';
import { OptionalProducts } from '../models/OptionalProducts.js';
import { Optionals } from '../models/Optionals.js';
import { ModifierProducts } from '../models/ModifierProducts.js';
import { Modifiers } from '../models/Modifiers.js';
import { Submodifiers } from '../models/Submodifiers.js';
import { Depmodifiers } from '../models/DepModifiers.js';
import { Discounts } from '../models/Discounts.js';


export const getSaleDetails = async (req, res) => {
    try {
        const saleDetails = await SaleDetails.findAll({
            include:[
                {model: Sales},
                {model: Prices},
            ]
        });
        res.json(saleDetails);
    } catch (error) {
        return res.status(500).json({message: error.message})
    }
};

export const getSaleDetailForSaleID = async (req,res)=>{
    try {
        const {
            data
        } = req.body;
        console.log(data);
        if(data.length > 0){
            try {
                const saleDetails = await SaleDetails.findAll({
                    where:{
                      saleID:{
                        [Op.between]:[data[0].id, data[data.length-1].id]
                      }
                    },
                    include:[
                      {model:Prices,
                        include:[
                          { model: ButtonDetails, 
                              include:[
                                  {model: Products},
                                  {model: Buttons,
                                      where:{
                                          id:{
                                              [Op.not]: null
                                          }  
                                      },
                                      include:[
                                          {model:ButtonCategories,
                                              include:[
                                                  {
                                                      model:Categories,
                                                      where:{
                                                          status:0
                                                      }
                                                  },
                                              ],
                                              where:{
                                                  CategoryID:{
                                                      [Op.not]: null
                                                  }
                                              }
                                          }
                                      ]
                                  }
                              ],
                              where:{
                                  buttonID:{
                                      [Op.not]: null
                                  }
                              }
                          },
                          { model: ChannelsSubchannels },
                          { model: Subchannel,
                              include:[{model: ChannelsSubchannels}]    
                          },
                          { model: OptionalProducts, 
                              include:[
                                  {model: Optionals}, 
                                  {model: Products}
                              ] 
                          },
                          {   model: ModifierProducts,
                              include:[
                                  {model: Modifiers},
                                  {model: Products},
                                  {model: Submodifiers},
                                  {model: Depmodifiers},
                              ]
                          },{
                              model: Discounts,
                          }
              
                        ]
                      }
                    ]
                })
                console.log(saleDetails);
                res.json(saleDetails);
            } catch (error) {
                res.json({error})
            }
        }
        return res.status(500).json({message: 'No se han realizado ventas en este corte'})
    } catch (error) {
        
    }
}

export const getSaleDetailsForSaleID = async (req,res)=>{
    try {
        const {saleID} = req.body;
        console.log(saleID);
        const saleDetails = await SaleDetails.findAll({
            include:[
                {model: Sales},
                {model: Prices},
            ],
            where:{
                saleID
            },
        });
        res.json(saleDetails);
    } catch (error) {
        return res.status(500).json({message: error.message})
    }
};

export const getSaleDetailForId = async (req, res) => {
    try {
        const {id} = req.params;
        const saleDetails = await SaleDetails.findByPk(id);
        res.json(saleDetails);
    } catch (error) {
        return res.status(500).json({message: error.message})
    }
};

export const createSaleDetail = async (req, res) => {
    const {
        tiketNumber,
        line,
        product,
        cant,
        cost,
        description,
        modifier,
        cashRegisterNumber,
        restaurant,
        channel,
        paymentMethod,
        date,
        hour,
        totalWithoutTax,
        discountLine,
        totalWithDiscount,
        tax,
        totalWithTax,
        tip,
        priceID,
        saleID,
        userCreate, 
        maskDetail,
        typeDetail
    } = req.body;
    try {
        const newSaleDetail = await SaleDetails.create({
            tiketNumber,
            line,
            product,
            cant,
            cost,
            description,
            modifier,
            cashRegisterNumber,
            restaurant,
            channel,
            paymentMethod,
            date,
            hour,
            totalWithoutTax,
            discountLine,
            totalWithDiscount,
            tax,
            totalWithTax,
            tip,
            priceID,
            saleID,
            userCreate,
            maskDetail,
            typeDetail,
        });
        const saleDetail = await SaleDetails.findByPk(newSaleDetail.id);
        saleDetail.mask = maskText('SALE', newSaleDetail.id);
        await saleDetail.save();
        res.status(200).json(saleDetail);
    } catch (error) {
        return res.status(500).json({message: error.message});
    }
};

export const updateSaleDetail = async (req, res) => {
    try {
        const {id} = req.params;
        const {
            tiketNumber,
            line,
            product,
            cant,
            cost,
            description,
            modifier,
            cashRegisterNumber,
            restaurant,
            channel,
            paymentMethod,
            date,
            hour,
            totalWithoutTax,
            discountLine,
            totalWithDiscount,
            tax,
            totalWithTax,
            tip,
            priceID,
            saleID,
            userUpdate
        } = req.body;

        const saleDetail = await SaleDetails.findByPk(id);
        saleDetail.tiketNumber = tiketNumber;
        saleDetail.line = line;
        saleDetail.product = product;
        saleDetail.cant = cant;
        saleDetail.cost = cost;
        saleDetail.description = description;
        saleDetail.modifier = modifier;
        saleDetail.cashRegisterNumber = cashRegisterNumber;
        saleDetail.restaurant = restaurant;
        saleDetail.channel = channel;
        saleDetail.paymentMethod = paymentMethod;
        saleDetail.date = date;
        saleDetail.hour = hour;
        saleDetail.totalWithoutTax = totalWithoutTax;
        saleDetail.discountLine = discountLine;
        saleDetail.totalWithDiscount = totalWithDiscount;
        saleDetail.tax = tax;
        saleDetail.totalWithTax = totalWithTax;
        saleDetail.tip = tip;
        saleDetail.priceID = priceID;
        saleDetail.saleID = saleID;
        saleDetail.userUpdate = userUpdate;
        await saleDetail.save();
        res.json(saleDetail);
    } catch (error) {
        return res.status(500).json({message: error.message});
    }
};

// export const statusSaleDetail = async (req, res) => {
//     try {
//         const {id} = req.params;
//         const {status} = req.body;
//         const saleDetail = await SaleDetails.findByPk(id);
//         saleDetail.status = status;
//         await saleDetail.save();
//         res.json(saleDetail);
//     } catch (error) {
//         return res.status(500).json({message: error.message});
//     }
// };