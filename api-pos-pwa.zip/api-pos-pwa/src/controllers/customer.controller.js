import {Customers} from '../models/Customers.js';
import {maskText} from '../global/mask.js';
import { Op } from 'sequelize';

export const getCustomers = async (req, res) => {
    try {
        const customers = await Customers.findAll();
        res.json(customers);
    } catch (error) {
        return res.status(500).json({message: error.message})
    }
};

export const getCustomerForId = async (req, res) => {
    try {
        const {id} = req.params;
        const customer = await Customers.findByPk(id);
        res.json(customer);
    } catch (error) {
        return res.status(500).json({message: error.message})
    }
};

export const createCustomer = async (req, res) => {
    const {
        mask, 
        dui,
        name,
        lastName,
        email,
        status, 
        userCreate} = req.body;
    // if(!name || !lastName || status == undefined) return res.sendStatus(400);
    try {
        const newCustomer = await Customers.create({
            mask,
            dui,
            name,
            lastName,
            email,
            status,
            userCreate
        });
        const customer = await Customers.findByPk(newCustomer.id);
        customer.mask = maskText('CUST', newCustomer.id);
        await customer.save();
        res.status(200).json(customer);
    } catch (error) {
        return res.status(500).json({message: error.message});
    }
};

export const updateCustomer = async (req, res) => {
    try {
        const {id} = req.params;
        const {
            dui,
            name,
            lastName,
            email,
            userUpdate
        } = req.body;
        // if(!name || !lastName || !id) return res.sendStatus(400);

        const customer = await Customers.findByPk(id);
        customer.dui = dui;
        customer.name = name;
        customer.lastName = lastName;
        customer.email = email;
        customer.userUpdate = userUpdate;
        await customer.save();
        res.json(customer);
    } catch (error) {
        return res.status(500).json({message: error.message});
    }
};

export const statusCustomer = async (req, res) => {
    try {
        const {id} = req.params;
        const {status} = req.body;
        const customer = await Customers.findByPk(id);
        customer.status = status;
        await customer.save();
        res.json(customer);
    } catch (error) {
        return res.status(500).json({message: error.message});
    }
};

export const customerRepeat = async (req, res) => {
    try {
        const {dui,id} = req.body;
        let customer;
        console.log(dui);
        console.log(id);
        if(id != ''){
            customer = await Customers.findAll({
                where:{
                    dui,
                    id:{
                        [Op.ne]:id
                    }
                }
            });
            console.log(customer);
        }else{
            customer = await Customers.findAll({
                where:{
                    dui,
                }
            });
        }
        console.log(customer);
        if(customer.length>0){
            return res.json({status:true,  message:'El DUI ya fue ingresado previamente'})
        }else{
            return res.json({status:false})
        }

    } catch (error) {
        console.log(error);
        return res.status(500).json({message: "No se encontraron resultados"});
    }
}

export const customerEmailRepeat = async (req, res) => {
    try {
        const {email,id} = req.body;
        let customer;
        if(id != ''){
            customer = await Customers.findAll({
                where:{
                    email,
                    id:{
                        [Op.ne]:id
                    }
                }
            });
        }else{
            customer = await Customers.findAll({
                where:{
                    email,
                }
            });
        }
        if(customer.length>0){
            return res.json({status:true,  message:'El correo ya fue ingresado previamente'})
        }else{
            return res.json({status:false})
        }

    } catch (error) {
        console.log(error);
        return res.status(500).json({message: "No se encontraron resultados"});
    }
}