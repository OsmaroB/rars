import {ReportCashDeskClosing} from '../models/ReportCashDeskClosing.js';
import { CashDeskClosing } from '../models/CashDeskClosing.js';

export const getReportCashDeskClosing = async (req, res) => {
    try {
        const reportCashDeskClosing = await ReportCashDeskClosing.findAll({
            include:[
                {model:CashDeskClosing}
            ]
        });
        res.json(reportCashDeskClosing);
    } catch (error) {
        return res.status(500).json({message: error.message})
    }
};

export const readReportCashDeskClosingForCashDesk = async (req, res) => {
    try {
        const {cashDeskClosingID} = req.body;
        const reportCashDeskClosing = await ReportCashDeskClosing.findAll({
            include:[
                {model:CashDeskClosing}
            ],
            where:{
                cashDeskClosingID
            }
        });
        res.json(reportCashDeskClosing);
    } catch (error) {
        return res.status(500).json({message: error.message})
    }
};

export const getReportCashDeskClosingForId = async (req, res) => {
    try {
        const {id} = req.params;
        const reportCashDeskClosing = await ReportCashDeskClosing.findOne({
            include:[
                {model:CashDeskClosing}
            ],
            where:{
                id
            },
        });
        res.json(reportCashDeskClosing);
    } catch (error) {
        return res.status(500).json({message: error.message});
    }
};

export const createReportCashDeskClosing = async (req, res) => {
    const {
        description,
        missing,
        ofMore,
        cashDeskClosingID,
        status,
        detail,
        userCreate
    } = req.body;
    try {
        const newReportCashDeskClosing = await ReportCashDeskClosing.create({
            description,
            missing,
            ofMore,
            cashDeskClosingID,
            status,
            detail,
            userCreate
        });
        res.status(200).json(newReportCashDeskClosing);
    } catch (error) {
        return res.status(500).json({message: error.message});
    }
};

export const updateReportCashDeskClosing = async (req, res) => {
    try {
        const {id} = req.params;
        const {
            description,
            missing,
            ofMore,
            cashDeskClosingID,
            userUpdate
        } = req.body;
        const reportCashDeskClosing = await ReportCashDeskClosing.findByPk(id);
        reportCashDeskClosing.description = description;
        reportCashDeskClosing.missing = missing;
        reportCashDeskClosing.ofMore = ofMore;
        reportCashDeskClosing.cashDeskClosingID = cashDeskClosingID;
        reportCashDeskClosing.userUpdate = userUpdate;
        await reportCashDeskClosing.save();
        res.json(reportCashDeskClosing);
    } catch (error) {
        return res.status(500).json({message: error.message});
    }
};

export const statusReportCashDeskClosing = async (req, res) => {
    try {
        const {id} = req.params;
        const {status} = req.body;
        const reportCashDeskClosing = await ReportCashDeskClosing.findByPk(id);
        reportCashDeskClosing.status = status;
        await reportCashDeskClosing.save();
        res.json(reportCashDeskClosing);
    } catch (error) {
        return res.status(500).json({message: error.message});
    }
};