import {Categories} from '../models/Categories.js';
import {maskText} from '../global/mask.js';

export const getCategories = async (req, res) => {
    try {
        const categories = await Categories.findAll();
        res.json(categories);
    } catch (error) {
        return res.status(500).json({message: error.message})
    }
};

export const getCategoryForId = async (req, res) => {
    try {
        const {id} = req.params;
        const category = await Categories.findOne({
            where:{
                id
            },
        });
        res.json(category);
    } catch (error) {
        return res.status(500).json({message: error.message});
    }
};

export const createCategory = async (req, res) => {
    const {
        mask,
        name,
        position,
        status,
        userCreate
    } = req.body;
    try {
        const newCategory = await Categories.create({
            mask,
            name,
            position,
            status,
            userCreate
        });
        const category = await Categories.findByPk(newCategory.id);
        category.mask = maskText('CAT', newCategory.id);
        await category.save();
        res.status(200).json(category);
    } catch (error) {
        return res.status(500).json({message: error.message});
    }
};

export const updateCategory = async (req, res) => {
    try {
        const {id} = req.params;
        const {
            mask,
            name,
            position,
            userUpdate
        } = req.body;
        const category = await Categories.findByPk(id);
        category.mask = mask;
        category.name = name;
        category.position = position;
        category.userUpdate = userUpdate;
        await category.save();
        res.json(category);
    } catch (error) {
        return res.status(500).json({message: error.message});
    }
};

export const statusCategory = async (req, res) => {
    try {
        const {id} = req.params;
        const {status} = req.body;
        const category = await Categories.findByPk(id);
        category.status = status;
        await category.save();
        res.json(category);
    } catch (error) {
        return res.status(500).json({message: error.message});
    }
};