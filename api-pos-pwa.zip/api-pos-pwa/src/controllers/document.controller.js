import {Documents} from '../models/Documents.js';
import {maskText} from '../global/mask.js';
import {DocumentTypes} from '../models/DocumentTypes.js';

export const getDocuments = async (req, res) => {
    try {
        const documents = await Documents.findAll({
            include:[
                {model:DocumentTypes}
            ]
        });
        res.json(documents);
    } catch (error) {
        return res.status(500).json({message: error.message})
    }
};


export const getDocumentsForDocumentType = async (req, res) => {
    try {
        const {documentTypeID} = req.body;
        const documents = await Documents.findAll({
            include:[
                {model:DocumentTypes}
            ],
            where:{
                documentTypeID
            }
        });
        res.json(documents);
    } catch (error) {
        return res.status(500).json({message: error.message})
    }
};

export const getDocumentForId = async (req, res) => {
    try {
        const {id} = req.params;
        const document = await Documents.findByPk(id);
        res.json(document);
    } catch (error) {
        return res.status(500).json({message: error.message})
    }
};

export const createDocument = async (req, res) => {
    const {
        mask, 
        startCorrelative,
        finishCorrelative,
        actualCorrelative,
        documentTypeID,
        userCreate,
        status
    } = req.body;
    // if(!name || !lastName || status == undefined) return res.sendStatus(400);
    try {
        const newDocument = await Documents.create({
            mask, 
            startCorrelative,
            finishCorrelative,
            actualCorrelative,
            documentTypeID,
            userCreate,
            status
        });
        const document = await Documents.findByPk(newDocument.id);
        document.mask = maskText('DOCU', newDocument.id);
        await document.save();
        res.status(200).json(document);
    } catch (error) {
        return res.status(500).json({message: error.message});
    }
};

export const updateDocument = async (req, res) => {
    try {
        const {id} = req.params;
        const {
            startCorrelative,
            finishCorrelative,
            actualCorrelative,
            documentTypeID,
            userUpdate
        } = req.body;
        // if(!name || !lastName || !id) return res.sendStatus(400);

        const document = await Documents.findByPk(id);
        document.startCorrelative = startCorrelative;
        document.finishCorrelative = finishCorrelative;
        document.actualCorrelative = actualCorrelative;
        document.documentTypeID = documentTypeID;
        document.userUpdate = userUpdate;
        await document.save();
        res.json(document);
    } catch (error) {
        return res.status(500).json({message: error.message});
    }
};

export const statusDocument = async (req, res) => {
    try {
        const {id} = req.params;
        const {status} = req.body;
        const document = await Documents.findByPk(id);
        document.status = status;
        await document.save();
        res.json(document);
    } catch (error) {
        return res.status(500).json({message: error.message});
    }
};