import { CodeAuthorized } from '../models/CodeAuthorized.js';
import { User } from '../models/User.js';

export const getCodeAuthorizeds= async (req, res) => {
    try {
        const codeAuthorizeds = await CodeAuthorized.findAll({
            include:[
                {model: User}
            ]
        });
        res.json(codeAuthorizeds);
    } catch (error) {
        return res.status(500).json({message: error.message})
    }
};

export const getCodeAuthorizedsForId = async (req, res) => {
    try {
        const {id} = req.params;
        const codeAuthorized = await CodeAuthorized.findOne({
            where:{
                id
            },
        });
        res.json(codeAuthorized);
    } catch (error) {
        return res.status(500).json({message: error.message});
    }
};

export const createCodeAuthorized = async (req, res) => {
    const {
        code,
        userID,
        status,
        userCreate
    } = req.body;
    try {
        const newCodeAuthorized = await CodeAuthorized.create({
            code,
            userID,
            status,
            userCreate
        });
        res.status(200).json(newCodeAuthorized);
    } catch (error) {
        return res.status(500).json({message: error.message});
    }
};

export const updateCodeAuthorized = async (req, res) => {
    try {
        const {id} = req.params;
        const {
            code,
            userID,
            status,
            userCreate
        } = req.body;
        const codeAuthorized = await CodeAuthorized.findByPk(id);
        codeAuthorized.code = code;
        codeAuthorized.userID = userID;
        codeAuthorized.status = status;
        codeAuthorized.userCreate = userCreate;
        await codeAuthorized.save();
        res.json(codeAuthorized);
    } catch (error) {
        return res.status(500).json({message: error.message});
    }
};

export const statusCodeAuthorized = async (req, res) => {
    try {
        const {id} = req.params;
        const {status} = req.body;
        const codeAuthorized = await CodeAuthorized.findByPk(id);
        codeAuthorized.status = status;
        await codeAuthorized.save();
        res.json(codeAuthorized);
    } catch (error) {
        return res.status(500).json({message: error.message});
    }
};