import {SubCategories} from '../models/SubCategories.js';
import {Categories} from '../models/Categories.js'
import {maskText} from '../global/mask.js';

export const getSubCategories = async (req, res) => {
    try {
        const subcategories = await SubCategories.findAll({
            include:[
                {model: Categories}
            ]
        });
        res.json(subcategories);
    } catch (error) {
        return res.status(500).json({message: error.message})
    }
};

export const getSubCategoryForId = async (req, res) => {
    try {
        const {id} = req.params;
        const subcategory = await SubCategories.findOne({
            where:{
                id
            },
        });
        res.json(subcategory);
    } catch (error) {
        return res.status(500).json({message: error.message});
    }
};

export const createSubCategory = async (req, res) => {
    const {
        mask,
        name,
        status,
        userCreate,
        categoryID
    } = req.body;
    try {
        const newSubCategory = await SubCategories.create({
            mask,
            name,
            status,
            userCreate,
            categoryID
        });
        const subcategory = await SubCategories.findByPk(newSubCategory.id);
        subcategory.mask = maskText('SBCAT', newSubCategory.id);
        await subcategory.save();
        res.status(200).json(subcategory);
    } catch (error) {
        return res.status(500).json({message: error.message});
    }
};

export const updateSubCategory = async (req, res) => {
    try {
        const {id} = req.params;
        const {
            mask,
            name,
            userUpdate,
            categoryID
        } = req.body;
        const subcategory = await SubCategories.findByPk(id);
        subcategory.mask = mask;
        subcategory.name = name;
        subcategory.userUpdate = userUpdate;
        subcategory.categoryID = categoryID;
        await subcategory.save();
        res.json(subcategory);
    } catch (error) {
        return res.status(500).json({message: error.message});
    }
};

export const statusSubCategory = async (req, res) => {
    try {
        const {id} = req.params;
        const {status} = req.body;
        const subcategory = await SubCategories.findByPk(id);
        subcategory.status = status;
        await subcategory.save();
        res.json(subcategory);
    } catch (error) {
        return res.status(500).json({message: error.message});
    }
};