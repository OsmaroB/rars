import { Prices } from '../models/Prices.js';
import { ButtonDetails } from '../models/ButtonDetails.js';
import { ChannelsSubchannels } from '../models/ChannelsSubchannels.js';
import { Subchannel } from '../models/Subchannel.js';
import { OptionalProducts } from '../models/OptionalProducts.js';
import { Products } from '../models/Products.js';
import { Buttons } from '../models/Buttons.js';
import { Optionals } from '../models/Optionals.js';
import { ModifierProducts } from '../models/ModifierProducts.js';
import { Modifiers } from '../models/Modifiers.js'; 
import {Categories} from '../models/Categories.js';
import { ButtonCategories } from '../models/ButtonCategories.js';
import { Submodifiers } from '../models/Submodifiers.js';
import { Depmodifiers } from '../models/DepModifiers.js';
import { Discounts } from '../models/Discounts.js';
import { Op } from 'sequelize';


export const getPricesForChannel = async (req, res) => {
    try {
        const {channelID, categoryID} = req.body;
        if(categoryID == ''){
            const prices = await Prices.findAll({
                where:{
                    channelID:channelID,
                    buttonDetailID:{
                        [Op.not]: null
                    }
                },
                include:[
                    { model: ButtonDetails, 
                        include:[
                            {model: Products},
                            {model: Buttons,
                                where:{
                                    id:{
                                        [Op.not]: null
                                    }  
                                },
                                include:[
                                    {model:ButtonCategories,
                                        include:[
                                            {
                                                model:Categories,
                                                where:{
                                                    status:0
                                                }
                                            },
                                        ],
                                        where:{
                                            CategoryID:{
                                                [Op.not]: null
                                            }
                                        }
                                    }
                                ]
                            }
                        ],
                        where:{
                            buttonID:{
                                [Op.not]: null
                            }
                        }
                    },
                    { model: ChannelsSubchannels },
                    { model: Subchannel,
                        include:[{model: ChannelsSubchannels}]    
                    },
                    { model: OptionalProducts, 
                        include:[
                            {model: Optionals}, 
                            {model: Products}
                        ] 
                    },
                    {   model: ModifierProducts,
                        include:[
                            {model: Modifiers},
                            {model: Products},
                            {model: Submodifiers},
                            {model: Depmodifiers},
                        ]
                    },{
                        model: Discounts,
                    }
    
                ]
            });
            res.json(prices);
        }else{
            const prices = await Prices.findAll({
                where:{
                    channelID:channelID,
                    buttonDetailID:{
                        [Op.not]: null
                    }
                },
                include:[
                    { model: ButtonDetails, 
                        include:[
                            {model: Products},
                            {model: Buttons,
                                where:{
                                    id:{
                                        [Op.not]: null
                                    }  
                                },
                                include:[
                                    {model:ButtonCategories,
                                        include:[
                                            {
                                                model:Categories,
                                                where:{
                                                    status:0
                                                }
                                            },
                                        ],
                                        where:{
                                            CategoryID:categoryID,
                                            CategoryID:{
                                                [Op.not]: null
                                            }
                                        }
                                    }
                                ]
                            }
                        ],
                        where:{
                            buttonID:{
                                [Op.not]: null
                            }
                        }
                    },
                    { model: ChannelsSubchannels },
                    { model: Subchannel,
                        include:[{model: ChannelsSubchannels}]    
                    },
                    { model: OptionalProducts, 
                        include:[
                            {model: Optionals}, 
                            {model: Products}
                        ] 
                    },
                    {   model: ModifierProducts,
                        include:[
                            {model: Modifiers},
                            {model: Products},
                            {model: Submodifiers},
                            {model: Depmodifiers},
                        ]
                    },{
                        model: Discounts,
                    }
    
                ]
            });
            res.json(prices);
        }
    } catch (error) {
        return res.status(500).json({message: error.message});
    }
};