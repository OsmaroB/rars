'use strict';

/** @type {import('sequelize-cli').Migration} */
module.exports = {
  async up (queryInterface, Sequelize) {
      
    await queryInterface.bulkInsert('roles', [{
      mask: 'ROL-0001',
      name: 'Gerente',
      description: 'Gerente de sucursal',
      status: 0,
      userCreate: 0,
      userUpdate: 0,
      createdAt: new Date(),
      updatedAt: new Date()
    }], {});
    
  },

  async down (queryInterface, Sequelize) {
     await queryInterface.bulkDelete('roles', null, {});
  }
};
