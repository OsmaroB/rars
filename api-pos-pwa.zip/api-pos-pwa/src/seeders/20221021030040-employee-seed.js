'use strict';

/** @type {import('sequelize-cli').Migration} */
module.exports = {
  async up (queryInterface, Sequelize) {
      
    await queryInterface.bulkInsert('employees', [
      {
        mask: 'EMP-0001',
        name: 'Osmaro Alfonso',
        lastName: 'Bonilla Mestizo',
        status: 0,
        userCreate: 0,
        userUpdate: 0,
        createdAt: new Date(),
        updatedAt: new Date()
      }
    ], {});
    
  },

  async down (queryInterface, Sequelize) {
     await queryInterface.bulkDelete('employees', null, {});
  }
};
