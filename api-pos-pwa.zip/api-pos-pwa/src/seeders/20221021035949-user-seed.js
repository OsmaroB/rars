'use strict';

/** @type {import('sequelize-cli').Migration} */
module.exports = {
  async up (queryInterface, Sequelize) {
      
    await queryInterface.bulkInsert('users', [{
      mask: 'USE-0001',
      email: 'osmaro.bonilla@gmail.com',
      password: '$2a$08$aG5kvjQ1i2Qcg4uo5Ag6ZeYg0aWFy8UQfQ2GJf9Ej6lt40b9UHJpy',
      status: 0,
      roleID: 1,
      employeeID: 1,
      userCreate: 0,
      userUpdate: 0,
      createdAt: new Date(),
      updatedAt: new Date()
    }], {});
    
  },

  async down (queryInterface, Sequelize) {
     await queryInterface.bulkDelete('users', null, {});
  }
};
