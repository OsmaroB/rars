'use strict';

/** @type {import('sequelize-cli').Migration} */
module.exports = {
  async up (queryInterface, Sequelize) {
      
    await queryInterface.bulkInsert('roleDetails', [{
      mask: 'USE-0001',
      url: '/app/employee',
      status: 0,
      roleID: 1,
      userCreate: 0,
      userUpdate: 0,
      createdAt: new Date(),
      updatedAt: new Date()
    }], {});
    
  },

  async down (queryInterface, Sequelize) {
     await queryInterface.bulkDelete('roleDetails', null, {});
  }
};
