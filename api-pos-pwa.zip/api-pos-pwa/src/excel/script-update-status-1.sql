--SCRIPT QUE EJECUTAR 
--SSD
--comida empleado subchhanel 4
UPDATE prices SET status = 1  WHERE buttonDetailID BETWEEN 4 and 11 AND subchannelID = 4
--combo administrativo subchannel 5
UPDATE prices SET status = 1  where buttonDetailID BETWEEN 4 and 11 AND subchannelID = 5
--comida empleado subchhanel 4
--EXTRAS
UPDATE prices SET status = 1  WHERE buttonDetailID BETWEEN 260 and 292 AND subchannelID = 4
--combo administrativo subchannel 5
UPDATE prices SET status = 1  where buttonDetailID BETWEEN 260 and 292 AND subchannelID = 5
--DESAYUNO
--comida empleado subchhanel 4
UPDATE prices SET status = 1  WHERE buttonDetailID BETWEEN 82 and 87 AND subchannelID = 4
--combo administrativo subchannel 5
UPDATE prices SET status = 1  where buttonDetailID BETWEEN 82 and 87 AND subchannelID = 5
--LEAL
--comida empleado subchhanel 4
UPDATE prices SET status = 1  WHERE buttonDetailID BETWEEN 115 and 190 AND subchannelID = 4
--combo administrativo subchannel 5
UPDATE prices SET status = 1  where buttonDetailID BETWEEN 115 and 190 AND subchannelID = 5
--CANJES
--comida empleado subchhanel 4
UPDATE prices SET status = 1  WHERE buttonDetailID BETWEEN 327 and 340 AND subchannelID = 4
--combo administrativo subchannel 5
UPDATE prices SET status = 1  where buttonDetailID BETWEEN 327 and 340 AND subchannelID = 5
--BANDEJAS
--comida empleado subchhanel 4
UPDATE prices SET status = 1  WHERE buttonDetailID BETWEEN 318 and 326 AND subchannelID = 4
--combo administrativo subchannel 5
UPDATE prices SET status = 1  where buttonDetailID BETWEEN 318 and 326 AND subchannelID = 5
--PROMOCIONES
--comida empleado subchhanel 4
UPDATE prices SET status = 1  WHERE buttonDetailID BETWEEN 204 and 259 AND subchannelID = 4
--combo administrativo subchannel 5
UPDATE prices SET status = 1  where buttonDetailID BETWEEN 204 and 259 AND subchannelID = 5
--SUB DE 30
--comida empleado subchhanel 4
UPDATE prices SET status = 1  WHERE buttonDetailID BETWEEN 47 and 81 AND subchannelID = 4
--combo administrativo subchannel 5
UPDATE prices SET status = 1  where buttonDetailID BETWEEN 47 and 81 AND subchannelID = 5
--QUITAR TODOS LOS QUE NO SEAN GALLETA GRATIS EN CANJES
UPDATE prices set status = 1 WHERE subchannelID = 6 AND (price > 0 OR price < 0)

	