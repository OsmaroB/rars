import express from "express";
import employeesRoutes from './routes/employee.routes.js'
import rolesRoutes from './routes/role.routes.js';
import roleDetailsRoutes from './routes/role-detail.routes.js';
import usersRoutes from './routes/user.routes.js';
import articlesRoutes from './routes/articles.routes.js';
import recipesRoutes from './routes/recipes.routes.js';
import recipeArticlesRoutes from './routes/recipes-articles.routes.js';
import productsRoutes from './routes/products.routes.js';
import productDetailsRoutes from './routes/product-details.routes.js';
import buttonsRoutes from './routes/buttons.routes.js';
import buttonDetailsRoutes from './routes/button-details.routes.js';
import channelsRoutes from './routes/channels.routes.js';
import categoriesRoutes from './routes/categories.routes.js';
import paymentMethodsRoutes from "./routes/payment-methods.routes.js";
import optionalsRoutes from './routes/optionals.routes.js';
import optionalProductsRoutes from './routes/optional-products.routes.js';
import documentTypesRoutes from './routes/document-types.routes.js';
import categoryButtonRoutes from './routes/category-buttons.routes.js';
import SubchannelRoutes from './routes/subchannels.routes.js';
import paymentMethodDetailRoutes from './routes/payment-method-details.routes.js';
import subcategoriesRoutes from './routes/subcategories.routes.js';
import pricesRoutes from './routes/prices.routes.js';
import modifiersRoutes from './routes/modifier.routes.js';
import modifierProductsRoutes from './routes/modifier-product.routes.js';
import submodifierRoutes from './routes/submodifier.routes.js';
import tiketConfigurationRoutes from './routes/tiket-configuration.routes.js';
import documentRoutes from './routes/document.routes.js';
import customerRoutes from './routes/customer.routes.js';
import saleRoutes from './routes/sale.routes.js';
import canceledSaleRoute from './routes/canceledSales.routes.js';
import depmodifierRoutes from './routes/depmodifier.routes.js';
import discountRoutes from './routes/discount.routes.js';
import cashDeskClosingRoutes from './routes/cash-desk-closing.routes.js';
import detailCardCashClosingRoutes from './routes/detail-card-cash-closing.routes.js';
import detailPaymentMethodCashClosingRoutes from './routes/detail-payment-method-cash-closing.routes.js';
import reportCashDeskClosingRoutes from './routes/report-cash-desk-closing.routes.js';
import outputCashDeskRoutes from './routes/output-cash-desk.routes.js';
import saleDetailRoutes from './routes/sale-details.routes.js';
import printRoutes from './routes/prints.routes.js';
import codeAuthorizedRotes from './routes/code-authorized.routes.js';
import customerSalesRoutes from './routes/customer-sales.routes.js'
import importDateExcelRoutes from './routes/import-data-excel.routes.js';

// auth with JWT
import  {authJwt}  from "./middlewares/index.js";
import cors from 'cors';
// documentation api
import swaggerUi from 'swagger-ui-express';
import {swaggerDocs} from './swagger/config.js'

const app = express();
// app.use(express.urlencoded({extended:false}));
// app.use(express.json());
app.use(cors());
app.use(express.json({limit: '25mb'}));
app.use(express.urlencoded({limit: '25mb',extended:false}));

// routes not autj
app.use('/api-doc', swaggerUi.serve, swaggerUi.setup(swaggerDocs));
app.use(usersRoutes);
app.use(tiketConfigurationRoutes);
app.use(customerSalesRoutes);
// app.use(pricesRoutes);
app.use(importDateExcelRoutes);

app.use(pricesRoutes);
// auth all routes with token jwt
app.use(authJwt.verifyToken);

app.use(saleRoutes);
app.use(printRoutes);
app.use(saleDetailRoutes);
app.use(codeAuthorizedRotes);
// routes auth
app.use(cashDeskClosingRoutes);
app.use(detailCardCashClosingRoutes);
app.use(detailPaymentMethodCashClosingRoutes);
app.use(outputCashDeskRoutes);
app.use(reportCashDeskClosingRoutes);
app.use(SubchannelRoutes);
app.use(paymentMethodDetailRoutes);
app.use(subcategoriesRoutes);
app.use(customerRoutes);
app.use(depmodifierRoutes);
app.use(canceledSaleRoute);
app.use(documentRoutes);
app.use(submodifierRoutes);
app.use(employeesRoutes);
app.use(rolesRoutes);
app.use(roleDetailsRoutes);
app.use(articlesRoutes);
app.use(recipesRoutes);
app.use(recipeArticlesRoutes);
app.use(productsRoutes);
app.use(productDetailsRoutes);
app.use(buttonsRoutes);
app.use(buttonDetailsRoutes);
app.use(channelsRoutes);
app.use(categoriesRoutes);
app.use(paymentMethodsRoutes);
app.use(optionalsRoutes);
app.use(optionalProductsRoutes);
app.use(documentTypesRoutes);
app.use(categoryButtonRoutes);
app.use(modifiersRoutes);
app.use(modifierProductsRoutes);
app.use(discountRoutes);

export default app;