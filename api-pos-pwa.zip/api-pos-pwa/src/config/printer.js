const printer = {};


printer.getPrinter = () =>{
  return(
    {
        name: 'EPSON_TM_T20III',
        isDefault: false,
        options: {
          copies: '1',
          'device-uri': 'usb://EPSONTM-T20III',
          finishings: '3',
          'job-cancel-after': '10800',
          'job-hold-until': 'no-hold',
          'job-priority': '50',
          'job-sheets': 'none,none',
          // 'marker-change-time': 1970-01-01T00:00:00.000Z,
          'number-up': '1',
          'printer-commands': 'none',
          'printer-info': 'EPSON TM-T20II',
          'printer-is-accepting-jobs': 'true',
          'printer-is-shared': 'false',
          'printer-is-temporary': 'false',
          'printer-location': 'HAL',
          'printer-make-and-model': 'EPSON TM-T20III (rastertotmt)',
          'printer-state': '3',
          'printer-state-change-time': '2020-12-03T15:12:51.000Z',
          'printer-state-reasons': 'none',
          'printer-type': '2134020',
          'printer-uri-supported': 'ipp://localhost/printers/EPSON_TM_T20III'
        },
        status: 'IDLE'
    }
  )
}

export default printer;