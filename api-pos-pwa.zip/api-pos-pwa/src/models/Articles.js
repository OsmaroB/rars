import { DataTypes } from "sequelize";
import { sequelize } from "../database/database.js";
import { RecipeArticles } from "./RecipeArticles.js";

/**
 * @openapi
 * components:
 *  schemas:
 *      createArticle:
 *          type: object
 *          required:
 *              - mask
 *              - name
 *              - purchasing_unit
 *              - quantity_purchasing_unit
 *              - sales_unit
 *              - quantity_sales_unit
 *              - stock
 *              - status
 *              - userCreate
 *          properties:
 *              mask:
 *                  type: string
 *                  default: ART-0001
 *              name:
 *                  type: string
 *                  default: articulo
 *              purchasing_unit:
 *                  type: string
 *                  default: unidad
 *              quantity_purchasing_unit:
 *                  type: integer
 *                  default: 50
 *              sales_unit:
 *                  type: string
 *                  default: unidad de venta
 *              quantity_sales_unit:
 *                  type: integer
 *                  default: 50
 *              stock:
 *                  type: integer
 *                  default: 100
 *              status:
 *                  type: string
 *                  default: 0
 *              userCreate:
 *                  type: integer
 *                  default: 1
 *      updateArticle:
 *          type: object
 *          required:
 *              - mask
 *              - name
 *              - purchasing_unit
 *              - quantity_purchasing_unit
 *              - sales_unit
 *              - quantity_sales_unit
 *              - stock
 *              - status
 *              - userUpdate
 *          properties:
 *              mask:
 *                  type: string
 *                  default: ART-0002
 *              name:
 *                  type: string
 *                  default: articulo modificado
 *              purchasing_unit:
 *                  type: string
 *                  default: unidad
 *              quantity_purchasing_unit:
 *                  type: integer
 *                  default: 50
 *              sales_unit:
 *                  type: string
 *                  default: unidad de venta
 *              quantity_sales_unit:
 *                  type: integer
 *                  default: 50
 *              stock:
 *                  type: integer
 *                  default: 100
 *              status:
 *                  type: string
 *                  default: 0
 *              userUpdate:
 *                  type: string
 *                  default: 1
 *      delete:
 *          type: object
 *          required:
 *              - status
 *          properties:
 *              status:
 *                  type: string
 *                  default: 1
 * 
 */
export const Articles = sequelize.define('articles',{
    id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true
    },
    mask:{
        type: DataTypes.STRING(9)
    },
    name:{
        type: DataTypes.STRING
    },
    purchasing_unit:{
        type: DataTypes.STRING
    },
    quantity_purchasing_unit:{
        type: DataTypes.INTEGER
    },
    sales_unit:{
        type: DataTypes.STRING
    },
    quantity_sales_unit:{
        type: DataTypes.INTEGER
    },
    stock:{
        type: DataTypes.INTEGER
    },
    status:{
        type: DataTypes.INTEGER,
        defaultValue: 0,
    },
    userCreate:{
        type: DataTypes.INTEGER
    },
    userUpdate: {
        type: DataTypes.INTEGER
    }

});


// relationship between recipeArticles and Articles
Articles.hasMany(RecipeArticles,{
    foreignKey: 'articleID',
    sourceKey: 'id'
});

RecipeArticles.belongsTo(Articles,{
    foreignKey: 'articleID',
    targetId: 'id'
});