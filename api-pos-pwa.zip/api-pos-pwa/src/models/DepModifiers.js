import { DataTypes } from "sequelize";
import { sequelize } from "../database/database.js";
import { ModifierProducts } from "./ModifierProducts.js";

export const Depmodifiers = sequelize.define('depmodifiers',{
    id:{
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true,
    },
    mask:{
        type: DataTypes.STRING(11)
    },
    name:{
        type: DataTypes.STRING(75)
    },
    status:{
        type: DataTypes.INTEGER,
        defaultValue: 0,
    },
    userCreate:{
        type: DataTypes.INTEGER
    },
    userUpdate: {
        type: DataTypes.INTEGER
    }
})

// relationship between Modifiers and ModifierProducts
Depmodifiers.hasMany(ModifierProducts, {
    foreignKey: 'depmodifierID',
    sourceKey: 'id'
});

ModifierProducts.belongsTo(Depmodifiers,{
    foreignKey: 'depmodifierID',
    targetId: 'id'
});