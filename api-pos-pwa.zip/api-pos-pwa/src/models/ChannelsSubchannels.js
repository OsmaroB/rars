import { DataTypes } from "sequelize";
import { sequelize } from "../database/database.js";
import { Subchannel } from "./Subchannel.js";


export const ChannelsSubchannels = sequelize.define('channelsSubchannels',{
    id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true
    },
    mask:{
        type: DataTypes.STRING(9)
    },
    name:{
        type: DataTypes.STRING(100)
    },
    description:{
        type: DataTypes.STRING
    },
    restaurant:{
        type: DataTypes.STRING
    },
    isChannel: {
        type: DataTypes.BOOLEAN
    },
    status:{
        type: DataTypes.INTEGER,
        defaultValue: 0,
    },
    userCreate:{
        type: DataTypes.INTEGER
    },
    userUpdate: {
        type: DataTypes.INTEGER
    }

});



// relationship between channel and subchannel
ChannelsSubchannels.hasMany(Subchannel,{
    foreignKey: 'channelID',
    sourceKey: 'id'
});

Subchannel.belongsTo(ChannelsSubchannels,{
    foreignKey: 'channelID',
    targetId: 'id'
})