import { DataTypes } from "sequelize";
import { sequelize } from "../database/database.js";

export const Customers = sequelize.define('customers',{
    id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true
    },
    mask:{
        type: DataTypes.STRING(9)
    },
    dui:{
        type: DataTypes.STRING(14),
        unique: {
            msg: 'El DUI necesita ser unico'
        },
        validate: {
            notEmpty: {
                msg: 'El DUI no debe ir vacio'
            }
        }
    },
    name: {
        type: DataTypes.STRING(100)
    },
    lastName:{
        type: DataTypes.STRING(100)
    },
    email:{
        type: DataTypes.STRING(255),
        unique: {
            msg: 'El email necesita ser unico'
        },
        validate: {
            isEmail: {
                msg: 'Email no valido'
            },
            notEmpty: {
                msg: 'Ingrese un email'
            }
        }
    },
    status:{
        type: DataTypes.INTEGER,
        defaultValue: 0,
    },
    userCreate:{
        type: DataTypes.INTEGER
    },
    userUpdate: {
        type: DataTypes.INTEGER
    }

});

