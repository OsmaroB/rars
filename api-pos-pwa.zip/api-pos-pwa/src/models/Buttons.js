import { DataTypes } from "sequelize";
import { sequelize } from "../database/database.js";
import { ButtonCategories } from "./ButtonCategories.js";
import { ButtonDetails } from "./ButtonDetails.js";

export const Buttons = sequelize.define('buttons',{
    id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true
    },
    mask:{
        type: DataTypes.STRING(9)
    },
    name:{
        type: DataTypes.STRING,
    },
    position:{
        type: DataTypes.INTEGER
    },
    status:{
        type: DataTypes.INTEGER,
        defaultValue: 0,
    },
    userCreate:{
        type: DataTypes.INTEGER
    },
    userUpdate: {
        type: DataTypes.INTEGER
    }
});

   
// relationship between Buttons and ButtonDetails
Buttons.hasMany(ButtonDetails,{
    foreignKey: 'buttonID',
    sourceKey: 'id'
});

ButtonDetails.belongsTo(Buttons,{
    foreignKey: 'buttonID',
    targetId: 'id'
});

// relationship between Buttons and ButtonsCategories
Buttons.hasMany(ButtonCategories,{
    foreignKey: 'buttonID',
    sourceKey: 'id'
});

ButtonCategories.belongsTo(Buttons,{
    foreignKey: 'buttonID',
    targetId: 'id'
});