import { DataTypes } from "sequelize";
import { sequelize } from "../database/database.js";
import { Sales } from "./sales.js";

export const User = sequelize.define('users',{
    id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true
    },
    mask:{
        type: DataTypes.STRING(9)
    },
    email:{
        type: DataTypes.STRING(150),
        unique: {
            msg: 'El email necesita ser unico'
        },
        validate: {
            isEmail: {
                msg: 'Email no valido'
            },
            notEmpty: {
                msg: 'Ingrese un email'
            }
        }
    },
    password:{
        type: DataTypes.STRING(255)
    },
    code:{
        type: DataTypes.STRING(255)
    },
    status:{
        type: DataTypes.INTEGER,
        defaultValue: 0,
    },
    userCreate:{
        type: DataTypes.INTEGER
    },
    userUpdate: {
        type: DataTypes.INTEGER
    }
});

