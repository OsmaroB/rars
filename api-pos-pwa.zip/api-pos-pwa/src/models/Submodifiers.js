import { DataTypes } from "sequelize";
import { sequelize } from "../database/database.js";
import { ModifierProducts } from "./ModifierProducts.js";
import { Depmodifiers } from "./DepModifiers.js";

export const Submodifiers = sequelize.define('submodifiers',{
    id:{
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true,
    },
    mask:{
        type: DataTypes.STRING(11)
    },
    name:{
        type: DataTypes.STRING(75)
    },
    status:{
        type: DataTypes.INTEGER,
        defaultValue: 0,
    },
    userCreate:{
        type: DataTypes.INTEGER
    },
    userUpdate: {
        type: DataTypes.INTEGER
    }
})

// relationship between Modifiers and ModifierProducts
Submodifiers.hasMany(ModifierProducts, {
    foreignKey: 'submodifierID',
    sourceKey: 'id'
});

ModifierProducts.belongsTo(Submodifiers,{
    foreignKey: 'submodifierID',
    targetId: 'id'
});

// relationship between Modifiers and ModifierProducts
Submodifiers.hasMany(Depmodifiers, {
    foreignKey: 'submodifierID',
    sourceKey: 'id'
});

Depmodifiers.belongsTo(Submodifiers,{
    foreignKey: 'submodifierID',
    targetId: 'id'
});