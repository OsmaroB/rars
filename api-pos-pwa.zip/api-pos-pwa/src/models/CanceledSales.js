import { DataTypes } from "sequelize";
import { sequelize } from "../database/database.js";

export const CanceledSales = sequelize.define('canceledSales',{
    id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true
    },
    tiketNumber:{
        type: DataTypes.STRING
    },
    cashRegisterNumber:{
        type: DataTypes.STRING
    },
    restaurant:{
        type: DataTypes.STRING
    },
    channel:{
        type: DataTypes.STRING
    },
    paymentMethod:{
        type: DataTypes.STRING
    },
    date:{
        type: DataTypes.DATE
    },
    hour:{
        type: DataTypes.STRING
    },
    totalWithoutTax:{
        type: DataTypes.DOUBLE
    },
    totalDiscount:{
        type: DataTypes.DOUBLE
    },
    totalWithDiscount:{
        type: DataTypes.DOUBLE
    },
    tax:{
        type: DataTypes.DOUBLE
    },
    totalWithTax:{
        type: DataTypes.DOUBLE
    },
    tip:{
        type: DataTypes.DOUBLE
    },
    status:{
        type: DataTypes.INTEGER
    },
    userCreate:{
        type: DataTypes.INTEGER
    },
    userUpdate:{
        type: DataTypes.INTEGER
    },
});


