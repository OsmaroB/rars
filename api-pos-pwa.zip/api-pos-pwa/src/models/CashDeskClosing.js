import { DataTypes } from "sequelize";
import { sequelize } from "../database/database.js";
// import { ButtonCategories } from "./ButtonCategories.js";
import {User} from "./User.js";

export const CashDeskClosing = sequelize.define('cashDeskClosings',{
    id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true
    },
    mask:{
        type: DataTypes.STRING(11)
    },
    date:{
        type: DataTypes.DATE,
    },
    cash:{
        type: DataTypes.DOUBLE,
    },
    hour:{
        type: DataTypes.STRING
    },
    type:{
        type: DataTypes.INTEGER,
    },
    status:{
        type: DataTypes.INTEGER,
        defaultValue: 0,
    },
    prettyCash:{
        type: DataTypes.NUMBER,
    },
    cashRegister:{
        type: DataTypes.STRING
    },
    userCreate:{
        type: DataTypes.INTEGER
    },
    userUpdate: {
        type: DataTypes.INTEGER
    },
    userAproved:{
        type:DataTypes.INTEGER
    }
});

// relationship between Modifiers and ModifierProducts
User.hasMany(CashDeskClosing, {
    foreignKey: 'userID',
    sourceKey: 'id'
});

CashDeskClosing.belongsTo(User,{
    foreignKey: 'userID',
    targetId: 'id'
});