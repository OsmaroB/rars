import { DataTypes } from "sequelize";
import { sequelize } from "../database/database.js";
// import { Sales } from "./sales.js";

export const Documents = sequelize.define('documents',{
    id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true
    },
    mask:{
        type: DataTypes.STRING
    },
    startCorrelative:{
        type: DataTypes.STRING
    },
    finishCorrelative:{
        type: DataTypes.STRING
    },
    actualCorrelative:{
        type: DataTypes.STRING
    },
    status:{
        type: DataTypes.INTEGER
    },
    userCreate:{
        type: DataTypes.INTEGER
    },
    userUpdate:{
        type: DataTypes.INTEGER
    },
});



