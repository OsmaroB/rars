import { DataTypes } from "sequelize";
import { sequelize } from "../database/database.js";
import {Prices} from './Prices.js';
import { Subchannel } from "./Subchannel.js";
import { ChannelsSubchannels } from "./ChannelsSubchannels.js";

export const Discounts = sequelize.define('discounts',{
    id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true
    },
    mask:{
        type: DataTypes.STRING
    },
    name:{
        type: DataTypes.STRING
    },
    isGlobal:{
        type: DataTypes.BOOLEAN
    },
    type:{
        type: DataTypes.INTEGER
    },
    discountInfo:{
        type: DataTypes.DOUBLE
    },
    status:{
        type: DataTypes.INTEGER
    },
    userCreate:{
        type: DataTypes.INTEGER
    },
    userUpdate:{
        type: DataTypes.INTEGER
    },
});

// // relationship between Discounts and Prices 
// Discounts.hasMany(Prices, {
//     foreignKey: 'discountID',
//     sourceKey: 'id'
// });

// Prices.belongsTo(Discounts,{
//     foreignKey: 'discountID',
//     targetId: 'id'
// });

// relationship between Subchannel and Discount 
Subchannel.hasMany(Discounts, {
    foreignKey: 'subchannelID',
    sourceKey: 'id'
});

Discounts.belongsTo(Subchannel,{
    foreignKey: 'subchannelID',
    targetId: 'id'
});

ChannelsSubchannels.hasMany(Discounts, {
    foreignKey: 'channelID',
    sourceKey: 'id'
});

Discounts.belongsTo(ChannelsSubchannels,{
    foreignKey: 'channelID',
    targetId: 'id'
});