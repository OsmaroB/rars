import { DataTypes } from "sequelize";
import { sequelize } from "../database/database.js";

export const SubCategories = sequelize.define('SubCategories',{
    id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true
    },
    mask:{
        type: DataTypes.STRING
    },
    name:{
        type: DataTypes.STRING
    },
    status:{
        type: DataTypes.INTEGER,
        defaultValue: 0,
    },
    userCreate:{
        type: DataTypes.INTEGER
    },
    userUpdate: {
        type: DataTypes.INTEGER
    }
});

