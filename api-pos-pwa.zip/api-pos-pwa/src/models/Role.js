import { DataTypes } from "sequelize";
import { sequelize } from "../database/database.js";
import { User } from "./User.js";
import { RoleDetail } from "./RoleDetail.js";
import { Sales } from "./Sales.js";
import { SaleDetails } from "./SaleDetails.js";
import { Prices } from "./Prices.js";

export const Role = sequelize.define('roles',{
    id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true
    },
    mask:{
        type: DataTypes.STRING(9)
    },
    name: {
        type: DataTypes.STRING(100)
    },
    description:{
        type: DataTypes.STRING(255)
    },
    status:{
        type: DataTypes.INTEGER,
        defaultValue: 0,
    },
    userCreate:{
        type: DataTypes.INTEGER
    },
    userUpdate: {
        type: DataTypes.INTEGER
    }

});

// relationship between role and user
Role.hasMany(User,{
    foreignKey: 'roleID',
    sourceKey: 'id'
});

User.belongsTo(Role,{
    foreignKey: 'roleID',
    targetId: 'id'
});

// relationship between role and roleDetail
Role.hasMany(RoleDetail,{
    foreignKey: 'roleID',
    sourceKey: 'id'
});

RoleDetail.belongsTo(Role,{
    foreignKey: 'roleID',
    targetId: 'id'
})

// relationship between Sales and SaleDetails 
Sales.hasMany(SaleDetails, {
    foreignKey: 'saleID',
    sourceKey: 'id'
});

SaleDetails.belongsTo(Sales,{
    foreignKey: 'saleID',
    targetId: 'id'
});


// relationship between Users and Sales 
User.hasMany(Sales, {
    foreignKey: 'userID',
    sourceKey: 'id'
});

Sales.belongsTo(User,{
    foreignKey: 'userID',
    targetId: 'id'
});

// relationship between Prices and SaleDetails 
Prices.hasMany(SaleDetails, {
    foreignKey: 'priceID',
    sourceKey: 'id'
});

SaleDetails.belongsTo(Prices,{
    foreignKey: 'priceID',
    targetId: 'id'
});