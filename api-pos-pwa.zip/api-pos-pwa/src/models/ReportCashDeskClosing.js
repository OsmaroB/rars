import { DataTypes } from "sequelize";
import { sequelize } from "../database/database.js";
import {CashDeskClosing} from "./CashDeskClosing.js";

export const ReportCashDeskClosing = sequelize.define('reportCashDeskClosings',{
    id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true
    },
    description:{
        type: DataTypes.STRING,
    },
    missing:{
        type: DataTypes.DOUBLE,
    },
    ofMore:{
        type: DataTypes.DOUBLE,
    },
    detail:{
        type:DataTypes.STRING,
    },
    status:{
        type: DataTypes.INTEGER,
        defaultValue: 0,
    },
    userCreate:{
        type: DataTypes.INTEGER
    },
    userUpdate: {
        type: DataTypes.INTEGER
    }
});

// relationship between Modifiers and ModifierProducts
CashDeskClosing.hasMany(ReportCashDeskClosing, {
    foreignKey: 'cashDeskClosingID',
    sourceKey: 'id'
});

ReportCashDeskClosing.belongsTo(CashDeskClosing,{
    foreignKey: 'cashDeskClosingID',
    targetId: 'id'
});