import { DataTypes } from "sequelize";
import { sequelize } from "../database/database.js";
import { User } from "./User.js";


export const CodeAuthorized = sequelize.define('codeAuthorizeds',{
    id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true
    },
    code:{
        type: DataTypes.STRING(100)
    },
    status:{
        type: DataTypes.INTEGER,
        defaultValue: 0,
    },
    userCreate:{
        type: DataTypes.INTEGER
    },
    userUpdate: {
        type: DataTypes.INTEGER
    }

});

// relationship between User and codeAuthorized
User.hasMany(CodeAuthorized,{
    foreignKey: 'userID',
    sourceKey: 'id'
});

CodeAuthorized.belongsTo(User,{
    foreignKey: 'userID',
    targetId: 'id'
})