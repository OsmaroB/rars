import { DataTypes } from "sequelize";
import { sequelize } from "../database/database.js";

export const OptionalProducts = sequelize.define('optionalProducts',{
    id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true
    },
    status:{
        type: DataTypes.INTEGER,
        defaultValue: 0,
    },
    userCreate:{
        type: DataTypes.INTEGER
    },
    userUpdate: {
        type: DataTypes.INTEGER
    }
});
