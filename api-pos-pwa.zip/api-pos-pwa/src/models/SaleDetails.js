import { DataTypes } from "sequelize";
import { sequelize } from "../database/database.js";
import { Prices } from "./Prices.js";
import { Sales } from "./Sales.js";

export const SaleDetails = sequelize.define('saleDetails',{
    id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true
    },
    tiketNumber:{
        type: DataTypes.STRING
    },
    maskDetail:{
        type: DataTypes.STRING
    },
    typeDetail:{
        type: DataTypes.INTEGER
    },
    line:{
        type: DataTypes.STRING
    },
    product:{
        type: DataTypes.STRING
    },
    description:{
        type: DataTypes.STRING,
        defaultValue: 0,
    },
    modifier:{
        type: DataTypes.STRING
    },
    cashRegisterNumber:{
        type: DataTypes.STRING
    },
    restaurant:{
        type: DataTypes.STRING
    },
    cant: {
        type: DataTypes.INTEGER
    },
    cost:{
        type: DataTypes.DOUBLE
    },
    totalWithoutTax:{
        type: DataTypes.DOUBLE
    },
    discountLine:{
        type: DataTypes.DOUBLE
    },
    totalWithDiscount:{
        type: DataTypes.DOUBLE
    },
    tax:{
        type: DataTypes.DOUBLE
    },
    totalWithTax:{
        type: DataTypes.DOUBLE
    },
    tip:{
        type: DataTypes.DOUBLE
    },
    userCreate:{
        type: DataTypes.INTEGER
    },
    userUpdate:{
        type: DataTypes.INTEGER
    },
});

