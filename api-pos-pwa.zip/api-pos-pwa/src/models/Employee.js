import { DataTypes } from "sequelize";
import { sequelize } from "../database/database.js";
import { User } from "./User.js";
 
/**
 * @openapi
 * components:
 *  schemas:
 *      CreateEmployeeInput:
 *          type: object
 *          required:
 *              - mask
 *              - name
 *              - lastName
 *              - status
 *              - userCreate
 *          properties:
 *              mask:
 *                  type: string
 *                  default: EMP-0001
 *              name:
 *                  type: string
 *                  default: osmaro
 *              lastName:
 *                  type: string
 *                  default: bonilla
 *              status:
 *                  type: string
 *                  default: 0
 *              userCreate:
 *                  type: string
 *                  default: 1
 *      updateEmployeeInput:
 *          type: object
 *          required:
 *              - mask
 *              - name
 *              - lastName
 *              - userUpdate
 *          properties:
 *              mask:
 *                  type: string
 *                  default: EMP-0002
 *              name:
 *                  type: string
 *                  default: osmaro
 *              lastName:
 *                  type: string
 *                  default: bonilla
 *              userUpdate:
 *                  type: string
 *                  default: 1
 *      deleteEmployeeInput:
 *          type: object
 *          required:
 *              - status
 *          properties:
 *              status:
 *                  type: string
 *                  default: 1
 * 
 */
export const Employee = sequelize.define('employees',{
    id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true
    },
    mask:{
        type: DataTypes.STRING(9)
    },
    name: {
        type: DataTypes.STRING(100)
    },
    lastName:{
        type: DataTypes.STRING(100)
    },
    status:{
        type: DataTypes.INTEGER,
        defaultValue: 0,
    },
    userCreate:{
        type: DataTypes.INTEGER
    },
    userUpdate: {
        type: DataTypes.INTEGER
    }

});

// relationship between employee and user
Employee.hasMany(User,{
	foreignKey: 'employeeID',
	sourceKey: 'id'
});
User.belongsTo(Employee,{
	foreignKey: 'employeeID',
	targetId: 'id'
});
