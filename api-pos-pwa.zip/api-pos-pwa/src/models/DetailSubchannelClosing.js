import { DataTypes } from "sequelize";
import { sequelize } from "../database/database.js";
import {CashDeskClosing} from "./CashDeskClosing.js";
import {Subchannel} from "./Subchannel.js";

export const DetailSubchannelCashClosing = sequelize.define('detailSubchannelCashClosings',{
    id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true
    },
    total:{
        type: DataTypes.DOUBLE,
    },
    status:{
        type: DataTypes.INTEGER,
        defaultValue: 0,
    },
    userCreate:{
        type: DataTypes.INTEGER
    },
    userUpdate: {
        type: DataTypes.INTEGER
    }
});

// relationship between Modifiers and ModifierProducts
CashDeskClosing.hasMany(DetailSubchannelCashClosing, {
    foreignKey: 'cashDeskClosingID',
    sourceKey: 'id'
});

DetailSubchannelCashClosing.belongsTo(CashDeskClosing,{
    foreignKey: 'cashDeskClosingID',
    targetId: 'id'
});

// relationship between Modifiers and ModifierProducts
Subchannel.hasMany(DetailSubchannelCashClosing, {
    foreignKey: 'subchannelID',
    sourceKey: 'id'
});

DetailSubchannelCashClosing.belongsTo(Subchannel,{
    foreignKey: 'subchannelID',
    targetId: 'id'
});