import { DataTypes } from "sequelize";
import { sequelize } from "../database/database.js";
import { ModifierProducts } from "./ModifierProducts.js";
import { Submodifiers } from "./Submodifiers.js";

export const Modifiers = sequelize.define('modifiers',{
    id:{
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true,
    },
    mask:{
        type: DataTypes.STRING(11)
    },
    name:{
        type: DataTypes.STRING(75)
    },
    status:{
        type: DataTypes.INTEGER,
        defaultValue: 0,
    },
    userCreate:{
        type: DataTypes.INTEGER
    },
    userUpdate: {
        type: DataTypes.INTEGER
    }
})

// relationship between Modifiers and ModifierProducts
Modifiers.hasMany(ModifierProducts, {
    foreignKey: 'modifierID',
    sourceKey: 'id'
});

ModifierProducts.belongsTo(Modifiers,{
    foreignKey: 'modifierID',
    targetId: 'id'
});

// relationship between Modifiers and Submodifiers
Modifiers.hasMany(Submodifiers, {
    foreignKey: 'modifierID',
    sourceKey: 'id'
});

Submodifiers.belongsTo(Modifiers,{
    foreignKey: 'modifierID',
    targetId: 'id'
});