import { DataTypes } from "sequelize";
import { sequelize } from "../database/database.js";
import {CashDeskClosing} from "./CashDeskClosing.js";
import {User} from './User.js';

export const OutputCashDesk = sequelize.define('outputCashDesks',{
    id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true
    },
    output:{
        type: DataTypes.DOUBLE,
    },
    description:{
        type: DataTypes.STRING,
    },
    status:{
        type: DataTypes.INTEGER,
        defaultValue: 0,
    },
    userCreate:{
        type: DataTypes.INTEGER
    },
    userUpdate: {
        type: DataTypes.INTEGER
    },
    userAproved:{
        type:DataTypes.INTEGER
    }
});

// relationship between Modifiers and ModifierProducts
CashDeskClosing.hasMany(OutputCashDesk, {
    foreignKey: 'cashDeskClosingID',
    sourceKey: 'id'
});

OutputCashDesk.belongsTo(CashDeskClosing,{
    foreignKey: 'cashDeskClosingID',
    targetId: 'id'
});

// relationship between Modifiers and ModifierProducts
User.hasMany(OutputCashDesk, {
    foreignKey: 'userID',
    sourceKey: 'id'
});

OutputCashDesk.belongsTo(User,{
    foreignKey: 'userID',
    targetId: 'id'
});