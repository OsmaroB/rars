import { DataTypes } from "sequelize";
import { sequelize } from "../database/database.js";
import { ButtonCategories } from "./ButtonCategories.js";
import { SubCategories } from "./SubCategories.js";

export const Categories = sequelize.define('categories',{
    id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true
    },
    mask:{
        type: DataTypes.STRING(9)
    },
    name:{
        type: DataTypes.STRING(75)
    },
    position:{
        type: DataTypes.INTEGER
    },
    status:{
        type: DataTypes.INTEGER,
        defaultValue: 0,
    },
    userCreate:{
        type: DataTypes.INTEGER
    },
    userUpdate: {
        type: DataTypes.INTEGER
    }
});

// relationship between Buttons and ButtonsCategories
Categories.hasMany(ButtonCategories,{
    foreignKey: 'categoryID',
    sourceKey: 'id'
});

ButtonCategories.belongsTo(Categories,{
    foreignKey: 'categoryID',
    targetId: 'id'
});

// relationship between categories and subcategories
Categories.hasMany(SubCategories,{
    foreignKey: 'categoryID',
    sourceKey: 'id'
});

SubCategories.belongsTo(Categories,{
    foreignKey: 'categoryID',
    targetId: 'id'
});

