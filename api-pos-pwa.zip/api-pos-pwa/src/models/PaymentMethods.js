import { DataTypes } from "sequelize";
import { sequelize } from "../database/database.js";
import {PaymentMethodDetails} from './PaymentMethodDetails.js'

export const PaymentMethods = sequelize.define('paymentMethods',{
    id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true
    },
    mask:{
        type: DataTypes.STRING(9)
    },
    name:{
        type: DataTypes.STRING(75)
    },
    description:{
        type: DataTypes.STRING(255)
    },
    status:{
        type: DataTypes.INTEGER,
        defaultValue: 0,
    },
    userCreate:{
        type: DataTypes.INTEGER
    },
    userUpdate: {
        type: DataTypes.INTEGER
    }
});


// relationship between PatymentMethods and PaymentMethodDetails
PaymentMethods.hasMany(PaymentMethodDetails,{
    foreignKey: 'paymentMethodID',
    sourceKey: 'id'
});

PaymentMethodDetails.belongsTo(PaymentMethods,{
    foreignKey: 'paymentMethodID',
    targetId: 'id'
});
