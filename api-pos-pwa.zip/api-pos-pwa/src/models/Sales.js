/*
foreign key with tables
    -Users
    -Documents
    -Customers
*/
import { DataTypes } from "sequelize";
import { sequelize } from "../database/database.js";
import { CanceledSales } from "./CanceledSales.js";
import { Documents } from "./Documents.js";
import { Customers } from "./Customers.js";

export const Sales = sequelize.define('sales',{
    id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true
    },
    mask:{
        type: DataTypes.STRING
    },
    tiketNumber:{
        type: DataTypes.STRING
    },
    cashRegisterNumber:{
        type: DataTypes.STRING
    },
    restaurant:{
        type: DataTypes.STRING
    },
    channel:{
        type: DataTypes.STRING
    },
    channelID:{
        type: DataTypes.INTEGER
    },
    paymentMethod:{
        type: DataTypes.STRING
    },
    date:{
        type: DataTypes.DATE
    },
    hour:{
        type: DataTypes.STRING
    },
    totalWithoutTax:{
        type: DataTypes.DOUBLE
    },
    totalDiscount:{
        type: DataTypes.DOUBLE
    },
    totalWithDiscount:{
        type: DataTypes.DOUBLE
    },
    tax:{
        type: DataTypes.DOUBLE
    },
    totalWithTax:{
        type: DataTypes.DOUBLE
    },
    tip:{
        type: DataTypes.DOUBLE
    },
    cutX:{
        type: DataTypes.DOUBLE
    },
    cutY:{
        type: DataTypes.DOUBLE
    },
    status:{
        type: DataTypes.INTEGER
    },
    userCreate:{
        type: DataTypes.INTEGER
    },
    userUpdate:{
        type: DataTypes.INTEGER
    },
    userAproved:{
        type:DataTypes.INTEGER
    }
});




// relationship between Sales and SaleDetails 
Sales.hasMany(CanceledSales, {
    foreignKey: 'saleID',
    sourceKey: 'id'
});

CanceledSales.belongsTo(Sales,{
    foreignKey: 'saleID',
    targetId: 'id'
});

// relationship between Document and Sales 
Documents.hasMany(Sales, {
    foreignKey: 'documentID',
    sourceKey: 'id'
});

Sales.belongsTo(Documents,{
    foreignKey: 'documentID',
    targetId: 'id'
});

// relationship between Prices and SaleDetails 
Customers.hasMany(Sales, {
    foreignKey: 'customerID',
    sourceKey: 'id'
});

Sales.belongsTo(Customers,{
    foreignKey: 'customerID',
    targetId: 'id'
});


