import { DataTypes } from "sequelize";
import { sequelize } from "../database/database.js";
import {CashDeskClosing} from "./CashDeskClosing.js";
import {PaymentMethodDetails} from './PaymentMethodDetails.js';

export const DetailPaymentMethodCashClosing = sequelize.define('detailPaymentMethodCashClosings',{
    id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true
    },
    total:{
        type: DataTypes.DOUBLE,
    },
    status:{
        type: DataTypes.INTEGER,
        defaultValue: 0,
    },
    userCreate:{
        type: DataTypes.INTEGER
    },
    userUpdate: {
        type: DataTypes.INTEGER
    }
});

// relationship between Modifiers and ModifierProducts
CashDeskClosing.hasMany(DetailPaymentMethodCashClosing, {
    foreignKey: 'cashDeskClosingID',
    sourceKey: 'id'
});

DetailPaymentMethodCashClosing.belongsTo(CashDeskClosing,{
    foreignKey: 'cashDeskClosingID',
    targetId: 'id'
});

// relationship between Modifiers and ModifierProducts
PaymentMethodDetails.hasMany(DetailPaymentMethodCashClosing, {
    foreignKey: 'paymentMethodDetailID',
    sourceKey: 'id'
});

DetailPaymentMethodCashClosing.belongsTo(PaymentMethodDetails,{
    foreignKey: 'paymentMethodDetailID',
    targetId: 'id'
});