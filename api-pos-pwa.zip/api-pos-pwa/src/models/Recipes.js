import { DataTypes } from "sequelize";
import { sequelize } from "../database/database.js";
import { ProductDetails } from "./ProductDetails.js";
import { RecipeArticles } from "./RecipeArticles.js";

export const Recipes = sequelize.define('recipes',{
    id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true
    },
    mask:{
        type: DataTypes.STRING(9)
    },
    name:{
        type: DataTypes.STRING,
    },
    status:{
        type: DataTypes.INTEGER,
        defaultValue: 0,
    },
    userCreate:{
        type: DataTypes.INTEGER
    },
    userUpdate: {
        type: DataTypes.INTEGER
    }
});

   
// relationship between recipeArticles and Articles
Recipes.hasMany(RecipeArticles,{
    foreignKey: 'recipeID',
    sourceKey: 'id'
});

RecipeArticles.belongsTo(Recipes,{
    foreignKey: 'recipeID',
    targetId: 'id'
});

// relationship between Recipe and ProductDetails
Recipes.hasMany(ProductDetails,{
    foreignKey: 'recipeID',
    sourceKey: 'id',
});

ProductDetails.belongsTo(Recipes,{
    foreignKey: 'recipeID',
    targetId: 'id'
})