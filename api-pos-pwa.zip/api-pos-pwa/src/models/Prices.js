import { DataTypes } from "sequelize";
import { sequelize } from "../database/database.js";
import { ButtonDetails } from "./ButtonDetails.js";
import {ChannelsSubchannels} from './ChannelsSubchannels.js'
import { Subchannel } from "./Subchannel.js";
import { OptionalProducts } from './OptionalProducts.js';
import { ModifierProducts } from "./ModifierProducts.js";
import { SaleDetails } from "./saleDetails.js";
import {Discounts} from './Discounts.js';

export const Prices = sequelize.define('prices', {
    id:{
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true
    },
    price:{
        type: DataTypes.DOUBLE
    },
    status:{
        type: DataTypes.INTEGER,
        defaultValue: 0,
    },
    userCreate:{
        type: DataTypes.INTEGER
    },
    userUpdate: {
        type: DataTypes.INTEGER
    }
});

// relationship between Prices and ButtonDetails
ButtonDetails.hasMany(Prices,{
    foreignKey: 'buttonDetailID',
    sourceKey: 'id'
});

Prices.belongsTo(ButtonDetails,{
    foreignKey: 'buttonDetailID',
    targetId: 'id'
});

// relationship between Prices and ModifierProducts
ModifierProducts.hasMany(Prices,{
    foreignKey: 'modifierProductID',
    sourceKey: 'id'
});

Prices.belongsTo(ModifierProducts,{
    foreignKey: 'modifierProductID',
    targetId: 'id'
});

// relationship between Prices and ChannelsSubchannels
ChannelsSubchannels.hasMany(Prices,{
    foreignKey: 'channelID',
    sourceKey: 'id'
});

Prices.belongsTo(ChannelsSubchannels,{
    foreignKey: 'channelID',
    targetId: 'id'
});

// relationship between Prices and Subchannel
Subchannel.hasMany(Prices,{
    foreignKey: 'subchannelID',
    sourceKey: 'id'
});

Prices.belongsTo(Subchannel,{
    foreignKey: 'subchannelID',
    targetId: 'id'
});

// relationship between Prices and OptionalProducts
OptionalProducts.hasMany(Prices,{
    foreignKey: 'optionalProductID',
    sourceKey: 'id'
});

Prices.belongsTo(OptionalProducts,{
    foreignKey: 'optionalProductID',
    targetId: 'id'
});


// relationship between Discounts and Prices
Discounts.hasMany(Prices,{
    foreignKey: 'discountID',
    sourceKey: 'id'
});

Prices.belongsTo(Discounts,{
    foreignKey: 'discountID',
    targetId: 'id'
});

// relationship between ModifierProducts and Prices
ModifierProducts.hasMany(Prices,{
    foreignKey: 'modifierProductID',
    sourceKey: 'id'
});

Prices.belongsTo(ModifierProducts,{
    foreignKey: 'modifierProductID',
    targetId: 'id'
});



