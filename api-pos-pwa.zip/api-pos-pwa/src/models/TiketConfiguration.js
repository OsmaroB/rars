import { DataTypes } from "sequelize";
import { sequelize } from "../database/database.js";

export const TiketConfiguration = sequelize.define('tiketConfigurations',{
    id:{
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true,
    },
    enterprise:{
        type: DataTypes.STRING(100)
    },
    nit:{
        type: DataTypes.STRING(20)
    },
    item:{
        type: DataTypes.STRING(100)
    },
    address:{
        type: DataTypes.STRING(255)
    },
    resolution:{
        type: DataTypes.STRING(50)
    },
    serie:{
        type: DataTypes.STRING(20)
    },
    authorizationDate:{
        type: DataTypes.STRING(10)
    },
    cashRegisterNumber:{
        type: DataTypes.STRING(10)
    },
    link:{
        type: DataTypes.STRING(255)
    },
    paragraph1:{
        type: DataTypes.STRING(255)
    },
    paragraph2:{
        type: DataTypes.STRING(255)
    },
    userCreate:{
        type: DataTypes.INTEGER
    },
    userUpdate: {
        type: DataTypes.INTEGER
    }
})

