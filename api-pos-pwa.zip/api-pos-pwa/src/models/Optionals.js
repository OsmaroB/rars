import { DataTypes } from "sequelize";
import { sequelize } from "../database/database.js";
import { OptionalProducts } from "./OptionalProducts.js";

export const Optionals = sequelize.define('optionals',{
    id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true
    },
    mask:{
        type: DataTypes.STRING(9)
    },
    name:{
        type: DataTypes.STRING(75)
    },
    status:{
        type: DataTypes.INTEGER,
        defaultValue: 0,
    },
    userCreate:{
        type: DataTypes.INTEGER
    },
    userUpdate: {
        type: DataTypes.INTEGER
    }
});

// relationship between Optionals and OptionalProducts
Optionals.hasMany(OptionalProducts,{
    foreignKey: 'optionalID',
    sourceKey: 'id'
});

OptionalProducts.belongsTo(Optionals,{
    foreignKey: 'optionalID',
    targetId: 'id'
})
