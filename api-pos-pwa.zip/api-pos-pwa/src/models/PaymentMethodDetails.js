import { DataTypes } from "sequelize";
import { sequelize } from "../database/database.js";

export const PaymentMethodDetails = sequelize.define('paymentMethodDetails',{
    id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true
    },
    mask:{
        type: DataTypes.STRING(9)
    },
    name:{
        type: DataTypes.STRING(75)
    },
    description:{
        type: DataTypes.STRING(255)
    },
    status:{
        type: DataTypes.INTEGER,
        defaultValue: 0,
    },
    userCreate:{
        type: DataTypes.INTEGER
    },
    userUpdate: {
        type: DataTypes.INTEGER
    }
});