import { DataTypes } from "sequelize";
import { sequelize } from "../database/database.js";
import { ButtonDetails } from "./ButtonDetails.js";
import { OptionalProducts } from "./OptionalProducts.js";
import { ProductDetails } from "./ProductDetails.js";
import { ModifierProducts } from "./ModifierProducts.js";

export const Products = sequelize.define('products',{
    id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true
    },
    mask:{
        type: DataTypes.STRING(9)
    },
    name:{ 
        type:DataTypes.STRING
    },
    status:{
        type: DataTypes.INTEGER,
        defaultValue: 0,
    },
    userCreate:{
        type: DataTypes.INTEGER
    },
    userUpdate: {
        type: DataTypes.INTEGER
    },
    nickname:{
        type:DataTypes.STRING
    },
});

// relationship between Products and ProductDetails
Products.hasMany(ProductDetails,{
    foreignKey: 'productID',
    sourceKey: 'id'
});

ProductDetails.belongsTo(Products,{
    foreignKey: 'productID',
    targetId: 'id'
});

// relationship between Products and ButtonDetails
Products.hasMany(ButtonDetails,{
    foreignKey: 'productID',
    sourceKey: 'id'
});

ButtonDetails.belongsTo(Products,{
    foreignKey: 'productID',
    targetId: 'id'
});

// relationship between Products and OptionalProducts
Products.hasMany(OptionalProducts,{
    foreignKey: 'productID',
    sourceKey: 'id'
});

OptionalProducts.belongsTo(Products,{
    foreignKey: 'productID',
    targetId: 'id'
})

// relationship between Modifiers and Products
Products.hasMany(ModifierProducts,{
    foreignKey: 'productID',
    sourceKey: 'id'
});

ModifierProducts.belongsTo(Products,{
    foreignKey: 'productID',
    targetId: 'id'
});