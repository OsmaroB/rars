import swaggerJsDoc from 'swagger-jsdoc';
import {PORT} from '../config/config.js'

// Extended: https://swagger.io/specification/#infoObject
const swaggerOptions = {
    swaggerDefinition:{
      openapi: "3.0.0",
      info:{
        title: "Customer API",
        description: "description",
        contact:{
          name: "Osmaro Alfonso Bonilla"
        },
        // components:{
        //   sevuritySchemas:{
        //     bearerAuth:{
        //       type: "http",
        //       scheme: "bearer",
        //       bearerFormat: "JWT",
        //     }
        //   }
        // },
        // security:[
        //   {
        //     bearerAuth: [],
        //   }
        // ],
        servers: [`http://localhost:${PORT}`]
      }
    },
    apis: ["./src/routes/*", "./src/models/*", "./src/swagger/routes/*", "./src/swagger/schemas/*"],
  };

export const swaggerDocs = swaggerJsDoc(swaggerOptions);
