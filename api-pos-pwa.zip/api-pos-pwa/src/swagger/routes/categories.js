/** 
 * @openapi
 * /categories:
 *  get:
 *    tags:
 *      - Categories
 *    summary: Get all elements
 *    description: Get all items in table
 *    responses:
 *      '200':
 *        description: A successful response
*/

/**
 * @openapi
 * /categories:
 *  post:
 *      tags:
 *          - Categories
 *      summary: Register item in table with success structure
 *      description: use to create item in table
 *      responses:
 *          '200':
 *              description: A successful response
 *      requestBody:
 *          required: true
 *          content:
 *              application/json:
 *                  schema:
 *                      $ref: '#/components/schemas/createCategory'
 * 
 */

/**
 * @openapi
 * /categories/1:
 *  put:
 *      tags:
 *          - Categories
 *      summary: Update element
 *      description: use to update item in table with success structure
 *      responses:
 *          '200':
 *              description: A successful response
 *      requestBody:
 *          required: true
 *          content:
 *              application/json:
 *                  schema:
 *                      $ref: '#/components/schemas/updateCategory'
 */

/**
 * @openapi
 * /categories-remove/1:
 *  put:
 *      tags:
 *          - Categories
 *      summary: Remove logit item for status in table
 *      description: Update column status in table
 *      responses:
 *          '200':
 *              description: A successful response
 *      requestBody:
 *          required: true
 *          content:
 *              application/json:
 *                  schema:
 *                      $ref: '#/components/schemas/delete'
 * 
 */

/**
 * @openapi
 * /categories/1:
 *  get:
 *      tags:
 *          - Categories
 *      summary: Get element for Id
 *      description: Read element for id in table
 *      responses:
 *          '200':
 *              description: A successful response
 * 
 */