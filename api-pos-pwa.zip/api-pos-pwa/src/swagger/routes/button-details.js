/** 
 * @openapi
 * /button-details:
 *  get:
 *    tags:
 *      - ButtonDetails
 *    summary: Get all elements
 *    description: Get all items in table
 *    responses:
 *      '200':
 *        description: A successful response
*/

/**
 * @openapi
 * /button-details:
 *  post:
 *      tags:
 *          - ButtonDetails
 *      summary: Register item in table with success structure
 *      description: use to create item in table
 *      responses:
 *          '200':
 *              description: A successful response
 *      requestBody:
 *          required: true
 *          content:
 *              application/json:
 *                  schema:
 *                      $ref: '#/components/schemas/createButtonDetail'
 * 
 */

/**
 * @openapi
 * /button-details/1:
 *  put:
 *      tags:
 *          - ButtonDetails
 *      summary: Update element
 *      description: use to update item in table with success structure
 *      responses:
 *          '200':
 *              description: A successful response
 *      requestBody:
 *          required: true
 *          content:
 *              application/json:
 *                  schema:
 *                      $ref: '#/components/schemas/updateButtonDetail'
 */

/**
 * @openapi
 * /button-details-remove/1:
 *  put:
 *      tags:
 *          - ButtonDetails
 *      summary: Remove logit item for status in table
 *      description: Update column status in table
 *      responses:
 *          '200':
 *              description: A successful response
 *      requestBody:
 *          required: true
 *          content:
 *              application/json:
 *                  schema:
 *                      $ref: '#/components/schemas/delete'
 * 
 */

/**
 * @openapi
 * /button-details/1:
 *  get:
 *      tags:
 *          - ButtonDetails
 *      summary: Get element for Id
 *      description: Read element for id in table
 *      responses:
 *          '200':
 *              description: A successful response
 * 
 */