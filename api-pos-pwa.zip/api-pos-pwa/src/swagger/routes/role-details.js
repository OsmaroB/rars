/** 
 * @openapi
 * /roles-detail:
 *  get:
 *    tags:
 *      - RolesDetail
 *    summary: Get all elements
 *    description: Get all items in table
 *    responses:
 *      '200':
 *        description: A successful response
*/

/**
 * @openapi
 * /roles-detail:
 *  post:
 *      tags:
 *          - RolesDetail
 *      summary: Register item in table with success structure
 *      description: use to create item in table
 *      responses:
 *          '200':
 *              description: A successful response
 *      requestBody:
 *          required: true
 *          content:
 *              application/json:
 *                  schema:
 *                      $ref: '#/components/schemas/createRoleDetail'
 * 
 */

/**
 * @openapi
 * /roles-detail/1:
 *  put:
 *      tags:
 *          - RolesDetail
 *      summary: Update element
 *      description: use to update item in table with success structure
 *      responses:
 *          '200':
 *              description: A successful response
 *      requestBody:
 *          required: true
 *          content:
 *              application/json:
 *                  schema:
 *                      $ref: '#/components/schemas/updateRoleDetail'
 */

/**
 * @openapi
 * /roles-detail-remove/1:
 *  put:
 *      tags:
 *          - RolesDetail
 *      summary: Remove logit item for status in table
 *      description: Update column status in table
 *      responses:
 *          '200':
 *              description: A successful response
 *      requestBody:
 *          required: true
 *          content:
 *              application/json:
 *                  schema:
 *                      $ref: '#/components/schemas/delete'
 * 
 */

/**
 * @openapi
 * /roles-detail/1:
 *  get:
 *      tags:
 *          - RolesDetail
 *      summary: Get element for Id
 *      description: Read element for id in table
 *      responses:
 *          '200':
 *              description: A successful response
 * 
 */