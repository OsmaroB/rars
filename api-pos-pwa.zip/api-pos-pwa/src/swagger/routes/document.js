/** 
 * @openapi
 * /document-types:
 *  get:
 *    tags:
 *      - DocumentTypes
 *    summary: Get all elements
 *    description: Get all items in table
 *    responses:
 *      '200':
 *        description: A successful response
*/

/**
 * @openapi
 * /document-types:
 *  post:
 *      tags:
 *          - DocumentTypes
 *      summary: Register item in table with success structure
 *      description: use to create item in table
 *      responses:
 *          '200':
 *              description: A successful response
 *      requestBody:
 *          required: true
 *          content:
 *              application/json:
 *                  schema:
 *                      $ref: '#/components/schemas/createDocument'
 * 
 */

/**
 * @openapi
 * /document-types/1:
 *  put:
 *      tags:
 *          - DocumentTypes
 *      summary: Update element
 *      description: use to update item in table with success structure
 *      responses:
 *          '200':
 *              description: A successful response
 *      requestBody:
 *          required: true
 *          content:
 *              application/json:
 *                  schema:
 *                      $ref: '#/components/schemas/updateDocument'
 */

/**
 * @openapi
 * /document-types-remove/1:
 *  put:
 *      tags:
 *          - DocumentTypes
 *      summary: Remove logit item for status in table
 *      description: Update column status in table
 *      responses:
 *          '200':
 *              description: A successful response
 *      requestBody:
 *          required: true
 *          content:
 *              application/json:
 *                  schema:
 *                      $ref: '#/components/schemas/delete'
 * 
 */

/**
 * @openapi
 * /document-types/1:
 *  get:
 *      tags:
 *          - DocumentTypes
 *      summary: Get element for Id
 *      description: Read element for id in table
 *      responses:
 *          '200':
 *              description: A successful response
 * 
 */