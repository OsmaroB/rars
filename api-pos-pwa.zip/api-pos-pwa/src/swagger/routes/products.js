/** 
 * @openapi
 * /products:
 *  get:
 *    tags:
 *      - Products
 *    summary: Get all elements
 *    description: Get all items in table
 *    responses:
 *      '200':
 *        description: A successful response
*/

/**
 * @openapi
 * /products:
 *  post:
 *      tags:
 *          - Products
 *      summary: Register item in table with success structure
 *      description: use to create item in table
 *      responses:
 *          '200':
 *              description: A successful response
 *      requestBody:
 *          required: true
 *          content:
 *              application/json:
 *                  schema:
 *                      $ref: '#/components/schemas/createProduct'
 * 
 */

/**
 * @openapi
 * /products/1:
 *  put:
 *      tags:
 *          - Products
 *      summary: Update element
 *      description: use to update item in table with success structure
 *      responses:
 *          '200':
 *              description: A successful response
 *      requestBody:
 *          required: true
 *          content:
 *              application/json:
 *                  schema:
 *                      $ref: '#/components/schemas/updateProduct'
 */

/**
 * @openapi
 * /products-remove/1:
 *  put:
 *      tags:
 *          - Products
 *      summary: Remove logit item for status in table
 *      description: Update column status in table
 *      responses:
 *          '200':
 *              description: A successful response
 *      requestBody:
 *          required: true
 *          content:
 *              application/json:
 *                  schema:
 *                      $ref: '#/components/schemas/delete'
 * 
 */

/**
 * @openapi
 * /products/1:
 *  get:
 *      tags:
 *          - Products
 *      summary: Get element for Id
 *      description: Read element for id in table
 *      responses:
 *          '200':
 *              description: A successful response
 * 
 */