/** 
 * @openapi
 * /optional-products:
 *  get:
 *    tags:
 *      - OptionalProduct
 *    summary: Get all elements
 *    description: Get all items in table
 *    responses:
 *      '200':
 *        description: A successful response
*/

/**
 * @openapi
 * /optional-products:
 *  post:
 *      tags:
 *          - OptionalProduct
 *      summary: Register item in table with success structure
 *      description: use to create item in table
 *      responses:
 *          '200':
 *              description: A successful response
 *      requestBody:
 *          required: true
 *          content:
 *              application/json:
 *                  schema:
 *                      $ref: '#/components/schemas/createOptionalProduct'
 * 
 */

/**
 * @openapi
 * /optional-products/1:
 *  put:
 *      tags:
 *          - OptionalProduct
 *      summary: Update element
 *      description: use to update item in table with success structure
 *      responses:
 *          '200':
 *              description: A successful response
 *      requestBody:
 *          required: true
 *          content:
 *              application/json:
 *                  schema:
 *                      $ref: '#/components/schemas/updateOptionalProduct'
 */

/**
 * @openapi
 * /optional-products-remove/1:
 *  put:
 *      tags:
 *          - OptionalProduct
 *      summary: Remove logit item for status in table
 *      description: Update column status in table
 *      responses:
 *          '200':
 *              description: A successful response
 *      requestBody:
 *          required: true
 *          content:
 *              application/json:
 *                  schema:
 *                      $ref: '#/components/schemas/delete'
 * 
 */

/**
 * @openapi
 * /optional-products/1:
 *  get:
 *      tags:
 *          - OptionalProduct
 *      summary: Get element for Id
 *      description: Read element for id in table
 *      responses:
 *          '200':
 *              description: A successful response
 * 
 */