/**
 * @openapi
 * components:
 *  schemas:
 *      createProductDetail:
 *          type: object
 *          required:
 *              - recipeID
 *              - productID
 *              - status
 *              - userCreate
 *          properties:
 *              recipeID:
 *                  type: integer
 *                  default: 1
 *              productID:
 *                  type: integer
 *                  default: 1
 *              status:
 *                  type: string
 *                  default: 0
 *              userCreate:
 *                  type: integer
 *                  default: 1
 *      updateProductDetail:
 *          type: object
 *          required:
 *              - recipeID
 *              - productID
 *              - status
 *              - userUpdate
 *          properties:
 *              recipeID:
 *                  type: integer
 *                  default: 1
 *              productID:
 *                  type: integer
 *                  default: 1
 *              status:
 *                  type: string
 *                  default: 0
 *              userUpdate:
 *                  type: string
 *                  default: 1
 *      delete:
 *          type: object
 *          required:
 *              - status
 *          properties:
 *              status:
 *                  type: string
 *                  default: 1
 * 
 */