/**
 * @openapi
 * components:
 *  schemas:
 *      createOptional:
 *          type: object
 *          required:
 *              - mask
 *              - name
 *              - status
 *              - userCreate
 *          properties:
 *              mask:
 *                  type: string
 *                  default: OPT-0001
 *              name:
 *                  type: string
 *                  default: opcional
 *              status:
 *                  type: string
 *                  default: 0
 *              userCreate:
 *                  type: integer
 *                  default: 1
 *      updateOptional:
 *          type: object
 *          required:
 *              - mask
 *              - name
 *              - status
 *              - userUpdate
 *          properties:
 *              mask:
 *                  type: string
 *                  default: OPT-0002
 *              name:
 *                  type: string
 *                  default: opcional modificado
 *              status:
 *                  type: string
 *                  default: 0
 *              userUpdate:
 *                  type: string
 *                  default: 1
 *      delete:
 *          type: object
 *          required:
 *              - status
 *          properties:
 *              status:
 *                  type: string
 *                  default: 1
 * 
 */