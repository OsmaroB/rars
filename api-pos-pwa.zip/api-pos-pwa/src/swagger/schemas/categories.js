/**
 * @openapi
 * components:
 *  schemas:
 *      createCategory:
 *          type: object
 *          required:
 *              - mask
 *              - name
 *              - status
 *              - userCreate
 *          properties:
 *              mask:
 *                  type: string
 *                  default: CAT-0001
 *              name:
 *                  type: string
 *                  default: categoria
 *              status:
 *                  type: string
 *                  default: 0
 *              userCreate:
 *                  type: integer
 *                  default: 1
 *      updateCategory:
 *          type: object
 *          required:
 *              - mask
 *              - name
 *              - status
 *              - userUpdate
 *          properties:
 *              mask:
 *                  type: string
 *                  default: CAT-0002
 *              name:
 *                  type: string
 *                  default: categoria modificada
 *              status:
 *                  type: string
 *                  default: 0
 *              userUpdate:
 *                  type: string
 *                  default: 1
 *      delete:
 *          type: object
 *          required:
 *              - status
 *          properties:
 *              status:
 *                  type: string
 *                  default: 1
 * 
 */