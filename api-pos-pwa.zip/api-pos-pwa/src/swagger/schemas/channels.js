/**
 * @openapi
 * components:
 *  schemas:
 *      createChannel:
 *          type: object
 *          required:
 *              - mask
 *              - name
 *              - description
 *              - restaurant
 *              - isChannel
 *              - status
 *              - userCreate
 *          properties:
 *              mask:
 *                  type: string
 *                  default: CHA-0001
 *              name:
 *                  type: string
 *                  default: canal
 *              description:
 *                  type: string
 *                  default: descripciòn del canal
 *              restaurant:
 *                  type: string
 *                  default: restaurante
 *              isChannel:
 *                  type: boolean
 *                  default: true
 *              status:
 *                  type: string
 *                  default: 0
 *              userCreate:
 *                  type: integer
 *                  default: 1
 *      updateChannel:
 *          type: object
 *          required:
 *              - mask
 *              - name
 *              - description
 *              - restaurant
 *              - isChannel
 *              - userUpdate
 *          properties:
 *              mask:
 *                  type: string
 *                  default: CHA-0002
 *              name:
 *                  type: string
 *                  default: modific
 *              description:
 *                  type: string
 *                  default: descripciòn del canal
 *              restaurant:
 *                  type: string
 *                  default: restaurante
 *              isChannel:
 *                  type: boolean
 *                  default: true
 *              userUpdate:
 *                  type: string
 *                  default: 1
 *      delete:
 *          type: object
 *          required:
 *              - status
 *          properties:
 *              status:
 *                  type: string
 *                  default: 1
 * 
 */