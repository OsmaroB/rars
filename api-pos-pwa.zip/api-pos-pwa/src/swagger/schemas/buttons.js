/**
 * @openapi
 * components:
 *  schemas:
 *      createButton:
 *          type: object
 *          required:
 *              - mask
 *              - name
 *              - position
 *              - status
 *              - userCreate
 *          properties:
 *              mask:
 *                  type: string
 *                  default: BUT-0001
 *              name:
 *                  type: string
 *                  default: boton
 *              position:
 *                  type: integer
 *                  default: 1
 *              status:
 *                  type: string
 *                  default: 0
 *              userCreate:
 *                  type: integer
 *                  default: 1
 *      updateButton:
 *          type: object
 *          required:
 *              - mask
 *              - name
 *              - position
 *              - status
 *              - userUpdate
 *          properties:
 *              mask:
 *                  type: string
 *                  default: BUT-0002
 *              name:
 *                  type: string
 *                  default: boton modificado
 *              position:
 *                  type: integer
 *                  default: 2
 *              status:
 *                  type: string
 *                  default: 0
 *              userUpdate:
 *                  type: string
 *                  default: 1
 *      delete:
 *          type: object
 *          required:
 *              - status
 *          properties:
 *              status:
 *                  type: string
 *                  default: 1
 * 
 */