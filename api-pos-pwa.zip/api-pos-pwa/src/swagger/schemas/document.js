/**
 * @openapi
 * components:
 *  schemas:
 *      createDocument:
 *          type: object
 *          required:
 *              - mask
 *              - name
 *              - description
 *              - status
 *              - userCreate
 *          properties:
 *              mask:
 *                  type: string
 *                  default: DOC-0001
 *              name:
 *                  type: string
 *                  default: tipo de documento
 *              description:
 *                  type: string
 *                  default: descripcion
 *              status:
 *                  type: string
 *                  default: 0
 *              userCreate:
 *                  type: integer
 *                  default: 1
 *      updateDocument:
 *          type: object
 *          required:
 *              - mask
 *              - name
 *              - description
 *              - userUpdate
 *          properties:
 *              mask:
 *                  type: string
 *                  default: DOC-0002
 *              name:
 *                  type: string
 *                  default: descripciòn modificada
 *              description:
 *                  type: string
 *                  default: descripciòn
 *              userUpdate:
 *                  type: string
 *                  default: 1
 *      delete:
 *          type: object
 *          required:
 *              - status
 *          properties:
 *              status:
 *                  type: string
 *                  default: 1
 * 
 */