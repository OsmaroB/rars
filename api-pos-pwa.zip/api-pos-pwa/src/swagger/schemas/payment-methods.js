/**
 * @openapi
 * components:
 *  schemas:
 *      createPaymentMethod:
 *          type: object
 *          required:
 *              - mask
 *              - name
 *              - description
 *              - status
 *              - userCreate
 *          properties:
 *              mask:
 *                  type: string
 *                  default: PAY-0001
 *              name:
 *                  type: string
 *                  default: metodo de pago
 *              descripcion:
 *                  type: string
 *                  default: descripción de metodo de pago
 *              status:
 *                  type: string
 *                  default: 0
 *              userCreate:
 *                  type: integer
 *                  default: 1
 *      updatePaymentMethod:
 *          type: object
 *          required:
 *              - mask
 *              - name
 *              - description
 *              - status
 *              - userUpdate
 *          properties:
 *              mask:
 *                  type: string
 *                  default: PAY-0002
 *              name:
 *                  type: string
 *                  default: descripción modificada
 *              descripcion:
 *                  type: string
 *                  default: descripción de metodo de pago
 *              status:
 *                  type: string
 *                  default: 0
 *              userUpdate:
 *                  type: string
 *                  default: 1
 *      delete:
 *          type: object
 *          required:
 *              - status
 *          properties:
 *              status:
 *                  type: string
 *                  default: 1
 * 
 */