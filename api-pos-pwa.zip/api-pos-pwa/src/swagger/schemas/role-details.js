/**
 * @openapi
 * components:
 *  schemas:
 *      createRoleDetail:
 *          type: object
 *          required:
 *              - mask
 *              - url
 *              - status
 *              - roleID
 *              - userCreate
 *          properties:
 *              mask:
 *                  type: string
 *                  default: RDT-0001
 *              url:
 *                  type: string
 *                  default: /products
 *              status:
 *                  type: string
 *                  default: 0
 *              roleID:
 *                  type: integer
 *                  default: 1
 *              userCreate:
 *                  type: integer
 *                  default: 1
 *      updateRoleDetail:
 *          type: object
 *          required:
 *              - mask
 *              - url
 *              - roleID
 *              - userCreate
 *          properties:
 *              mask:
 *                  type: string
 *                  default: RDT-0002
 *              url:
 *                  type: string
 *                  default: /products
 *              roleID:
 *                  type: integer
 *                  default: 1
 *              userUpdate:
 *                  type: string
 *                  default: 1
 *      delete:
 *          type: object
 *          required:
 *              - status
 *          properties:
 *              status:
 *                  type: string
 *                  default: 1
 * 
 */