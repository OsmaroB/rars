/**
 * @openapi
 * components:
 *  schemas:
 *      createRecipes:
 *          type: object
 *          required:
 *              - mask
 *              - name
 *              - status
 *              - userCreate
 *          properties:
 *              mask:
 *                  type: string
 *                  default: REC-0001
 *              name:
 *                  type: string
 *                  default: receta
 *              status:
 *                  type: string
 *                  default: 0
 *              userCreate:
 *                  type: integer
 *                  default: 1
 *      updateRecipes:
 *          type: object
 *          required:
 *              - mask
 *              - name
 *              - status
 *              - userUpdate
 *          properties:
 *              mask:
 *                  type: string
 *                  default: REC-0002
 *              name:
 *                  type: string
 *                  default: receta modificada
 *              status:
 *                  type: string
 *                  default: 0
 *              userUpdate:
 *                  type: string
 *                  default: 1
 *      delete:
 *          type: object
 *          required:
 *              - status
 *          properties:
 *              status:
 *                  type: string
 *                  default: 1
 * 
 */