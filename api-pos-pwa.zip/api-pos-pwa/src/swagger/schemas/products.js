/**
 * @openapi
 * components:
 *  schemas:
 *      createProduct:
 *          type: object
 *          required:
 *              - mask
 *              - name
 *              - status
 *              - userCreate
 *          properties:
 *              mask:
 *                  type: string
 *                  default: PRO-0001
 *              name:
 *                  type: string
 *                  default: producto
 *              status:
 *                  type: string
 *                  default: 0
 *              userCreate:
 *                  type: integer
 *                  default: 1
 *      updateProduct:
 *          type: object
 *          required:
 *              - mask
 *              - name
 *              - status
 *              - userUpdate
 *          properties:
 *              mask:
 *                  type: string
 *                  default: PRO-0002
 *              name:
 *                  type: string
 *                  default: producto modificado
 *              status:
 *                  type: string
 *                  default: 0
 *              userUpdate:
 *                  type: string
 *                  default: 1
 *      delete:
 *          type: object
 *          required:
 *              - status
 *          properties:
 *              status:
 *                  type: string
 *                  default: 1
 * 
 */