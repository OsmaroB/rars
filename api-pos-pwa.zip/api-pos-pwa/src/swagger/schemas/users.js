/**
 * @openapi
 * components:
 *  schemas:
 *      createUser:
 *          type: object
 *          required:
 *              - mask
 *              - email
 *              - password
 *              - status
 *              - userCreate
 *              - employeeID
 *              - roleID
 *          properties:
 *              mask:
 *                  type: string
 *                  default: USE-0001
 *              email:
 *                  type: string
 *                  default: osmaro.bonilla.argos@gmail.com
 *              password:
 *                  type: string
 *                  default: password
 *              employeeID:
 *                  type: integer
 *                  default: 1
 *              roleID:
 *                  type: integer
 *                  default: 1
 *              status:
 *                  type: string
 *                  default: 0
 *              userCreate:
 *                  type: integer
 *                  default: 1
 *      updateUser:
 *          type: object
 *          required:
 *              - mask
 *              - email
 *              - password
 *              - userCreate
 *              - employeeID
 *              - roleID
 *          properties:
 *              mask:
 *                  type: string
 *                  default: USE-0001
 *              email:
 *                  type: string
 *                  default: osmaro.bonilla.argos@gmail.com
 *              password:
 *                  type: string
 *                  default: password
 *              employeeID:
 *                  type: integer
 *                  default: 1
 *              roleID:
 *                  type: integer
 *                  default: 1
 *              userUpdate:
 *                  type: string
 *                  default: 1
 *      delete:
 *          type: object
 *          required:
 *              - status
 *          properties:
 *              status:
 *                  type: string
 *                  default: 1
 * 
 */