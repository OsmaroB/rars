/**
 * @openapi
 * components:
 *  schemas:
 *      createButtonDetail:
 *          type: object
 *          required:
 *              - status
 *              - productID
 *              - buttonID
 *              - userCreate
 *          properties:
 *              productID:
 *                  type: integer
 *                  default: 1
 *              buttonID:
 *                  type: integer
 *                  default: 1
 *              status:
 *                  type: string
 *                  default: 0
 *              userCreate:
 *                  type: integer
 *                  default: 1
 *      updateButtonDetail:
 *          type: object
 *          required:
 *              - productID
 *              - buttonID
 *              - status
 *              - userUpdate
 *          properties:
 *              productID:
 *                  type: integer
 *                  default: 1
 *              buttonID:
 *                  type: integer
 *                  default: 1
 *              status:
 *                  type: string
 *                  default: 0
 *              userUpdate:
 *                  type: string
 *                  default: 1
 *      delete:
 *          type: object
 *          required:
 *              - status
 *          properties:
 *              status:
 *                  type: string
 *                  default: 1
 * 
 */