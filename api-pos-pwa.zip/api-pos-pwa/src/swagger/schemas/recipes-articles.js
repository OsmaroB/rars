/**
 * @openapi
 * components:
 *  schemas:
 *      createRecipesArticles:
 *          type: object
 *          required:
 *              - quantity
 *              - status
 *              - userCreate
 *              - articleID
 *              - recipeID
 *          properties:
 *              quantity:
 *                  type: integer
 *                  default: 120
 *              status:
 *                  type: string
 *                  default: 0
 *              articleID:
 *                  type: integer
 *                  default: 1
 *              recipeID:
 *                  type: integer
 *                  default: 1
 *              userCreate:
 *                  type: integer
 *                  default: 1
 *      updateRecipesArticles:
 *          type: object
 *          required:
 *              - quantity
 *              - userUpdate
 *              - articleID
 *              - recipeID
 *          properties:
 *              quantity:
 *                  type: integer
 *                  default: 500
 *              articleID:
 *                  type: integer
 *                  default: 1
 *              recipeID:
 *                  type: integer
 *                  default: 1
 *              userUpdate:
 *                  type: string
 *                  default: 1
 *      delete:
 *          type: object
 *          required:
 *              - status
 *          properties:
 *              status:
 *                  type: string
 *                  default: 1
 * 
 */