/**
 * @openapi
 * components:
 *  schemas:
 *      createCategoryButton:
 *          type: object
 *          required:
 *              - buttonID
 *              - categoryID
 *              - status
 *              - userCreate
 *          properties:
 *              buttonID:
 *                  type: integer
 *                  default: 1
 *              categoryID:
 *                  type: integer
 *                  default: 1
 *              status:
 *                  type: string
 *                  default: 0
 *              userCreate:
 *                  type: integer
 *                  default: 1
 *      updateCategoryButton:
 *          type: object
 *          required:
 *              - buttonID
 *              - categoryID
 *              - status
 *              - userUpdate
 *          properties:
 *              buttonID:
 *                  type: integer
 *                  default: 1
 *              categoryID:
 *                  type: integer
 *                  default: 1
 *              status:
 *                  type: string
 *                  default: 0
 *              userUpdate:
 *                  type: string
 *                  default: 1
 *      delete:
 *          type: object
 *          required:
 *              - status
 *          properties:
 *              status:
 *                  type: string
 *                  default: 1
 * 
 */