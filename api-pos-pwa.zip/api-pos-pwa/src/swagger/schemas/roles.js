/**
 * @openapi
 * components:
 *  schemas:
 *      createRole:
 *          type: object
 *          required:
 *              - mask
 *              - name
 *              - description
 *              - status
 *              - userCreate
 *          properties:
 *              mask:
 *                  type: string
 *                  default: ROL-0001
 *              name:
 *                  type: string
 *                  default: gerente
 *              description:
 *                  type: string
 *                  default: rol de gerente
 *              status:
 *                  type: string
 *                  default: 0
 *              userCreate:
 *                  type: integer
 *                  default: 1
 *      updateRole:
 *          type: object
 *          required:
 *              - mask
 *              - name
 *              - description
 *              - userCreate
 *          properties:
 *              mask:
 *                  type: string
 *                  default: ROL-0003
 *              name:
 *                  type: string
 *                  default: rol gerente
 *              description:
 *                  type: string
 *                  default: rol de gerente modificado
 *              userUpdate:
 *                  type: string
 *                  default: 1
 *      delete:
 *          type: object
 *          required:
 *              - status
 *          properties:
 *              status:
 *                  type: string
 *                  default: 1
 * 
 */