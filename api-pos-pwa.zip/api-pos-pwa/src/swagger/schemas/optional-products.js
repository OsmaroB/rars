/**
 * @openapi
 * components:
 *  schemas:
 *      createOptionalProduct:
 *          type: object
 *          required:
 *              - productID
 *              - optionalID
 *              - status
 *              - userCreate
 *          properties:
 *              productID:
 *                  type: integer
 *                  default: 1
 *              optionalID:
 *                  type: integer
 *                  default: 1
 *              status:
 *                  type: string
 *                  default: 0
 *              userCreate:
 *                  type: integer
 *                  default: 1
 *      updateOptionalProduct:
 *          type: object
 *          required:
 *              - productID
 *              - optionalID
 *              - status
 *              - userUpdate
 *          properties:
 *              productID:
 *                  type: integer
 *                  default: 1
 *              optionalID:
 *                  type: integer
 *                  default: 1
 *              status:
 *                  type: string
 *                  default: 0
 *              userUpdate:
 *                  type: string
 *                  default: 1
 *      delete:
 *          type: object
 *          required:
 *              - status
 *          properties:
 *              status:
 *                  type: string
 *                  default: 1
 * 
 */