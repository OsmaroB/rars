export const maskText = (prefix, id) => {
    if(id > 9 ){
        return `${prefix}-0${id}`
    }
    if(id > 99 ){
        return `${prefix}-${id}`
    }
    if(id <= 9 ){
        return `${prefix}-00${id}`
    }
};